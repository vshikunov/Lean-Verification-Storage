import ReciprocalCounterexample.Definitions
import ReciprocalCounterexample.Algebra
import ReciprocalCounterexample.Forcing
import ReciprocalCounterexample.PeriodicForcing
import ReciprocalCounterexample.Energy
import ReciprocalCounterexample.Normalization
import ReciprocalCounterexample.EnergyControl
import ReciprocalCounterexample.WeightedLog
import ReciprocalCounterexample.MainReduction

import ReciprocalCounterexample.FlatCoreMain
import ReciprocalCounterexample.FlatCoreWitness
import ReciprocalCounterexample.FlatCoreSlope
import ReciprocalCounterexample.CollisionPassage
import ReciprocalCounterexample.LogCompactness

/-!
# Complete formal verification of the smooth reciprocal counterexample

`mainTheorem_explicit : MainTheorem` proves the original target without any
analytic hypothesis, using `explicitCounterexampleForcing`. The flat-core
construction replaces the earlier sixth-order collision approach. Supporting
results from that older branch are retained; its separate stronger proposition
`SmoothedNonexistence` is not needed or asserted by the completed proof.
-/
