import ReciprocalCounterexample
import Lean.Util.CollectAxioms

/-!
# Audit of the complete counterexample proof

Every compiled project theorem is checked against the three standard classical
axioms used by mathlib. Complete theorem types are compared with MainTheorem
and with the specified witness proposition. An implication with an unproved
premise cannot qualify as an unconditional proof. The legacy sixth-order
proposition is inspected separately and is not required by the flat-core proof.
-/
open Lean Elab Command Meta
set_option maxHeartbeats 0

run_cmd do
  let env ← getEnv
  let allowed : Array Name := #[`propext, `Classical.choice, `Quot.sound]
  let mut count := 0
  for (name, info) in env.constants.toList do
    if (`ReciprocalCounterexample).isPrefixOf name && info.isTheorem then
      let axioms ← Lean.collectAxioms name
      for ax in axioms do
        unless allowed.contains ax do
          throwError "Unexpected axiom {ax} in {name}"
      count := count + 1
      logInfo m!"AXIOM_CHECK_PASS {name}: {axioms}"
  logInfo m!"CHECKED_DECLARATIONS {count}"
  logInfo "ALL_COMPONENT_AXIOM_CHECKS_PASSED"

run_cmd do
  let proved ← liftTermElabM do
    let env ← getEnv
    let mut found : Array Name := #[]
    for (name, info) in env.constants.toList do
      if (`ReciprocalCounterexample).isPrefixOf name && info.isTheorem then
        if ← isDefEq info.type (mkConst `ReciprocalCounterexample.MainTheorem) then
          found := found.push name
    pure found
  if proved.isEmpty then
    logInfo "MAIN_THEOREM_STATUS: NOT_PROVED"
  else
    logInfo "MAIN_THEOREM_STATUS: PROVED"
    for name in proved do
      logInfo m!"MAIN_THEOREM_PROOF {name}"
    logInfo m!"MAIN_THEOREM_PROOFS: {proved}"

run_cmd do
  let proved ← liftTermElabM do
    let env ← getEnv
    let target := mkApp (mkConst `ReciprocalCounterexample.IsCounterexample)
      (mkConst `ReciprocalCounterexample.explicitCounterexampleForcing)
    let mut found : Array Name := #[]
    for (name, info) in env.constants.toList do
      if (`ReciprocalCounterexample).isPrefixOf name && info.isTheorem then
        if ← isDefEq info.type target then
          found := found.push name
    pure found
  if proved.isEmpty then
    logInfo "SPECIFIED_FORCING_STATUS: NOT_PROVED"
  else
    logInfo "SPECIFIED_FORCING_STATUS: VERIFIED"
    for name in proved do
      logInfo m!"SPECIFIED_FORCING_PROOF {name}"
  logInfo "SPECIFIED_FORCING: ReciprocalCounterexample.explicitCounterexampleForcing"

run_cmd do
  let proved ← liftTermElabM do
    let env ← getEnv
    let mut found : Array Name := #[]
    for (name, info) in env.constants.toList do
      if (`ReciprocalCounterexample).isPrefixOf name && info.isTheorem then
        if ← isDefEq info.type (mkConst `ReciprocalCounterexample.SmoothedNonexistence) then
          found := found.push name
    pure found
  if proved.isEmpty then
    logInfo "LEGACY_SIXTH_ORDER_STATUS: NOT_PROVED"
  else
    logInfo "LEGACY_SIXTH_ORDER_STATUS: PROVED"
    for name in proved do
      logInfo m!"LEGACY_SIXTH_ORDER_PROOF {name}"
  logInfo "LEGACY_SIXTH_ORDER_REQUIRED_FOR_MAIN: FALSE"

#check ReciprocalCounterexample.MainTheorem
#check ReciprocalCounterexample.mainTheorem_flatCore
#check ReciprocalCounterexample.mainTheorem_explicit
#check ReciprocalCounterexample.explicitCounterexampleForcing
#check ReciprocalCounterexample.explicitCounterexampleForcing_isCounterexample
#print axioms ReciprocalCounterexample.mainTheorem_explicit
#print axioms ReciprocalCounterexample.explicitCounterexampleForcing_isCounterexample
