# Reciprocal singular equation: complete Lean verification

**The requested counterexample theorem is proved, with a specified smooth
forcing and no remaining analytic hypothesis.** This is version 1.0.0 of the
Lean 4/mathlib verification accompanying the revised paper *A smooth
counterexample for a periodic singular equation at exponent one*.

The checked entry points are:

```lean
ReciprocalCounterexample.explicitCounterexampleForcing_isCounterexample :
  IsCounterexample explicitCounterexampleForcing

ReciprocalCounterexample.mainTheorem_explicit : MainTheorem
ReciprocalCounterexample.mainTheorem_flatCore : MainTheorem
```

`MainTheorem` has its original meaning: there exists a smooth, even,
one-periodic real forcing with both signs and integral minus one for which
`x'' = h / x` has no strictly positive classical periodic solution. The
formal solution structure uses continuous position, velocity and acceleration,
with derivatives within the closed interval. It includes both periodic
boundary conditions and does not assume a global periodic extension of a
candidate solution.

The theorem's axiom dependencies are exactly the standard classical foundations
`propext`, `Classical.choice`, and `Quot.sound`. No custom analytic axiom,
`sorry`, or `native_decide` is used in the proof. The audit checks the compiled
proofs and their full transitive axiom dependencies.

## The specified forcing

The new construction uses the smooth even profile

```text
f(t) = S(4t - 1) + S(-4t - 1),
```

where `S` is the exact exponential smooth step defined in `Forcing.lean`.
This profile vanishes on `[-1/4, 1/4]` and equals one outside `(-1/2, 1/2)`.
Its positive forcing is joined to a short smooth negative pulse, then
periodized. The pulse has total negative mass two.

The parameter is fixed by the formula

```text
D   = flatCoreDerivativeConstant
J   = flatCoreEntropyMoment
eta = 1 / (1000 * (1 + D + J))
eps = eta^2
del = eta^4 / 4096.
```

Here `D` is a fixed positive bound for `|f'|` on `[-1, 1]`, and
`J = integral |f'| |log f|` on that interval. Their existence and finiteness
are proved for this exact profile. `FlatCoreExplicit.lean` proves the required
smallness quantitatively, with error at most `231/1000 < 1/2`.

Let `H = flatCoreRawForcing eps del`, let `T = fullPeriod del`, and let
`M = flatCoreMass eps del > 0`. The named witness is

```text
explicitCounterexampleForcing(t) = (T / M) * H(T * t).
```

`FlatCoreWitness.lean` proves all six properties in `IsCounterexample` for
this function, including nonexistence. The proof of nonexistence is obtained
from estimates on every actual hypothetical positive classical solution.

## Reproduce the verification

The package pins Lean `leanprover/lean4:v4.19.0` and mathlib commit
`c44e0c8ee63ca166450922a373c7409c5d26b00b`. The included Lake manifest also pins
the transitive dependencies. Use that manifest as supplied; a routine
verification does not require `lake update`.

Install Git, the elan Lean toolchain manager, and Python 3. Open a terminal
in the extracted `lean_verification` directory. Internet access is needed for
the initial toolchain, dependency and mathlib cache downloads. The source
archive intentionally excludes downloaded dependencies and compiled binaries.

### Windows PowerShell

```powershell
Set-Location "C:\path\to\lean_verification"
lake exe cache get
py -3 scripts\verify.py
$LASTEXITCODE
```

Use `python` in place of `py -3` if that is how Python 3 is installed. Open a
new PowerShell window after installing elan if `lake` is not yet on `PATH`.
The verifier also accepts an explicit executable path:

```powershell
py -3 scripts\verify.py --lake "C:\path\to\lake.exe"
```

### Linux or macOS

```sh
cd /path/to/lean_verification
lake exe cache get
python3 scripts/verify.py
```

The expected verifier exit code is **0**. The script runs the full aggregate
build and then `Audit.lean`. Exit code 1 means a build or audit failure.
Exit code 2 means that the compiled environment did not supply the required
unconditional theorem or specified witness. The optional `--components-only`
mode checks the components without enforcing that final gate; it is not the
command used to certify the main theorem.

The underlying commands can also be run directly:

```text
lake build
lake env lean Audit.lean
```

## What the audit establishes

`Audit.lean` traverses every compiled project theorem in the aggregate import,
computes its axiom closure, and rejects any dependency outside the three
standard axioms listed above. It then compares complete theorem types with
`MainTheorem` and separately with
`IsCounterexample explicitCounterexampleForcing`. A conditional theorem such
as `P -> MainTheorem` does not pass the exact-type main-theorem check.

`scripts/verify.py` records the names of the actual unconditional proofs and
the specified-forcing proof in `verification_status.json`. It reserves a
successful default result for a completed build, a passing axiom audit, and
the checked main and witness entry points. The exact proposition, rather than
a declaration's name or a source-text claim, determines proof status.

## Proof organization

| Modules | Checked content |
| --- | --- |
| `Definitions`, `Normalization` | Exact boundary-value problem; actual solution rescaling; period and mean normalization |
| `FlatCoreProfile` | Smooth profile with an exact flat central interval; derivative and logarithmic moment regularity |
| `FlatCoreForcing`, `FlatCoreMasses`, `FlatCoreSolution` | Smooth even periodic forcing; exact mass decomposition; extraction of an actual positive bowl from a putative periodic solution |
| `FlatCoreBounds`, `FlatCoreEnergy` | Convexity, normalized parameter bound, FTC identities, logarithmic energy derivative and oscillation |
| `FlatCoreObstruction`, `FlatCoreDefect` | The quantitative flat-core obstruction and the squared-speed error bound |
| `FlatCoreLog`, `FlatCoreSmallLog`, `FlatCoreLogApplication` | Weighted logarithmic estimates applied to actual solutions; the error majorant |
| `SmoothPulseBounds`, `FlatCoreHeight`, `FlatCorePulse` | Global height bound, pulse comparison and small pulse energy; all derived from the classical ODE |
| `FlatCoreParameters`, `FlatCoreExplicit` | Parameter algebra and the specified admissible parameter |
| `FlatCoreMain`, `FlatCoreWitness` | Unconditional nonexistence, a named forcing satisfying the requested properties, and `MainTheorem` |
| `FlatCoreSlope` | An additional uniform slope bound for positive bowls; not needed by the shorter final proof |

The decisive inequality is proved for an actual positive bowl, with
`v = x'`, `K = integral v^2`, `Omega = eps * integral |f'| |log x|`, and
`L = eps * integral f |log x|`:

```text
1/2 <= |x(1) - x(-1)| + |K - 2| + 4*Omega + 4*L.
```

The pulse and logarithmic estimates make its right-hand side less than
`1/2` for the specified parameter. This proves nonexistence directly.
No collision passage map or compactness assumption remains in this argument.

## Earlier sixth-order branch

The older modules, including `Algebra`, `PeriodicForcing`, `CollisionPassage`,
`LogCompactness`, and `MainReduction`, retain checked supporting results for
the previous sixth-order forcing approach. Its separate proposition
`SmoothedNonexistence` is still unproved. That stronger statement concerns a
different forcing family and is neither used nor asserted by the completed
flat-core proof. The audit records its status separately; it is not a missing
premise of `mainTheorem_explicit`.

## Verification evidence

The verifier writes `logs/final-build.log`, `logs/final-axiom-audit.log`, and
`verification_status.json`. The distributed `verification_report.txt` explains
the final scope, while `source_manifest.json` records source and manuscript
fingerprints. These files allow the result to be checked against the exact
sources in the package.
