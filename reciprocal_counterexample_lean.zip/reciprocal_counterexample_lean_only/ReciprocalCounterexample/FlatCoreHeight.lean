import ReciprocalCounterexample.FlatCoreSolution
import ReciprocalCounterexample.FlatCoreMasses

/-!
# A uniform height bound for every actual periodic solution

The kinetic energy is at most two. Its Cauchy--Schwarz oscillation bound,
together with exact positive and negative forcing masses, gives height at
most six on the entire original period and hence on the positive bowl.
-/

noncomputable section
open Set MeasureTheory
open scoped Interval

namespace ReciprocalCounterexample
namespace IsClassicalSolution

variable {eps delta : ℝ} {x v a : ℝ → ℝ}

theorem flatCore_energy_eq_mass
    (hs : IsClassicalSolution (fullPeriod delta) (flatCoreRawForcing eps delta) x v a)
    (hdelta : 0 < delta) :
    (∫ t in (0 : ℝ)..fullPeriod delta, (v t) ^ 2) = flatCoreMass eps delta := by
  have hT : 0 ≤ fullPeriod delta := by unfold fullPeriod halfPeriod; linarith
  have h := hs.energy_identity hT
  rw [flatCoreRawForcing_integral hdelta] at h
  linarith

theorem flatCore_energy_le_two
    (hs : IsClassicalSolution (fullPeriod delta) (flatCoreRawForcing eps delta) x v a)
    (heps : 0 ≤ eps) (hdelta : 0 < delta) :
    (∫ t in (0 : ℝ)..fullPeriod delta, (v t) ^ 2) ≤ 2 := by
  rw [hs.flatCore_energy_eq_mass hdelta]
  exact (flatCoreMass_bounds heps hdelta).2

theorem flatCore_height_le_six
    (hs : IsClassicalSolution (fullPeriod delta) (flatCoreRawForcing eps delta) x v a)
    (heps : 0 ≤ eps) (heps4 : eps ≤ 1 / 4)
    (hdelta : 0 < delta) (hdelta2 : delta ≤ 1 / 2) :
    ∀ t ∈ Icc 0 (fullPeriod delta), x t ≤ 6 := by
  have hT : 0 ≤ fullPeriod delta := by unfold fullPeriod halfPeriod; linarith
  have hT4 : fullPeriod delta ≤ 4 := by unfold fullPeriod halfPeriod; linarith
  have hpmass : (∫ t in (0 : ℝ)..fullPeriod delta, flatCoreRawPositive eps delta t) ≤ 1 := by
    have h := flatCoreRawPositive_integral_le heps hdelta
    have h' := mul_le_mul_of_nonneg_left hT4 heps
    nlinarith
  exact hs.global_height_le_six hT hT4 (hs.flatCore_energy_le_two heps hdelta)
    (flatCoreRawPositive_continuous eps delta).continuousOn
    (flatCoreRawNegative_continuous delta).continuousOn
    (fun t _ => flatCoreRawPositive_nonneg heps hdelta t)
    (fun t _ => flatCoreRawNegative_nonneg hdelta t)
    (fun t ht => flatCoreRawForcing_decomposition hdelta ht)
    hpmass (flatCoreRawNegative_integral hdelta)

theorem flatCore_bowl_height_le_six
    (hs : IsClassicalSolution (fullPeriod delta) (flatCoreRawForcing eps delta) x v a)
    (heps : 0 ≤ eps) (heps4 : eps ≤ 1 / 4)
    (hdelta : 0 < delta) (hdelta2 : delta ≤ 1 / 2) :
    ∀ t ∈ Icc (-1 : ℝ) 1, x (halfPeriod delta + t) ≤ 6 := by
  intro t ht
  exact hs.flatCore_height_le_six heps heps4 hdelta hdelta2 _ (flatCore_bowl_time_mem hdelta ht)

/-- Removing the pulse kinetic energy from the exact global identity leaves
the bowl kinetic energy within positive mass plus pulse energy of two. -/
theorem flatCore_bowl_kinetic_defect_le
    (hs : IsClassicalSolution (fullPeriod delta) (flatCoreRawForcing eps delta) x v a)
    {Q : ℝ} (heps : 0 ≤ eps) (hdelta : 0 < delta)
    (hpulse : pulseIntegral (fullPeriod delta) (halfPeriod delta - 1) (halfPeriod delta + 1)
      (fun t => (v t) ^ 2) ≤ Q) :
    |(∫ t in (-1 : ℝ)..1, (v (halfPeriod delta + t)) ^ 2) - 2| ≤
      eps * fullPeriod delta + Q := by
  have hl : 0 ≤ halfPeriod delta - 1 := by unfold halfPeriod; linarith
  have hlr : halfPeriod delta - 1 ≤ halfPeriod delta + 1 := by linarith
  have hr : halfPeriod delta + 1 ≤ fullPeriod delta := by unfold fullPeriod halfPeriod; linarith
  have hsplit := hs.kinetic_energy_split hl hlr hr
  rw [hs.flatCore_energy_eq_mass hdelta] at hsplit
  have hshift : (∫ t in (-1 : ℝ)..1, (v (halfPeriod delta + t)) ^ 2) =
      ∫ t in (halfPeriod delta - 1)..(halfPeriod delta + 1), (v t) ^ 2 := by
    simpa only [sub_eq_add_neg] using
      (intervalIntegral.integral_comp_add_left (fun t => (v t) ^ 2)
        (a := (-1 : ℝ)) (b := 1) (halfPeriod delta))
  rw [← hshift] at hsplit
  have hpnonneg : 0 ≤ pulseIntegral (fullPeriod delta)
      (halfPeriod delta - 1) (halfPeriod delta + 1) (fun t => (v t) ^ 2) :=
    pulseIntegral_nonneg hl hr (fun t _ => sq_nonneg _)
  have hm := flatCoreMass_bounds heps hdelta
  rw [abs_of_nonpos (by linarith :
    (∫ t in (-1 : ℝ)..1, (v (halfPeriod delta + t)) ^ 2) - 2 ≤ 0)]
  linarith

end IsClassicalSolution

#print axioms IsClassicalSolution.flatCore_height_le_six
#print axioms IsClassicalSolution.flatCore_bowl_height_le_six
#print axioms IsClassicalSolution.flatCore_bowl_kinetic_defect_le

end ReciprocalCounterexample
