import ReciprocalCounterexample.Forcing
import Mathlib.Algebra.BigOperators.Finprod
import Mathlib.Algebra.Ring.Periodic
import Mathlib.Data.Real.Archimedean
import Mathlib.Data.Int.Interval

/-!
# Exact smooth even periodic extension of the forcing

The even extension is written as a sum of smooth functions, avoiding an
absolute-value cusp.  A compactly supported offset is then repeated by a
locally finite integer sum.  The resulting function agrees exactly with
the manuscript's reflected profile on its fundamental interval.
-/

noncomputable section

open scoped ContDiff Topology
open MeasureTheory Set Filter Function

namespace ReciprocalCounterexample

def fullPeriod (δ : ℝ) : ℝ := 2 * halfPeriod δ

/-- A smooth formula for even reflection, without using absolute value. -/
def evenForcing (ε δ s : ℝ) : ℝ :=
  halfForcing ε δ s + halfForcing ε δ (-s) - ε * s ^ 6

theorem evenForcing_contDiff (ε δ : ℝ) : ContDiff ℝ ∞ (evenForcing ε δ) := by
  unfold evenForcing
  exact ((halfForcing_contDiff ε δ).add
    ((halfForcing_contDiff ε δ).comp contDiff_id.neg)).sub
      (contDiff_const.mul (contDiff_id.pow 6))

theorem evenForcing_even (ε δ s : ℝ) : evenForcing ε δ (-s) = evenForcing ε δ s := by
  simp only [evenForcing, neg_neg]
  ring

theorem evenForcing_eq_halfForcing (ε δ s : ℝ) (hδ : 0 < δ) (hs : 0 ≤ s) :
    evenForcing ε δ s = halfForcing ε δ s := by
  rw [evenForcing, halfForcing_eq_bowl ε δ (-s) hδ (by linarith)]
  ring

theorem halfForcing_constant_after (ε δ s : ℝ) (hδ : 0 < δ) (hs : halfPeriod δ ≤ s) :
    halfForcing ε δ s = -(2 / δ) := by
  have h₁ : 1 ≤ (s - 1) / δ := (le_div_iff₀ hδ).2 (by unfold halfPeriod at hs; linarith)
  have h₂ : 1 ≤ (s - 1 - δ) / δ :=
    (le_div_iff₀ hδ).2 (by unfold halfPeriod at hs; linarith)
  simp [halfForcing, positiveProfile, negativePulse,
    smoothStep_one_of_one_le h₁, smoothStep_one_of_one_le h₂]

theorem evenForcing_constant_outside (ε δ s : ℝ) (hδ : 0 < δ)
    (hs : halfPeriod δ ≤ |s|) : evenForcing ε δ s = -(2 / δ) := by
  by_cases hsign : 0 ≤ s
  · rw [abs_of_nonneg hsign] at hs
    rw [evenForcing_eq_halfForcing ε δ s hδ hsign]
    exact halfForcing_constant_after ε δ s hδ hs
  · have hsneg : 0 ≤ -s := by linarith
    rw [abs_of_neg (lt_of_not_ge hsign)] at hs
    rw [← evenForcing_even ε δ s, evenForcing_eq_halfForcing ε δ (-s) hδ hsneg]
    exact halfForcing_constant_after ε δ (-s) hδ hs

/-- The compactly supported function used for periodization. -/
def forcingBump (ε δ s : ℝ) : ℝ := evenForcing ε δ s + 2 / δ

theorem forcingBump_contDiff (ε δ : ℝ) : ContDiff ℝ ∞ (forcingBump ε δ) :=
  (evenForcing_contDiff ε δ).add contDiff_const

theorem forcingBump_even (ε δ s : ℝ) : forcingBump ε δ (-s) = forcingBump ε δ s := by
  simp [forcingBump, evenForcing_even]

theorem forcingBump_zero_outside (ε δ s : ℝ) (hδ : 0 < δ)
    (hs : halfPeriod δ ≤ |s|) : forcingBump ε δ s = 0 := by
  rw [forcingBump, evenForcing_constant_outside ε δ s hδ hs]
  ring

theorem forcingBump_nonzero_implies (ε δ s : ℝ) (hδ : 0 < δ)
    (hs : forcingBump ε δ s ≠ 0) : |s| < halfPeriod δ := by
  by_contra hn
  exact hs (forcingBump_zero_outside ε δ s hδ (le_of_not_gt hn))

/-- Exact periodization of the compactly supported offset. -/
def periodicForcing (ε δ s : ℝ) : ℝ :=
  (∑ᶠ n : ℤ, forcingBump ε δ (s + n * fullPeriod δ)) - 2 / δ

theorem periodicForcing_periodic (ε δ : ℝ) :
    Function.Periodic (periodicForcing ε δ) (fullPeriod δ) := by
  intro s
  unfold periodicForcing
  congr 1
  apply finsum_eq_of_bijective (fun n : ℤ => n + 1) (Equiv.addRight (1 : ℤ)).bijective
  intro n
  congr 1
  push_cast
  ring

theorem periodicForcing_even (ε δ s : ℝ) :
    periodicForcing ε δ (-s) = periodicForcing ε δ s := by
  unfold periodicForcing
  congr 1
  apply finsum_eq_of_bijective (fun n : ℤ => -n) (Equiv.neg ℤ).bijective
  intro n
  rw [show -s + (n : ℝ) * fullPeriod δ = -(s + (-n : ℤ) * fullPeriod δ) by
    push_cast; ring]
  exact forcingBump_even ε δ _

theorem forcingBump_shift_zero (ε δ s : ℝ) (hδ : 0 < δ)
    (hs : s ∈ Icc (-halfPeriod δ) (halfPeriod δ)) (n : ℤ) (hn : n ≠ 0) :
    forcingBump ε δ (s + n * fullPeriod δ) = 0 := by
  have hL : 0 < halfPeriod δ := by unfold halfPeriod; linarith
  apply forcingBump_zero_outside ε δ _ hδ
  rcases lt_or_gt_of_ne hn with hneg | hpos
  · have hn₁ : (n : ℝ) ≤ -1 := by exact_mod_cast (show n ≤ -1 by omega)
    have hfar : s + n * fullPeriod δ ≤ -halfPeriod δ := by
      unfold fullPeriod
      nlinarith [hs.2]
    exact (by linarith : halfPeriod δ ≤ -(s + n * fullPeriod δ)).trans (neg_le_abs _)
  · have hn₁ : (1 : ℝ) ≤ n := by exact_mod_cast (show 1 ≤ n by omega)
    have hfar : halfPeriod δ ≤ s + n * fullPeriod δ := by
      unfold fullPeriod
      nlinarith [hs.1]
    exact hfar.trans (le_abs_self _)

theorem periodicForcing_eq_evenForcing (ε δ s : ℝ) (hδ : 0 < δ)
    (hs : s ∈ Icc (-halfPeriod δ) (halfPeriod δ)) :
    periodicForcing ε δ s = evenForcing ε δ s := by
  unfold periodicForcing
  rw [finsum_eq_single _ (0 : ℤ) (fun n hn => forcingBump_shift_zero ε δ s hδ hs n hn)]
  simp [forcingBump]

theorem periodicForcing_eq_halfForcing (ε δ s : ℝ) (hδ : 0 < δ)
    (hs : s ∈ Icc (0 : ℝ) (halfPeriod δ)) :
    periodicForcing ε δ s = halfForcing ε δ s := by
  rw [periodicForcing_eq_evenForcing ε δ s hδ ⟨by
    unfold halfPeriod
    linarith [hs.1], hs.2⟩]
  exact evenForcing_eq_halfForcing ε δ s hδ hs.1

/-- Locally finite periodization preserves smoothness.  The finite sum
representing the function near each point is constructed explicitly. -/
theorem contDiff_finsum_int_translate (g : ℝ → ℝ) (hg : ContDiff ℝ ∞ g)
    (L T : ℝ) (hT : 0 < T) (hzero : ∀ s, L ≤ |s| → g s = 0) :
    ContDiff ℝ ∞ (fun s => ∑ᶠ n : ℤ, g (s + n * T)) := by
  classical
  rw [contDiff_iff_contDiffAt]
  intro x
  let a : ℤ := ⌊(-L - x - 1) / T⌋
  let b : ℤ := ⌈(L - x + 1) / T⌉
  let I : Finset ℤ := Finset.Icc a b
  have hfinite : ∀ y ∈ Ioo (x - 1) (x + 1),
      (∑ᶠ n : ℤ, g (y + n * T)) = ∑ n ∈ I, g (y + n * T) := by
    intro y hy
    apply finsum_eq_sum_of_support_subset
    intro n hn
    have hnz : g (y + n * T) ≠ 0 := hn
    have habs : |y + n * T| < L := by
      by_contra h
      exact hnz (hzero _ (le_of_not_gt h))
    have hbounds := abs_lt.mp habs
    have hlo : (a : ℝ) ≤ n := by
      exact (Int.floor_le _).trans ((div_le_iff₀ hT).2 (by linarith [hbounds.1, hy.2]))
    have hhi : (n : ℝ) ≤ b := by
      exact ((le_div_iff₀ hT).2 (by linarith [hbounds.2, hy.1])).trans (Int.le_ceil _)
    change n ∈ Finset.Icc a b
    rw [Finset.mem_Icc]
    constructor
    · exact_mod_cast hlo
    · exact_mod_cast hhi
  have hsmooth : ContDiff ℝ ∞ (fun y => ∑ n ∈ I, g (y + n * T)) := by
    apply ContDiff.sum
    intro n _
    exact hg.comp (contDiff_id.add contDiff_const)
  apply hsmooth.contDiffAt.congr_of_eventuallyEq
  filter_upwards [Ioo_mem_nhds (by linarith : x - 1 < x) (by linarith : x < x + 1)] with y hy
  exact hfinite y hy

theorem periodicForcing_contDiff (ε δ : ℝ) (hδ : 0 < δ) :
    ContDiff ℝ ∞ (periodicForcing ε δ) := by
  have hT : 0 < fullPeriod δ := by unfold fullPeriod halfPeriod; linarith
  exact (contDiff_finsum_int_translate (forcingBump ε δ) (forcingBump_contDiff ε δ)
    (halfPeriod δ) (fullPeriod δ) hT (fun s hs => forcingBump_zero_outside ε δ s hδ hs)).sub
      contDiff_const

theorem periodicForcing_reflection (ε δ s : ℝ) :
    periodicForcing ε δ (fullPeriod δ - s) = periodicForcing ε δ s := by
  rw [show fullPeriod δ - s = -s + fullPeriod δ by ring,
    periodicForcing_periodic ε δ, periodicForcing_even]

theorem periodicForcing_integral_halfPeriod (ε δ : ℝ) (hδ : 0 < δ) :
    (∫ s in (0 : ℝ)..halfPeriod δ, periodicForcing ε δ s) =
      ∫ s in (0 : ℝ)..halfPeriod δ, halfForcing ε δ s := by
  apply intervalIntegral.integral_congr
  intro s hs
  rw [uIcc_of_le (by unfold halfPeriod; linarith : (0 : ℝ) ≤ halfPeriod δ)] at hs
  exact periodicForcing_eq_halfForcing ε δ s hδ hs

theorem periodicForcing_integral_fullPeriod (ε δ : ℝ) (hδ : 0 < δ) :
    (∫ s in (0 : ℝ)..fullPeriod δ, periodicForcing ε δ s) =
      2 * ∫ s in (0 : ℝ)..halfPeriod δ, halfForcing ε δ s := by
  have hTminusL : fullPeriod δ - halfPeriod δ = halfPeriod δ := by
    unfold fullPeriod
    ring
  have hreflect := intervalIntegral.integral_comp_sub_left (periodicForcing ε δ)
    (fullPeriod δ) (a := (0 : ℝ)) (b := halfPeriod δ)
  simp only [periodicForcing_reflection, hTminusL, sub_zero] at hreflect
  have hI (a b : ℝ) : IntervalIntegrable (periodicForcing ε δ) volume a b :=
    (periodicForcing_contDiff ε δ hδ).continuous.intervalIntegrable a b
  rw [← intervalIntegral.integral_add_adjacent_intervals (hI 0 (halfPeriod δ))
    (hI (halfPeriod δ) (fullPeriod δ)), ← hreflect,
    periodicForcing_integral_halfPeriod ε δ hδ]
  ring

theorem periodicForcing_integral_negative (ε δ : ℝ)
    (hε : 0 ≤ ε) (hεsmall : ε < 1 / 128) (hδ : 0 < δ) (hδsmall : δ ≤ 1 / 2) :
    (∫ s in (0 : ℝ)..fullPeriod δ, periodicForcing ε δ s) < 0 := by
  rw [periodicForcing_integral_fullPeriod ε δ hδ]
  have h := halfForcing_integral_negative ε δ hε hεsmall hδ hδsmall
  linarith

theorem periodicForcing_sign_change_on (ε δ : ℝ) (hε : 0 < ε) (hδ : 0 < δ) :
    (∃ s ∈ Icc (0 : ℝ) (fullPeriod δ), periodicForcing ε δ s < 0) ∧
    (∃ s ∈ Icc (0 : ℝ) (fullPeriod δ), 0 < periodicForcing ε δ s) := by
  have hL : 0 < halfPeriod δ := by unfold halfPeriod; linarith
  have hLone : 1 ≤ halfPeriod δ := by unfold halfPeriod; linarith
  constructor
  · refine ⟨halfPeriod δ, ⟨hL.le, ?_⟩, ?_⟩
    · unfold fullPeriod
      linarith
    · rw [periodicForcing_eq_halfForcing ε δ (halfPeriod δ) hδ ⟨hL.le, le_rfl⟩]
      exact halfForcing_negative_at_halfPeriod ε δ hδ
  · refine ⟨1, ⟨by norm_num, ?_⟩, ?_⟩
    · unfold fullPeriod
      linarith
    · rw [periodicForcing_eq_halfForcing ε δ 1 hδ ⟨by norm_num, hLone⟩]
      exact halfForcing_pos_on_bowl ε δ 1 hε hδ (by norm_num) le_rfl

/-- The factor `A_δ` printed in equation (2.3). -/
def positiveMassFactor (δ : ℝ) : ℝ :=
  ∫ s in (0 : ℝ)..(1 + δ), s ^ 6 * (1 - smoothStep ((s - 1) / δ))

/-- The positive normalization factor `M_{ε,δ}` in the manuscript. -/
def forcingMass (ε δ : ℝ) : ℝ := 2 * (1 - ε * positiveMassFactor δ)

theorem positiveProfile_zero_after (ε δ s : ℝ) (hδ : 0 < δ) (hs : 1 + δ ≤ s) :
    positiveProfile ε δ s = 0 := by
  have harg : 1 ≤ (s - 1) / δ := (le_div_iff₀ hδ).2 (by linarith)
  simp [positiveProfile, smoothStep_one_of_one_le harg]

theorem positiveProfile_integral_exact (ε δ : ℝ) (hδ : 0 < δ) :
    (∫ s in (0 : ℝ)..halfPeriod δ, positiveProfile ε δ s) = ε * positiveMassFactor δ := by
  have hI (a b : ℝ) : IntervalIntegrable (positiveProfile ε δ) volume a b :=
    (positiveProfile_contDiff ε δ).continuous.intervalIntegrable a b
  have htail : (∫ s in (1 + δ)..halfPeriod δ, positiveProfile ε δ s) = 0 := by
    calc
      (∫ s in (1 + δ)..halfPeriod δ, positiveProfile ε δ s) =
          ∫ _s in (1 + δ)..halfPeriod δ, (0 : ℝ) := by
        apply intervalIntegral.integral_congr
        intro s hs
        rw [uIcc_of_le (by unfold halfPeriod; linarith : 1 + δ ≤ halfPeriod δ)] at hs
        exact positiveProfile_zero_after ε δ s hδ hs.1
      _ = 0 := by simp
  rw [← intervalIntegral.integral_add_adjacent_intervals (hI 0 (1 + δ))
    (hI (1 + δ) (halfPeriod δ)), htail, add_zero]
  simp only [positiveProfile, positiveMassFactor, mul_assoc, intervalIntegral.integral_const_mul]

theorem periodicForcing_integral_eq_neg_mass (ε δ : ℝ) (hδ : 0 < δ) :
    (∫ s in (0 : ℝ)..fullPeriod δ, periodicForcing ε δ s) = -forcingMass ε δ := by
  rw [periodicForcing_integral_fullPeriod ε δ hδ]
  unfold halfForcing
  rw [intervalIntegral.integral_sub
    ((positiveProfile_contDiff ε δ).continuous.intervalIntegrable 0 (halfPeriod δ))
    ((negativePulse_contDiff δ).continuous.intervalIntegrable 0 (halfPeriod δ)),
    positiveProfile_integral_exact ε δ hδ, negativePulse_integral_halfPeriod δ hδ]
  unfold forcingMass
  ring

theorem forcingMass_positive (ε δ : ℝ)
    (hε : 0 ≤ ε) (hεsmall : ε < 1 / 128) (hδ : 0 < δ) (hδsmall : δ ≤ 1 / 2) :
    0 < forcingMass ε δ := by
  have h := periodicForcing_integral_negative ε δ hε hεsmall hδ hδsmall
  rw [periodicForcing_integral_eq_neg_mass ε δ hδ] at h
  linarith

end ReciprocalCounterexample

#print axioms ReciprocalCounterexample.evenForcing_contDiff
#print axioms ReciprocalCounterexample.periodicForcing_periodic
#print axioms ReciprocalCounterexample.periodicForcing_even
#print axioms ReciprocalCounterexample.periodicForcing_eq_halfForcing
#print axioms ReciprocalCounterexample.contDiff_finsum_int_translate
#print axioms ReciprocalCounterexample.periodicForcing_contDiff
#print axioms ReciprocalCounterexample.periodicForcing_integral_fullPeriod
#print axioms ReciprocalCounterexample.periodicForcing_integral_negative
#print axioms ReciprocalCounterexample.periodicForcing_sign_change_on
#print axioms ReciprocalCounterexample.periodicForcing_integral_eq_neg_mass
#print axioms ReciprocalCounterexample.forcingMass_positive
