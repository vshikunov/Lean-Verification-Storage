import ReciprocalCounterexample.FlatCoreEnergy
import ReciprocalCounterexample.FlatCoreProfile

/-!
# Quantitative flat-core obstruction for positive ODE solutions

The weighted logarithmic integrals control the L1 error of the squared speed.
Combining this with the flat interval gives a numerical obstruction directly,
without extracting a collision limit or assuming a collision passage map.
-/
noncomputable section
open Set MeasureTheory
open scoped Interval

namespace ReciprocalCounterexample
namespace PositiveBowl
variable {ε : ℝ} {f fp x v a : ℝ → ℝ}

/-- Exact signed mean energy, with no normalization of the heights. -/
theorem energy_integral_signed (hs : PositiveBowl ε f x v a)
    (hf : ContinuousOn f (Icc (-1 : ℝ) 1)) :
    (∫ t in (-1 : ℝ)..1, profileEnergy ε f x v t) =
      (∫ t in (-1 : ℝ)..1, (v t)^2) / 2 -
      ε * (∫ t in (-1 : ℝ)..1, f t * Real.log (x t)) := by
  unfold profileEnergy
  rw [intervalIntegral.integral_sub
    (((hs.continuous_v.pow 2).div_const 2).intervalIntegrable_of_Icc (by norm_num))
    (((continuousOn_const.mul hf).mul hs.continuous_log).intervalIntegrable_of_Icc
      (by norm_num)), intervalIntegral.integral_div]
  congr 1
  rw [← intervalIntegral.integral_const_mul]
  apply intervalIntegral.integral_congr
  intro t _
  ring

/-- Control of the signed logarithmic integral by its absolute counterpart. -/
theorem abs_profile_log_integral_le (hs : PositiveBowl ε f x v a)
    (hε : 0 ≤ ε) (hf0 : ∀ t ∈ Icc (-1 : ℝ) 1, 0 ≤ f t) :
    |ε * (∫ t in (-1 : ℝ)..1, f t * Real.log (x t))| ≤
      ε * (∫ t in (-1 : ℝ)..1, f t * |Real.log (x t)|) := by
  rw [← intervalIntegral.integral_const_mul, ← intervalIntegral.integral_const_mul]
  calc
    |∫ t in (-1 : ℝ)..1, ε * (f t * Real.log (x t))| ≤
        ∫ t in (-1 : ℝ)..1, |ε * (f t * Real.log (x t))| :=
      intervalIntegral.abs_integral_le_integral_abs (by norm_num)
    _ = ∫ t in (-1 : ℝ)..1, ε * (f t * |Real.log (x t)|) := by
      apply intervalIntegral.integral_congr
      intro t ht
      dsimp only
      rw [abs_mul, abs_mul, abs_of_nonneg hε,
        abs_of_nonneg (hf0 t (by simpa using ht))]

/-- The full squared-speed error follows from the actual energy oscillation,
its kinetic mean, and the logarithmic correction. -/
theorem square_speed_defect_bound (hs : PositiveBowl ε f x v a)
    (hε : 0 ≤ ε)
    (hf0 : ∀ t ∈ Icc (-1 : ℝ) 1, 0 ≤ f t)
    (hf : ContinuousOn f (Icc (-1 : ℝ) 1))
    (hfp : ContinuousOn fp (Icc (-1 : ℝ) 1))
    (hdf : ∀ t ∈ Icc (-1 : ℝ) 1, HasDerivAt f (fp t) t) :
    (∫ t in (-1 : ℝ)..1, |(v t)^2 - 1|) ≤
      |(∫ t in (-1 : ℝ)..1, (v t)^2) - 2| +
      4 * (ε * (∫ t in (-1 : ℝ)..1, |fp t| * |Real.log (x t)|)) +
      4 * (ε * (∫ t in (-1 : ℝ)..1, f t * |Real.log (x t)|)) := by
  let K : ℝ := ∫ t in (-1 : ℝ)..1, (v t)^2
  let L : ℝ := ε * (∫ t in (-1 : ℝ)..1, f t * |Real.log (x t)|)
  let Ω : ℝ := ε * (∫ t in (-1 : ℝ)..1, |fp t| * |Real.log (x t)|)
  have hmean : |bowlAverage (profileEnergy ε f x v) - 1/2| ≤ |K - 2| / 4 + L / 2 := by
    have hE := hs.energy_integral_signed hf
    have hJ := abs_le.mp (hs.abs_profile_log_integral_le hε hf0)
    have hK := abs_le.mp (le_refl |K - 2|)
    dsimp [bowlAverage]
    rw [hE]
    apply abs_le.mpr
    dsimp [K, L] at hK ⊢
    constructor <;> linarith only [hJ.1, hJ.2, hK.1, hK.2]
  have hosc : ∀ s ∈ Icc (-1 : ℝ) 1, ∀ t ∈ Icc (-1 : ℝ) 1,
      |profileEnergy ε f x v s - profileEnergy ε f x v t| ≤ Ω :=
    fun s hs' t ht => hs.energy_oscillation hε hf hfp hdf hs' ht
  have hpoint : ∀ t ∈ Icc (-1 : ℝ) 1,
      |(v t)^2 - 1| ≤ (2 * Ω + |K - 2| / 2 + L) +
        2 * ε * (f t * |Real.log (x t)|) := by
    intro t ht
    have he := energy_distance_le (hs.continuous_energy hf) hosc (c := 1/2) ht
    have hsplit : (v t)^2 - 1 =
        2 * (profileEnergy ε f x v t - 1/2) + 2 * ε * (f t * Real.log (x t)) := by
      dsimp [profileEnergy]
      ring
    calc
      |(v t)^2 - 1| = |2 * (profileEnergy ε f x v t - 1/2) +
          2 * ε * (f t * Real.log (x t))| := congrArg abs hsplit
      _ ≤ |2 * (profileEnergy ε f x v t - 1/2)| +
          |2 * ε * (f t * Real.log (x t))| := abs_add _ _
      _ = 2 * |profileEnergy ε f x v t - 1/2| +
          2 * ε * (f t * |Real.log (x t)|) := by
        rw [abs_mul, abs_mul, abs_mul, abs_mul, abs_of_nonneg hε,
          abs_of_nonneg (hf0 t ht)]
        norm_num
      _ ≤ (2 * Ω + |K - 2| / 2 + L) + 2 * ε * (f t * |Real.log (x t)|) := by
        linarith only [he, hmean]
  have hJcont : ContinuousOn (fun t => f t * |Real.log (x t)|) (Icc (-1 : ℝ) 1) :=
    hf.mul hs.continuous_log.abs
  have hint := intervalIntegral.integral_mono_on (μ := volume) (by norm_num : (-1 : ℝ) ≤ 1)
    (((hs.continuous_v.pow 2).sub continuousOn_const).abs.intervalIntegrable_of_Icc (by norm_num))
    ((continuousOn_const.add (continuousOn_const.mul hJcont)).intervalIntegrable_of_Icc
      (by norm_num)) hpoint
  rw [intervalIntegral.integral_add intervalIntegrable_const
    ((continuousOn_const.mul hJcont).intervalIntegrable_of_Icc (by norm_num)),
    intervalIntegral.integral_const, intervalIntegral.integral_const_mul] at hint
  norm_num [smul_eq_mul] at hint
  dsimp [K, L, Ω] at hint
  linarith only [hint]

/-- Every positive flat-core bowl satisfies this numerical inequality. Thus
small endpoint mismatch, kinetic error, and weighted logarithmic integrals
are incompatible with an actual solution. -/
theorem flat_core_necessary_inequality (hs : PositiveBowl ε flatCoreProfile x v a)
    (hε : 0 ≤ ε) :
    (1 : ℝ) / 2 ≤ |x 1 - x (-1)| +
      |(∫ t in (-1 : ℝ)..1, (v t)^2) - 2| +
      4 * (ε * (∫ t in (-1 : ℝ)..1, |deriv flatCoreProfile t| * |Real.log (x t)|)) +
      4 * (ε * (∫ t in (-1 : ℝ)..1, flatCoreProfile t * |Real.log (x t)|)) := by
  have hvflat : v (1/4) = v (-1/4) := hs.velocity_eq_of_forcing_zero
    (by norm_num) (by norm_num) (by norm_num) (by
      intro t ht
      apply flatCoreProfile_zero_of_abs_le_quarter
      apply abs_le.mpr
      constructor <;> linarith [ht.1, ht.2])
  have hob := flatCore_obstruction (a := 1/4) (by norm_num) (by norm_num)
    hs.continuous_v (hs.velocity_monotone hε (fun t _ => flatCoreProfile_nonneg t))
    (by simpa only [neg_div] using hvflat.symm)
  have hdef := hs.square_speed_defect_bound hε (fun t _ => flatCoreProfile_nonneg t)
    flatCoreProfile_contDiff.continuous.continuousOn
    (flatCoreProfile_contDiff.continuous_deriv (by simp)).continuousOn
    (fun t _ => (flatCoreProfile_contDiff.differentiable (by simp) t).hasDerivAt)
  rw [hs.integral_velocity] at hob
  linarith only [hob, hdef]

end PositiveBowl
#print axioms PositiveBowl.square_speed_defect_bound
#print axioms PositiveBowl.flat_core_necessary_inequality
end ReciprocalCounterexample
