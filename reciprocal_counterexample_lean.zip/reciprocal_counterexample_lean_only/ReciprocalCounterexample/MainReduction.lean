import ReciprocalCounterexample.Normalization
import ReciprocalCounterexample.PeriodicForcing
import Mathlib.Tactic.Linarith

/-!
# The earlier sixth-order family and its separate nonexistence obligation

This is the legacy sixth-order branch. The original existential MainTheorem
is now proved independently in FlatCoreMain.lean using the flat-core family.
The forcing properties below are proved unconditionally for an explicit parameter
range. `main_of_smoothedNonexistence` is ONLY A CONDITIONAL THEOREM: its argument
`hno` is the unproved analytic conclusion of manuscript Sections 3--6.
No axiom or theorem asserting `SmoothedNonexistence` is introduced here.
-/

noncomputable section
open Set MeasureTheory
open scoped Interval ContDiff

namespace ReciprocalCounterexample

def candidateForcing (ε δ : ℝ) : ℝ → ℝ :=
  normalizedForcing (fullPeriod δ) (forcingMass ε δ) (periodicForcing ε δ)

theorem fullPeriod_positive {δ : ℝ} (hδ : 0 < δ) : 0 < fullPeriod δ := by
  unfold fullPeriod halfPeriod
  linarith

/-- All forcing hypotheses in the question are verified for the concrete
family. The range here ensures the mean normalization, not nonexistence. -/
theorem candidateForcing_properties (ε δ : ℝ)
    (hε : 0 < ε) (hεsmall : ε < 1 / 128)
    (hδ : 0 < δ) (hδsmall : δ ≤ 1 / 2) :
    ContDiff ℝ ∞ (candidateForcing ε δ) ∧
    Function.Periodic (candidateForcing ε δ) 1 ∧
    (∀ t, candidateForcing ε δ (-t) = candidateForcing ε δ t) ∧
    ChangesSignOn 1 (candidateForcing ε δ) ∧
    (∫ t in (0 : ℝ)..1, candidateForcing ε δ t) = -1 := by
  have hT := fullPeriod_positive hδ
  have hM := forcingMass_positive ε δ hε.le hεsmall hδ hδsmall
  exact ⟨normalized_contDiff (periodicForcing_contDiff ε δ hδ),
    normalized_periodic (periodicForcing_periodic ε δ),
    normalized_even (periodicForcing_even ε δ),
    normalized_changesSign hT hM (periodicForcing_sign_change_on ε δ hε hδ),
    normalized_mean (ne_of_gt hT) (ne_of_gt hM)
      (periodicForcing_integral_eq_neg_mass ε δ hδ)⟩

/-- Conditional transfer for the exact family. `hno` has NOT been proved. -/
theorem candidateForcing_isCounterexample_of_raw_nonexistence (ε δ : ℝ)
    (hε : 0 < ε) (hεsmall : ε < 1 / 128)
    (hδ : 0 < δ) (hδsmall : δ ≤ 1 / 2)
    (hno : ¬ HasPositivePeriodicSolution (fullPeriod δ) (periodicForcing ε δ)) :
    IsCounterexample (candidateForcing ε δ) := by
  exact normalized_isCounterexample (fullPeriod_positive hδ)
    (forcingMass_positive ε δ hε.le hεsmall hδ hδsmall)
    (periodicForcing_contDiff ε δ hδ) (periodicForcing_periodic ε δ)
    (periodicForcing_even ε δ) (periodicForcing_sign_change_on ε δ hε hδ)
    (periodicForcing_integral_eq_neg_mass ε δ hδ) hno

/-- The remaining analytic statement, with the exact ordered quantifiers from
the manuscript. This is a proposition definition, NOT an assumed axiom. -/
def SmoothedNonexistence : Prop :=
  ∃ ε₀ : ℝ, 0 < ε₀ ∧ ∀ ε : ℝ, 0 < ε → ε < ε₀ →
    ∃ δ₀ : ℝ, 0 < δ₀ ∧ ∀ δ : ℝ, 0 < δ → δ < δ₀ →
      ¬ HasPositivePeriodicSolution (fullPeriod δ) (periodicForcing ε δ)

/-- The main theorem follows IF the singular analytic nonexistence statement
is supplied. This theorem does not supply that statement. -/
theorem main_of_smoothedNonexistence (hno : SmoothedNonexistence) : MainTheorem := by
  obtain ⟨ε₀, hε₀, hεall⟩ := hno
  let ε : ℝ := min (ε₀ / 2) (1 / 256)
  have hε : 0 < ε := lt_min (half_pos hε₀) (by norm_num)
  have hεle : ε ≤ ε₀ / 2 := min_le_left _ _
  have hεsmall : ε < 1 / 128 := lt_of_le_of_lt (min_le_right _ _) (by norm_num)
  have hεε₀ : ε < ε₀ := by linarith
  obtain ⟨δ₀, hδ₀, hδall⟩ := hεall ε hε hεε₀
  let δ : ℝ := min (δ₀ / 2) (1 / 4)
  have hδ : 0 < δ := lt_min (half_pos hδ₀) (by norm_num)
  have hδle : δ ≤ δ₀ / 2 := min_le_left _ _
  have hδsmall : δ ≤ 1 / 2 := le_trans (min_le_right _ _) (by norm_num)
  have hδδ₀ : δ < δ₀ := by linarith
  exact ⟨candidateForcing ε δ,
    candidateForcing_isCounterexample_of_raw_nonexistence ε δ
      hε hεsmall hδ hδsmall (hδall δ hδ hδδ₀)⟩

#print axioms candidateForcing_properties
#print axioms candidateForcing_isCounterexample_of_raw_nonexistence
#print axioms main_of_smoothedNonexistence
#check main_of_smoothedNonexistence
end ReciprocalCounterexample
