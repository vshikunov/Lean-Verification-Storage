import Mathlib.MeasureTheory.Integral.IntervalIntegral.Basic
import Mathlib.Topology.MetricSpace.Pseudo.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum

/-!
# From oscillation and average control to uniform energy convergence

This file proves the final uniform-convergence step of the energy argument.
The hypotheses controlling oscillation and mean are explicit. In particular,
it does NOT assert the manuscript's weighted Jensen bound or derive these
hypotheses for the singular family of solutions.
-/
noncomputable section
open Set MeasureTheory Filter
open scoped Interval Topology

namespace ReciprocalCounterexample

def bowlAverage (E : ℝ → ℝ) : ℝ := (∫ t in (-1 : ℝ)..1, E t) / 2

theorem distance_bowlAverage_le {E : ℝ → ℝ} {ω t : ℝ}
    (hE : ContinuousOn E (Icc (-1 : ℝ) 1))
    (hω : ∀ s ∈ Icc (-1 : ℝ) 1, ∀ t ∈ Icc (-1 : ℝ) 1,
      |E s - E t| ≤ ω)
    (ht : t ∈ Icc (-1 : ℝ) 1) : |E t - bowlAverage E| ≤ ω := by
  have hbound : ‖∫ s in (-1 : ℝ)..1, E s - E t‖ ≤ ω * |(1 : ℝ) - (-1)| := by
    apply intervalIntegral.norm_integral_le_of_norm_le_const
    intro s hs
    rw [uIoc_of_le (by norm_num : (-1 : ℝ) ≤ 1)] at hs
    simpa only [Real.norm_eq_abs] using hω s (mem_Icc_of_Ioc hs) t ht
  rw [intervalIntegral.integral_sub
    (hE.intervalIntegrable_of_Icc (by norm_num)) intervalIntegrable_const,
    intervalIntegral.integral_const] at hbound
  simp only [Real.norm_eq_abs, smul_eq_mul] at hbound
  norm_num at hbound
  rcases abs_le.mp hbound with ⟨hl, hu⟩
  apply abs_le.mpr
  constructor <;> unfold bowlAverage <;> linarith

theorem energy_distance_le {E : ℝ → ℝ} {ω c t : ℝ}
    (hE : ContinuousOn E (Icc (-1 : ℝ) 1))
    (hω : ∀ s ∈ Icc (-1 : ℝ) 1, ∀ t ∈ Icc (-1 : ℝ) 1,
      |E s - E t| ≤ ω)
    (ht : t ∈ Icc (-1 : ℝ) 1) :
    |E t - c| ≤ ω + |bowlAverage E - c| := by
  calc
    |E t - c| ≤ |E t - bowlAverage E| + |bowlAverage E - c| :=
      abs_sub_le (E t) (bowlAverage E) c
    _ ≤ ω + |bowlAverage E - c| :=
      add_le_add_right (distance_bowlAverage_le hE hω ht) _

/-- The actual uniform convergence conclusion used after the mean and
oscillation estimates in Section 3.2. -/
theorem uniform_energy_of_oscillation_and_mean
    {E : ℕ → ℝ → ℝ} {ω : ℕ → ℝ} {c : ℝ}
    (hE : ∀ n, ContinuousOn (E n) (Icc (-1 : ℝ) 1))
    (hω : ∀ n, ∀ s ∈ Icc (-1 : ℝ) 1, ∀ t ∈ Icc (-1 : ℝ) 1,
      |E n s - E n t| ≤ ω n)
    (hωlim : Tendsto ω atTop (𝓝 0))
    (hmean : Tendsto (fun n => bowlAverage (E n)) atTop (𝓝 c)) :
    TendstoUniformlyOn E (fun _ => c) atTop (Icc (-1 : ℝ) 1) := by
  have hlim : Tendsto (fun n => ω n + |bowlAverage (E n) - c|)
      atTop (𝓝 0) := by
    convert hωlim.add ((hmean.sub tendsto_const_nhds).abs) using 1
    simp
  apply Metric.tendstoUniformlyOn_iff.mpr
  intro η hη
  have hevent : ∀ᶠ n in atTop, ω n + |bowlAverage (E n) - c| < η :=
    hlim.eventually (gt_mem_nhds hη)
  filter_upwards [hevent] with n hn
  intro t ht
  rw [Real.dist_eq, abs_sub_comm]
  exact lt_of_le_of_lt (energy_distance_le (hE n) (hω n) ht) hn

#print axioms distance_bowlAverage_le
#print axioms uniform_energy_of_oscillation_and_mean
end ReciprocalCounterexample
