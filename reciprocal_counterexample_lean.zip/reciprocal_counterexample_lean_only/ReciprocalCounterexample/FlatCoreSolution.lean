import ReciprocalCounterexample.FlatCoreForcing
import ReciprocalCounterexample.FlatCoreBounds
import ReciprocalCounterexample.Normalization

/-!
# Exact bowl extraction and normalization for the flat-core family

All properties here are derived from an actual positive classical periodic
solution on the original closed interval; no periodic extension is assumed.
-/
noncomputable section
open Set MeasureTheory
open scoped ContDiff Topology Interval
namespace ReciprocalCounterexample

lemma flatCore_bowl_time_mem {δ t : ℝ} (hδ : 0 < δ)
    (ht : t ∈ Icc (-1 : ℝ) 1) :
    halfPeriod δ + t ∈ Icc 0 (fullPeriod δ) := by
  unfold fullPeriod halfPeriod
  constructor <;> linarith [ht.1, ht.2]

namespace IsClassicalSolution

theorem flatCore_bowl {ε δ : ℝ} {x v a : ℝ → ℝ} (hδ : 0 < δ)
    (hs : IsClassicalSolution (fullPeriod δ) (flatCoreRawForcing ε δ) x v a) :
    PositiveBowl ε flatCoreProfile (fun t => x (halfPeriod δ + t))
      (fun t => v (halfPeriod δ + t)) (fun t => a (halfPeriod δ + t)) where
  continuous_v := hs.continuous_v.comp (continuous_const.add continuous_id).continuousOn
    (fun _ ht => flatCore_bowl_time_mem hδ ht)
  continuous_a := hs.continuous_a.comp (continuous_const.add continuous_id).continuousOn
    (fun _ ht => flatCore_bowl_time_mem hδ ht)
  dx := by
    intro t ht
    have hd := (hs.dx _ (flatCore_bowl_time_mem hδ ht)).comp t
      ((hasDerivAt_id t).const_add (halfPeriod δ)).hasDerivWithinAt
      (fun _ hu => flatCore_bowl_time_mem hδ hu)
    simpa only [mul_one, Function.comp_def] using hd
  dv := by
    intro t ht
    have hd := (hs.dv _ (flatCore_bowl_time_mem hδ ht)).comp t
      ((hasDerivAt_id t).const_add (halfPeriod δ)).hasDerivWithinAt
      (fun _ hu => flatCore_bowl_time_mem hδ hu)
    simpa only [mul_one, Function.comp_def] using hd
  equation := by
    intro t ht
    rw [hs.equation _ (flatCore_bowl_time_mem hδ ht),
      flatCoreRawForcing_bowl hδ (abs_le.mpr ht)]
  positive := fun _ ht => hs.positive _ (flatCore_bowl_time_mem hδ ht)

/-- The larger bowl endpoint cannot be smaller than order `sqrt ε`. -/
theorem flatCore_endpoint_height_sq {ε δ : ℝ} {x v a : ℝ → ℝ}
    (hε : 0 ≤ ε) (hδ : 0 < δ)
    (hs : IsClassicalSolution (fullPeriod δ) (flatCoreRawForcing ε δ) x v a) :
    ε ≤ 32 * (max (x (halfPeriod δ - 1)) (x (halfPeriod δ + 1))) ^ 2 := by
  let A := max (x (halfPeriod δ - 1)) (x (halfPeriod δ + 1))
  have hb := hs.flatCore_bowl hδ
  have hA : 0 < A := lt_of_lt_of_le
    (hs.positive _ (flatCore_bowl_time_mem hδ (show (1:ℝ) ∈ Icc (-1:ℝ) 1 by norm_num)))
    (le_max_right _ _)
  have hb' := hb.div_const hA
  have hh : ∀ t ∈ Icc (-1 : ℝ) 1, x (halfPeriod δ + t) ≤ A := by
    intro t ht
    simpa only [A, ← sub_eq_add_neg] using hb.height_le_max_endpoints hε
      (fun t _ => flatCoreProfile_nonneg t) ht
  have hh' : ∀ t ∈ Icc (-1 : ℝ) 1, x (halfPeriod δ + t) / A ≤ 1 := by
    intro t ht
    exact (div_le_one hA).2 (hh t ht)
  have hp := hb'.normalized_parameter_le (div_nonneg hε (sq_nonneg A)) hh' (by
    intro t ht
    apply flatCoreProfile_one_of_half_le_abs
    exact (by linarith [ht.2] : (1:ℝ)/2 ≤ -t).trans (neg_le_abs t))
  have hAp : 0 < A ^ 2 := sq_pos_of_pos hA
  exact (div_le_iff₀ hAp).mp hp

end IsClassicalSolution

/-- The exact flat core supplies the nonzero lower bound in the velocity
obstruction, with no collision or compactness hypothesis. -/
theorem PositiveBowl.flatCore_obstruction {ε : ℝ} {x v a : ℝ → ℝ}
    (hε : 0 ≤ ε) (hs : PositiveBowl ε flatCoreProfile x v a) :
    (1 : ℝ) / 2 ≤ |∫ t in (-1 : ℝ)..1, v t| +
      ∫ t in (-1 : ℝ)..1, |(v t) ^ 2 - 1| := by
  have hv := hs.velocity_monotone hε (fun t _ => flatCoreProfile_nonneg t)
  have hflat : v (-(1/4)) = v (1/4) := by
    symm
    apply hs.velocity_eq_of_forcing_zero (by norm_num) (by norm_num) (by norm_num)
    intro t ht
    exact flatCoreProfile_zero_of_abs_le_quarter (abs_le.mpr (by simpa using ht))
  have ho := ReciprocalCounterexample.flatCore_obstruction (by norm_num : (0:ℝ) ≤ 1/4)
    (by norm_num : (1/4:ℝ) ≤ 1) hs.continuous_v hv hflat
  norm_num at ho ⊢
  exact ho

/-- A raw nonexistence theorem for this family implies the exact main theorem,
including smoothness, evenness, period one, both signs and mean minus one. -/
theorem main_of_flatCore_nonexistence {ε δ : ℝ}
    (hε : 0 < ε) (hδ : 0 < δ) (hm : ε * fullPeriod δ < 2)
    (hno : ¬ HasPositivePeriodicSolution (fullPeriod δ) (flatCoreRawForcing ε δ)) :
    MainTheorem := by
  have hT : 0 < fullPeriod δ := by unfold fullPeriod halfPeriod; linarith
  have hM : 0 < flatCoreMass ε δ := by
    linarith [(flatCoreMass_bounds hε.le hδ).1]
  refine ⟨normalizedForcing (fullPeriod δ) (flatCoreMass ε δ) (flatCoreRawForcing ε δ), ?_⟩
  exact normalized_isCounterexample hT hM (flatCoreRawForcing_contDiff hδ)
    (flatCoreRawForcing_periodic ε δ) (flatCoreRawForcing_even ε δ)
    (flatCoreRawForcing_sign_change hε hδ) (flatCoreRawForcing_integral hδ) hno

end ReciprocalCounterexample
