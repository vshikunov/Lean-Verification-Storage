import Mathlib.Analysis.Calculus.Deriv.Inv
import Mathlib.Analysis.Calculus.Deriv.Comp
import Mathlib.Analysis.Calculus.FDeriv.Prod
import Mathlib.Analysis.Calculus.FDeriv.Add
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Convert

/-!
# Algebra of the limiting return map

This file proves exact algebraic statements about the free passage and kick
maps in Sections 4 and 5 of the accompanying manuscript.  These results do
not assert the analytic convergence of the singular passage maps.
-/

noncomputable section

namespace ReciprocalCounterexample

abbrev Phase := ℝ × ℝ

/-- The extended passage map for the free reflected trajectory. -/
def freePassage (z : Phase) : Phase := (-z.1 - 2 * z.2, -z.2)

/-- The velocity jump induced by a negative impulse of mass two. -/
def kick (z : Phase) : Phase := (z.1, z.2 - 2 / z.1)

/-- The limiting extended return map. -/
def freeReturn (z : Phase) : Phase := kick (freePassage z)

/-- The limiting incoming chart, with parameters `(minimum time, speed)`. -/
def incomingChart (p : Phase) : Phase := (p.2 * (1 + p.1), -p.2)

/-- The limiting outgoing chart, with the same parameters. -/
def outgoingChart (p : Phase) : Phase := (p.2 * (1 - p.1), p.2)

/-- The inverse of the incoming chart when the velocity is nonzero. -/
def incomingInverse (z : Phase) : Phase := (-z.1 / z.2 - 1, -z.2)

theorem incomingInverse_incomingChart (τ b : ℝ) (hb : b ≠ 0) :
    incomingInverse (incomingChart (τ, b)) = (τ, b) := by
  apply Prod.ext
  · simp only [incomingInverse, incomingChart, Prod.fst, Prod.snd]
    field_simp [hb]
  · simp [incomingInverse, incomingChart]

theorem incomingChart_incomingInverse (B v : ℝ) (hv : v ≠ 0) :
    incomingChart (incomingInverse (B, v)) = (B, v) := by
  apply Prod.ext
  · simp only [incomingInverse, incomingChart, Prod.fst, Prod.snd]
    field_simp [hv]
  · simp [incomingInverse, incomingChart]

theorem outgoingChart_incomingInverse (B v : ℝ) (hv : v ≠ 0) :
    outgoingChart (incomingInverse (B, v)) = freePassage (B, v) := by
  apply Prod.ext
  · simp only [incomingInverse, outgoingChart, freePassage, Prod.fst, Prod.snd]
    field_simp [hv]
    ring
  · simp [incomingInverse, outgoingChart, freePassage]

theorem freeReturn_fixedPoint : freeReturn (1, -1) = (1, -1) := by
  norm_num [freeReturn, freePassage, kick]

/-- The free return map has exactly one fixed point of positive height. -/
theorem freeReturn_positive_fixedPoint_unique (B v : ℝ) (hB : 0 < B)
    (hfix : freeReturn (B, v) = (B, v)) : B = 1 ∧ v = -1 := by
  have h₁ : -B - 2 * v = B := by
    simpa [freeReturn, freePassage, kick] using congrArg Prod.fst hfix
  have h₂ : -v - 2 / (-B - 2 * v) = v := by
    simpa [freeReturn, freePassage, kick] using congrArg Prod.snd hfix
  have hv : v = -B := by linarith
  rw [h₁, hv] at h₂
  have hB0 : B ≠ 0 := ne_of_gt hB
  have hsq : B ^ 2 = 1 := by
    field_simp [hB0] at h₂
    nlinarith
  have hBone : B = 1 := by nlinarith
  constructor
  · exact hBone
  · linarith

theorem freeReturn_positive_fixedPoint_iff (B v : ℝ) (hB : 0 < B) :
    freeReturn (B, v) = (B, v) ↔ B = 1 ∧ v = -1 := by
  constructor
  · exact freeReturn_positive_fixedPoint_unique B v hB
  · rintro ⟨rfl, rfl⟩
    exact freeReturn_fixedPoint

private def fstProjection : Phase →L[ℝ] ℝ := ContinuousLinearMap.fst ℝ ℝ ℝ
private def sndProjection : Phase →L[ℝ] ℝ := ContinuousLinearMap.snd ℝ ℝ ℝ

/-- First coordinate of the derivative of the free passage map. -/
def freeFirstDerivative : Phase →L[ℝ] ℝ :=
  -fstProjection - (2 : ℝ) • sndProjection

/-- The actual continuous linear derivative of the limiting return map. -/
def returnDerivativeCLM : Phase →L[ℝ] Phase :=
  freeFirstDerivative.prod ((-2 : ℝ) • fstProjection - (5 : ℝ) • sndProjection)

theorem returnDerivativeCLM_apply (B v : ℝ) :
    returnDerivativeCLM (B, v) = (-B - 2 * v, -2 * B - 5 * v) := by
  simp [returnDerivativeCLM, freeFirstDerivative, fstProjection, sndProjection]

/-- The displayed matrix is justified by a Fréchet derivative, not just matrix arithmetic. -/
theorem hasFDerivAt_freeReturn :
    HasFDerivAt freeReturn returnDerivativeCLM (1, -1) := by
  have hf : HasFDerivAt (fun z : Phase => z.1) fstProjection (1, -1) :=
    (ContinuousLinearMap.fst ℝ ℝ ℝ).hasFDerivAt
  have hs : HasFDerivAt (fun z : Phase => z.2) sndProjection (1, -1) :=
    (ContinuousLinearMap.snd ℝ ℝ ℝ).hasFDerivAt
  have hp : HasFDerivAt (fun z : Phase => -z.1 - 2 * z.2)
      freeFirstDerivative (1, -1) := by
    simpa [freeFirstDerivative, smul_eq_mul] using hf.neg.sub (hs.const_smul (2 : ℝ))
  have hi : HasFDerivAt (fun z : Phase => (-z.1 - 2 * z.2)⁻¹)
      (-freeFirstDerivative) (1, -1) := by
    have hi' :=
      (hasDerivAt_inv (by norm_num : (-(1 : ℝ) - 2 * (-1)) ≠ 0)).comp_hasFDerivAt
        (1, -1) hp
    norm_num [Function.comp_def] at hi'
    exact hi'
  have hd : freeFirstDerivative.prod
      (-sndProjection - (2 : ℝ) • (-freeFirstDerivative)) = returnDerivativeCLM := by
    apply ContinuousLinearMap.ext
    intro z
    apply Prod.ext
    · rfl
    · change -z.2 - 2 * (-(-z.1 - 2 * z.2)) = -2 * z.1 - 5 * z.2
      ring
  have hh := hp.prodMk (hs.neg.sub (hi.const_smul (2 : ℝ)))
  rw [hd] at hh
  simpa [freeReturn, freePassage, kick, div_eq_mul_inv, smul_eq_mul] using hh

theorem fderiv_freeReturn :
    fderiv ℝ freeReturn (1, -1) = returnDerivativeCLM :=
  hasFDerivAt_freeReturn.fderiv

/-- The matrix displayed for the derivative at the limiting fixed point. -/
def returnDerivativeMatrix : Matrix (Fin 2) (Fin 2) ℝ :=
  !![-1, -2; -2, -5]

theorem returnDerivativeMatrix_columns :
    returnDerivativeCLM (1, 0) = (returnDerivativeMatrix 0 0, returnDerivativeMatrix 1 0) ∧
    returnDerivativeCLM (0, 1) = (returnDerivativeMatrix 0 1, returnDerivativeMatrix 1 1) := by
  norm_num [returnDerivativeCLM_apply, returnDerivativeMatrix]

theorem returnDerivativeMatrix_sub_identity_det :
    Matrix.det (returnDerivativeMatrix - (1 : Matrix (Fin 2) (Fin 2) ℝ)) = 8 := by
  norm_num [returnDerivativeMatrix, Matrix.det_fin_two]

theorem returnDerivativeMatrix_sub_identity_det_ne_zero :
    Matrix.det (returnDerivativeMatrix - (1 : Matrix (Fin 2) (Fin 2) ℝ)) ≠ 0 := by
  rw [returnDerivativeMatrix_sub_identity_det]
  norm_num

/-- Incoming-chart determinant after a determinant-one variational propagation. -/
theorem incoming_chart_det_after_propagation
    (Φ : Matrix (Fin 2) (Fin 2) ℝ) (hΦ : Matrix.det Φ = 1) (b : ℝ) :
    Matrix.det (Φ * !![b, 0; 0, -1]) = -b := by
  rw [Matrix.det_mul, hΦ]
  simp [Matrix.det_fin_two]

theorem incoming_chart_det_after_propagation_ne_zero
    (Φ : Matrix (Fin 2) (Fin 2) ℝ) (hΦ : Matrix.det Φ = 1)
    (b : ℝ) (hb : b ≠ 0) :
    Matrix.det (Φ * !![b, 0; 0, -1]) ≠ 0 := by
  rw [incoming_chart_det_after_propagation Φ hΦ b]
  exact neg_ne_zero.mpr hb

end ReciprocalCounterexample

#print axioms ReciprocalCounterexample.incomingInverse_incomingChart
#print axioms ReciprocalCounterexample.incomingChart_incomingInverse
#print axioms ReciprocalCounterexample.outgoingChart_incomingInverse
#print axioms ReciprocalCounterexample.freeReturn_positive_fixedPoint_iff
#print axioms ReciprocalCounterexample.hasFDerivAt_freeReturn
#print axioms ReciprocalCounterexample.fderiv_freeReturn
#print axioms ReciprocalCounterexample.returnDerivativeMatrix_columns
#print axioms ReciprocalCounterexample.returnDerivativeMatrix_sub_identity_det
#print axioms ReciprocalCounterexample.incoming_chart_det_after_propagation
