import ReciprocalCounterexample.FlatCoreLog
import Mathlib.Analysis.SpecialFunctions.Log.NegMulLog

/-!
# Vanishing logarithmic energy for bounded flat-core trajectories

The acceleration in this file is the actual expression eps*f/x. Uniform
height and total-acceleration bounds imply a quantitative O(eps*(1+|log eps|))
bound, with no positive lower bound on x. The final modulus is continuous at
zero, so it is directly usable in a quantitative nonexistence argument.
-/

noncomputable section
open Set MeasureTheory Filter
open scoped Interval Topology

namespace ReciprocalCounterexample

theorem flatCore_weighted_log_pointwise {eps B D t : ℝ} {x w : ℝ → ℝ}
    (heps : 0 < eps) (heps1 : eps ≤ 1) (hB : 0 ≤ B) (hD : 0 ≤ D)
    (hx : 0 < x t) (hxB : x t ≤ B) (hw : 0 ≤ w t) (hwD : w t ≤ D)
    (hwzero : flatCoreProfile t = 0 → w t = 0) :
    w t * |Real.log (x t)| ≤ D * flatAcceleration eps x t +
      D * (Real.log (1 + B) + |Real.log eps|) +
        w t * |Real.log (flatCoreProfile t)| := by
  have hlogB : 0 ≤ Real.log (1 + B) := Real.log_nonneg (by linarith)
  by_cases hfzero : flatCoreProfile t = 0
  · rw [hwzero hfzero]
    simp only [flatAcceleration, hfzero, mul_zero, zero_div, zero_mul, zero_add, add_zero]
    positivity
  have hfpos : 0 < flatCoreProfile t :=
    lt_of_le_of_ne (flatCoreProfile_nonneg t) (Ne.symm hfzero)
  have hα : 0 < eps * flatCoreProfile t := mul_pos heps hfpos
  have hα1 : eps * flatCoreProfile t ≤ 1 :=
    le_trans (mul_le_mul_of_nonneg_left (flatCoreProfile_le_one t) heps.le)
      (by simpa using heps1)
  have hmajor := abs_log_control hx hxB hα hα1
  rw [Real.log_mul (ne_of_gt heps) hfzero] at hmajor
  have hY : 0 ≤ flatAcceleration eps x t :=
    div_nonneg (mul_nonneg heps.le (flatCoreProfile_nonneg t)) hx.le
  have hloglin : Real.log (1 + flatAcceleration eps x t) ≤ flatAcceleration eps x t := by
    have := Real.log_le_sub_one_of_pos (show 0 < 1 + flatAcceleration eps x t by linarith)
    linarith
  have hmajor' : |Real.log (x t)| ≤ flatAcceleration eps x t +
      (Real.log (1 + B) + |Real.log eps|) + |Real.log (flatCoreProfile t)| := by
    change |Real.log (x t)| ≤ Real.log (1 + B) +
      Real.log (1 + flatAcceleration eps x t) -
        (Real.log eps + Real.log (flatCoreProfile t)) at hmajor
    have h1 := neg_le_abs (Real.log eps)
    have h2 := neg_le_abs (Real.log (flatCoreProfile t))
    linarith
  calc
    w t * |Real.log (x t)| ≤ w t * (flatAcceleration eps x t +
        (Real.log (1 + B) + |Real.log eps|) + |Real.log (flatCoreProfile t)|) :=
      mul_le_mul_of_nonneg_left hmajor' hw
    _ = w t * flatAcceleration eps x t +
        w t * (Real.log (1 + B) + |Real.log eps|) +
          w t * |Real.log (flatCoreProfile t)| := by ring
    _ ≤ D * flatAcceleration eps x t +
        D * (Real.log (1 + B) + |Real.log eps|) +
          w t * |Real.log (flatCoreProfile t)| := by
      exact add_le_add_right (add_le_add (mul_le_mul_of_nonneg_right hwD hY)
        (mul_le_mul_of_nonneg_right hwD (add_nonneg hlogB (abs_nonneg _)))) _

theorem flatCore_weighted_log_integral_bound {eps B D : ℝ} {x w : ℝ → ℝ}
    (heps : 0 < eps) (heps1 : eps ≤ 1) (hB : 0 ≤ B) (hD : 0 ≤ D)
    (hxcont : ContinuousOn x (Icc (-1 : ℝ) 1))
    (hxpos : ∀ t ∈ Icc (-1 : ℝ) 1, 0 < x t)
    (hxB : ∀ t ∈ Icc (-1 : ℝ) 1, x t ≤ B)
    (hwcont : ContinuousOn w (Icc (-1 : ℝ) 1))
    (hwnonneg : ∀ t ∈ Icc (-1 : ℝ) 1, 0 ≤ w t)
    (hwD : ∀ t ∈ Icc (-1 : ℝ) 1, w t ≤ D)
    (hwzero : ∀ t ∈ Icc (-1 : ℝ) 1, flatCoreProfile t = 0 → w t = 0)
    (hmoment : IntervalIntegrable (fun t => w t * |Real.log (flatCoreProfile t)|)
      volume (-1) 1) :
    (∫ t in (-1 : ℝ)..1, w t * |Real.log (x t)|) ≤
      D * (∫ t in (-1 : ℝ)..1, flatAcceleration eps x t) +
        2 * D * (Real.log (1 + B) + |Real.log eps|) +
          (∫ t in (-1 : ℝ)..1, w t * |Real.log (flatCoreProfile t)|) := by
  have hlog : ContinuousOn (fun t => |Real.log (x t)|) (Icc (-1 : ℝ) 1) :=
    (hxcont.log (fun t ht => ne_of_gt (hxpos t ht))).abs
  have hleft : IntervalIntegrable (fun t => w t * |Real.log (x t)|) volume (-1) 1 :=
    (hwcont.mul hlog).intervalIntegrable_of_Icc (by norm_num)
  have hacc : IntervalIntegrable (flatAcceleration eps x) volume (-1) 1 :=
    ((continuousOn_const.mul flatCoreProfile_contDiff.continuous.continuousOn).div hxcont
      (fun t ht => ne_of_gt (hxpos t ht))).intervalIntegrable_of_Icc (by norm_num)
  have hfirst := hacc.const_mul D
  have hc : IntervalIntegrable (fun _ : ℝ => D * (Real.log (1 + B) + |Real.log eps|))
      volume (-1) 1 := intervalIntegrable_const
  have hmono := intervalIntegral.integral_mono_on (by norm_num : (-1 : ℝ) ≤ 1)
    hleft ((hfirst.add hc).add hmoment)
    (fun t ht => flatCore_weighted_log_pointwise heps heps1 hB hD
      (hxpos t ht) (hxB t ht) (hwnonneg t ht) (hwD t ht) (hwzero t ht))
  rw [intervalIntegral.integral_add (hfirst.add hc) hmoment,
    intervalIntegral.integral_add hfirst hc,
    intervalIntegral.integral_const_mul, intervalIntegral.integral_const] at hmono
  norm_num [smul_eq_mul] at hmono
  nlinarith

/-- An everywhere-continuous error modulus, equal to the logarithmic bound for
nonnegative eps and converging to zero as eps tends to zero. -/
def flatCoreLogModulus (B D A J eps : ℝ) : ℝ :=
  eps * (D * A + 2 * D * Real.log (1 + B) + J) +
    2 * D * |eps * Real.log eps|

theorem flatCoreLogModulus_continuous (B D A J : ℝ) :
    Continuous (flatCoreLogModulus B D A J) := by
  exact (continuous_id.mul continuous_const).add
    (continuous_const.mul Real.continuous_mul_log.abs)

@[simp] theorem flatCoreLogModulus_zero (B D A J : ℝ) :
    flatCoreLogModulus B D A J 0 = 0 := by simp [flatCoreLogModulus]

theorem flatCoreLogModulus_tendsto_zero (B D A J : ℝ) :
    Tendsto (flatCoreLogModulus B D A J) (𝓝 0) (𝓝 0) := by
  simpa using (flatCoreLogModulus_continuous B D A J).continuousAt.tendsto (x := 0)

theorem flatCoreLogModulus_eq {B D A J eps : ℝ} (heps : 0 ≤ eps) :
    flatCoreLogModulus B D A J eps =
      eps * (D * A + 2 * D * (Real.log (1 + B) + |Real.log eps|) + J) := by
  rw [flatCoreLogModulus, abs_mul, abs_of_nonneg heps]
  ring

theorem flatCore_small_weighted_log_bound {eps B D A J : ℝ} {x w : ℝ → ℝ}
    (heps : 0 < eps) (heps1 : eps ≤ 1) (hB : 0 ≤ B) (hD : 0 ≤ D)
    (hxcont : ContinuousOn x (Icc (-1 : ℝ) 1))
    (hxpos : ∀ t ∈ Icc (-1 : ℝ) 1, 0 < x t)
    (hxB : ∀ t ∈ Icc (-1 : ℝ) 1, x t ≤ B)
    (hwcont : ContinuousOn w (Icc (-1 : ℝ) 1))
    (hwnonneg : ∀ t ∈ Icc (-1 : ℝ) 1, 0 ≤ w t)
    (hwD : ∀ t ∈ Icc (-1 : ℝ) 1, w t ≤ D)
    (hwzero : ∀ t ∈ Icc (-1 : ℝ) 1, flatCoreProfile t = 0 → w t = 0)
    (hmoment : IntervalIntegrable (fun t => w t * |Real.log (flatCoreProfile t)|)
      volume (-1) 1)
    (hA : (∫ t in (-1 : ℝ)..1, flatAcceleration eps x t) ≤ A)
    (hJ : (∫ t in (-1 : ℝ)..1, w t * |Real.log (flatCoreProfile t)|) ≤ J) :
    eps * (∫ t in (-1 : ℝ)..1, w t * |Real.log (x t)|) ≤
      flatCoreLogModulus B D A J eps := by
  have h := flatCore_weighted_log_integral_bound heps heps1 hB hD hxcont hxpos hxB
    hwcont hwnonneg hwD hwzero hmoment
  rw [flatCoreLogModulus_eq heps.le]
  apply mul_le_mul_of_nonneg_left _ heps.le
  exact le_trans h (by nlinarith [mul_le_mul_of_nonneg_left hA hD])

/-- The estimate only needs a bound for eps times the acceleration mass.
Thus the acceleration mass itself is allowed to diverge as eps tends to zero. -/
theorem flatCore_small_weighted_log_bound_of_scaled_acceleration
    {eps B D R J : ℝ} {x w : ℝ → ℝ}
    (heps : 0 < eps) (heps1 : eps ≤ 1) (hB : 0 ≤ B) (hD : 0 ≤ D)
    (hxcont : ContinuousOn x (Icc (-1 : ℝ) 1))
    (hxpos : ∀ t ∈ Icc (-1 : ℝ) 1, 0 < x t)
    (hxB : ∀ t ∈ Icc (-1 : ℝ) 1, x t ≤ B)
    (hwcont : ContinuousOn w (Icc (-1 : ℝ) 1))
    (hwnonneg : ∀ t ∈ Icc (-1 : ℝ) 1, 0 ≤ w t)
    (hwD : ∀ t ∈ Icc (-1 : ℝ) 1, w t ≤ D)
    (hwzero : ∀ t ∈ Icc (-1 : ℝ) 1, flatCoreProfile t = 0 → w t = 0)
    (hmoment : IntervalIntegrable (fun t => w t * |Real.log (flatCoreProfile t)|)
      volume (-1) 1)
    (hR : eps * (∫ t in (-1 : ℝ)..1, flatAcceleration eps x t) ≤ R)
    (hJ : (∫ t in (-1 : ℝ)..1, w t * |Real.log (flatCoreProfile t)|) ≤ J) :
    eps * (∫ t in (-1 : ℝ)..1, w t * |Real.log (x t)|) ≤
      D * R + eps * (2 * D * Real.log (1 + B) + J) +
        2 * D * |eps * Real.log eps| := by
  have h := flatCore_weighted_log_integral_bound heps heps1 hB hD hxcont hxpos hxB
    hwcont hwnonneg hwD hwzero hmoment
  have he := mul_le_mul_of_nonneg_left h heps.le
  have hRD := mul_le_mul_of_nonneg_left hR hD
  have hJe := mul_le_mul_of_nonneg_left hJ heps.le
  rw [abs_mul, abs_of_nonneg heps.le]
  nlinarith

theorem flatCore_small_deriv_log_bound_of_scaled_acceleration
    {eps B D R : ℝ} {x : ℝ → ℝ}
    (heps : 0 < eps) (heps1 : eps ≤ 1) (hB : 0 ≤ B) (hD : 0 ≤ D)
    (hxcont : ContinuousOn x (Icc (-1 : ℝ) 1))
    (hxpos : ∀ t ∈ Icc (-1 : ℝ) 1, 0 < x t)
    (hxB : ∀ t ∈ Icc (-1 : ℝ) 1, x t ≤ B)
    (hderiv : ∀ t ∈ Icc (-1 : ℝ) 1, |deriv flatCoreProfile t| ≤ D)
    (hR : eps * (∫ t in (-1 : ℝ)..1, flatAcceleration eps x t) ≤ R) :
    eps * (∫ t in (-1 : ℝ)..1, |deriv flatCoreProfile t| * |Real.log (x t)|) ≤
      D * R + eps * (2 * D * Real.log (1 + B) +
        (∫ t in (-1 : ℝ)..1, |deriv flatCoreProfile t| * |Real.log (flatCoreProfile t)|)) +
          2 * D * |eps * Real.log eps| := by
  exact flatCore_small_weighted_log_bound_of_scaled_acceleration heps heps1 hB hD
    hxcont hxpos hxB (flatCoreProfile_contDiff.continuous_deriv (by simp)).abs.continuousOn
    (fun t _ => abs_nonneg _) hderiv
    (fun t _ hz => by rw [flatCoreProfile_deriv_eq_zero_of_profile_zero hz, abs_zero])
    (flatCoreProfile_logMoment_intervalIntegrable (-1) 1) hR le_rfl

theorem flatCore_small_profile_log_bound_of_scaled_acceleration
    {eps B R : ℝ} {x : ℝ → ℝ}
    (heps : 0 < eps) (heps1 : eps ≤ 1) (hB : 0 ≤ B)
    (hxcont : ContinuousOn x (Icc (-1 : ℝ) 1))
    (hxpos : ∀ t ∈ Icc (-1 : ℝ) 1, 0 < x t)
    (hxB : ∀ t ∈ Icc (-1 : ℝ) 1, x t ≤ B)
    (hR : eps * (∫ t in (-1 : ℝ)..1, flatAcceleration eps x t) ≤ R) :
    eps * (∫ t in (-1 : ℝ)..1, flatCoreProfile t * |Real.log (x t)|) ≤
      R + eps * (2 * Real.log (1 + B) + 2) + 2 * |eps * Real.log eps| := by
  have h := flatCore_small_weighted_log_bound_of_scaled_acceleration heps heps1 hB
    (by norm_num : (0 : ℝ) ≤ 1) hxcont hxpos hxB
    flatCoreProfile_contDiff.continuous.continuousOn
    (fun t _ => flatCoreProfile_nonneg t) (fun t _ => flatCoreProfile_le_one t)
    (fun _ _ hz => hz) (flatCoreProfile_entropy_abs_continuous.intervalIntegrable (-1) 1)
    hR flatCoreProfile_entropy_integral_le_two
  simpa using h

/-- A continuous error function for the concrete choice eps=eta^2 and an
acceleration mass bounded by C/eta. -/
def flatCoreSquareLogModulus (B D C J eta : ℝ) : ℝ :=
  D * C * eta + eta ^ 2 * (2 * D * Real.log (1 + B) + J) +
    2 * D * |eta ^ 2 * Real.log (eta ^ 2)|

theorem flatCoreSquareLogModulus_continuous (B D C J : ℝ) :
    Continuous (flatCoreSquareLogModulus B D C J) := by
  exact ((continuous_const.mul continuous_id).add
    ((continuous_id.pow 2).mul continuous_const)).add
      (continuous_const.mul ((Real.continuous_mul_log.comp (continuous_id.pow 2)).abs))

@[simp] theorem flatCoreSquareLogModulus_zero (B D C J : ℝ) :
    flatCoreSquareLogModulus B D C J 0 = 0 := by simp [flatCoreSquareLogModulus]

theorem flatCoreSquareLogModulus_tendsto_zero (B D C J : ℝ) :
    Tendsto (flatCoreSquareLogModulus B D C J) (𝓝 0) (𝓝 0) := by
  simpa using (flatCoreSquareLogModulus_continuous B D C J).continuousAt.tendsto (x := 0)

theorem scaled_acceleration_bound_of_reciprocal {eta C M : ℝ}
    (heta : 0 < eta) (hM : M ≤ C / eta) : eta ^ 2 * M ≤ C * eta := by
  have h := (le_div_iff₀ heta).1 hM
  have h' := mul_le_mul_of_nonneg_right h heta.le
  nlinarith

theorem flatCoreProfile_exists_deriv_bound :
    ∃ D : ℝ, 0 < D ∧ ∀ t ∈ Icc (-1 : ℝ) 1, |deriv flatCoreProfile t| ≤ D := by
  obtain ⟨s, hs, hmax⟩ := isCompact_Icc.exists_isMaxOn
    (show (Icc (-1 : ℝ) 1).Nonempty from ⟨0, by norm_num⟩)
    (flatCoreProfile_contDiff.continuous_deriv (by simp)).abs.continuousOn
  refine ⟨|deriv flatCoreProfile s| + 1, by positivity, ?_⟩
  intro t ht
  exact le_trans (hmax ht) (by linarith)

theorem flatCore_square_small_deriv_log_bound
    {eta B D C : ℝ} {x : ℝ → ℝ}
    (heta : 0 < eta) (heta1 : eta ≤ 1) (hB : 0 ≤ B) (hD : 0 ≤ D)
    (hxcont : ContinuousOn x (Icc (-1 : ℝ) 1))
    (hxpos : ∀ t ∈ Icc (-1 : ℝ) 1, 0 < x t)
    (hxB : ∀ t ∈ Icc (-1 : ℝ) 1, x t ≤ B)
    (hderiv : ∀ t ∈ Icc (-1 : ℝ) 1, |deriv flatCoreProfile t| ≤ D)
    (hA : (∫ t in (-1 : ℝ)..1, flatAcceleration (eta ^ 2) x t) ≤ C / eta) :
    eta ^ 2 * (∫ t in (-1 : ℝ)..1, |deriv flatCoreProfile t| * |Real.log (x t)|) ≤
      flatCoreSquareLogModulus B D C
        (∫ t in (-1 : ℝ)..1, |deriv flatCoreProfile t| * |Real.log (flatCoreProfile t)|) eta := by
  have h := flatCore_small_deriv_log_bound_of_scaled_acceleration
    (sq_pos_of_pos heta) (pow_le_one₀ heta.le heta1) hB hD hxcont hxpos hxB hderiv
    (scaled_acceleration_bound_of_reciprocal heta hA)
  simpa only [flatCoreSquareLogModulus, mul_assoc] using h

theorem flatCore_square_small_profile_log_bound
    {eta B C : ℝ} {x : ℝ → ℝ}
    (heta : 0 < eta) (heta1 : eta ≤ 1) (hB : 0 ≤ B)
    (hxcont : ContinuousOn x (Icc (-1 : ℝ) 1))
    (hxpos : ∀ t ∈ Icc (-1 : ℝ) 1, 0 < x t)
    (hxB : ∀ t ∈ Icc (-1 : ℝ) 1, x t ≤ B)
    (hA : (∫ t in (-1 : ℝ)..1, flatAcceleration (eta ^ 2) x t) ≤ C / eta) :
    eta ^ 2 * (∫ t in (-1 : ℝ)..1, flatCoreProfile t * |Real.log (x t)|) ≤
      flatCoreSquareLogModulus B 1 C 2 eta := by
  have h := flatCore_small_profile_log_bound_of_scaled_acceleration
    (sq_pos_of_pos heta) (pow_le_one₀ heta.le heta1) hB hxcont hxpos hxB
    (scaled_acceleration_bound_of_reciprocal heta hA)
  simpa only [flatCoreSquareLogModulus, one_mul, mul_one] using h

#print axioms flatCore_weighted_log_integral_bound
#print axioms flatCore_small_weighted_log_bound
#print axioms flatCoreLogModulus_tendsto_zero
#print axioms flatCore_small_deriv_log_bound_of_scaled_acceleration
#print axioms flatCore_small_profile_log_bound_of_scaled_acceleration
#print axioms flatCoreSquareLogModulus_tendsto_zero

end ReciprocalCounterexample
