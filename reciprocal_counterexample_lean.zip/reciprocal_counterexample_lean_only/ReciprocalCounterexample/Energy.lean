import ReciprocalCounterexample.Definitions
import Mathlib.MeasureTheory.Integral.IntervalIntegral.IntegrationByParts
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Analysis.SpecialFunctions.Integrals
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring

/-!
# Periodic energy and pointwise logarithmic energy identities

These results prove necessary conditions and differential identities used by
the manuscript. They do not prove existence of the counterexample forcing.
The interval hypotheses are exactly those in `IsClassicalSolution`.
-/

noncomputable section
open Set MeasureTheory
open scoped Interval

namespace ReciprocalCounterexample

/-- A continuous, nonzero function of zero mean takes both signs. -/
theorem continuous_zero_integral_changesSign {T : ℝ} {f : ℝ → ℝ}
    (hT : 0 < T) (hf : ContinuousOn f (Icc 0 T))
    (hint : (∫ t in (0 : ℝ)..T, f t) = 0)
    (hnz : ∃ t ∈ Icc 0 T, f t ≠ 0) : ChangesSignOn T f := by
  constructor
  · by_contra hno
    push_neg at hno
    obtain ⟨t, ht, hft⟩ := hnz
    have hpos : 0 < ∫ s in (0 : ℝ)..T, f s :=
      intervalIntegral.integral_pos hT hf
        (fun s hs => hno s (mem_Icc_of_Ioc hs))
        ⟨t, ht, lt_of_le_of_ne (hno t ht) (Ne.symm hft)⟩
    rw [hint] at hpos
    exact (lt_irrefl 0) hpos
  · by_contra hno
    push_neg at hno
    obtain ⟨t, ht, hft⟩ := hnz
    have hpos : 0 < ∫ s in (0 : ℝ)..T, -f s :=
      intervalIntegral.integral_pos hT hf.neg
        (fun s hs => neg_nonneg.mpr (hno s (mem_Icc_of_Ioc hs)))
        ⟨t, ht, neg_pos.mpr (lt_of_le_of_ne (hno t ht) hft)⟩
    rw [intervalIntegral.integral_neg, hint, neg_zero] at hpos
    exact (lt_irrefl 0) hpos

namespace IsClassicalSolution

/-- Integration by parts with the actual periodic boundary conditions. -/
theorem energy_identity {T : ℝ} {h x v a : ℝ → ℝ}
    (hs : IsClassicalSolution T h x v a) (hT : 0 ≤ T) :
    (∫ t in (0 : ℝ)..T, h t) = -(∫ t in (0 : ℝ)..T, (v t) ^ 2) := by
  have hdx : ∀ t ∈ uIcc 0 T, HasDerivWithinAt x (v t) (uIcc 0 T) t := by
    simpa only [uIcc_of_le hT] using hs.dx
  have hdv : ∀ t ∈ uIcc 0 T, HasDerivWithinAt v (a t) (uIcc 0 T) t := by
    simpa only [uIcc_of_le hT] using hs.dv
  have hip := intervalIntegral.integral_mul_deriv_eq_deriv_mul_of_hasDerivWithinAt
    hdx hdv (hs.continuous_v.intervalIntegrable_of_Icc hT)
    (hs.continuous_a.intervalIntegrable_of_Icc hT)
  have heq : (∫ t in (0 : ℝ)..T, h t) = ∫ t in (0 : ℝ)..T, x t * a t := by
    apply intervalIntegral.integral_congr
    intro t ht
    exact (hs.equation t (by simpa only [uIcc_of_le hT] using ht)).symm
  rw [heq, hip, ← hs.endpoint_x, ← hs.endpoint_v, sub_self, zero_sub]
  congr 1
  apply intervalIntegral.integral_congr
  intro t _
  ring

/-- A periodic solution necessarily has nonpositive forcing mean. -/
theorem mean_nonpositive {T : ℝ} {h x v a : ℝ → ℝ}
    (hs : IsClassicalSolution T h x v a) (hT : 0 ≤ T) :
    (∫ t in (0 : ℝ)..T, h t) ≤ 0 := by
  rw [hs.energy_identity hT]
  exact neg_nonpos.mpr (intervalIntegral.integral_nonneg hT (fun t _ => sq_nonneg (v t)))

/-- Nonzero forcing excludes identically zero velocity, including at the
one-sided endpoints. -/
theorem exists_velocity_ne_zero {T : ℝ} {h x v a : ℝ → ℝ}
    (hs : IsClassicalSolution T h x v a) (hT : 0 < T)
    (hnz : ∃ t ∈ Icc 0 T, h t ≠ 0) :
    ∃ t ∈ Icc 0 T, v t ≠ 0 := by
  by_contra hzero
  push_neg at hzero
  obtain ⟨t, ht, hht⟩ := hnz
  have hvzero : HasDerivWithinAt v 0 (Icc 0 T) t :=
    (hasDerivWithinAt_const t (Icc 0 T) (0 : ℝ)).congr_of_mem hzero ht
  have hazero : a t = 0 :=
    UniqueDiffWithinAt.eq_deriv (Icc 0 T) (uniqueDiffOn_Icc hT t ht) (hs.dv t ht) hvzero
  apply hht
  rw [← hs.equation t ht, hazero, mul_zero]

/-- The strict negative-mean necessary condition for nonzero forcing. -/
theorem mean_negative {T : ℝ} {h x v a : ℝ → ℝ}
    (hs : IsClassicalSolution T h x v a) (hT : 0 < T)
    (hnz : ∃ t ∈ Icc 0 T, h t ≠ 0) :
    (∫ t in (0 : ℝ)..T, h t) < 0 := by
  rw [hs.energy_identity hT.le]
  apply neg_neg_of_pos
  apply intervalIntegral.integral_pos hT (hs.continuous_v.pow 2)
    (fun t _ => sq_nonneg (v t))
  obtain ⟨t, ht, hvt⟩ := hs.exists_velocity_ne_zero hT hnz
  exact ⟨t, ht, sq_pos_iff.mpr hvt⟩

/-- Integrating the acceleration gives the second periodic boundary condition. -/
theorem integral_acceleration_zero {T : ℝ} {h x v a : ℝ → ℝ}
    (hs : IsClassicalSolution T h x v a) (hT : 0 ≤ T) :
    (∫ t in (0 : ℝ)..T, a t) = 0 := by
  have hFTC := intervalIntegral.integral_eq_sub_of_hasDerivAt_of_le hT hs.continuous_v
    (fun t ht => (hs.dv t (mem_Icc_of_Ioo ht)).hasDerivAt (Icc_mem_nhds ht.1 ht.2))
    (hs.continuous_a.intervalIntegrable_of_Icc hT)
  simpa only [← hs.endpoint_v, sub_self] using hFTC

/-- The reciprocal force has zero integral along any positive periodic solution. -/
theorem force_balance {T : ℝ} {h x v a : ℝ → ℝ}
    (hs : IsClassicalSolution T h x v a) (hT : 0 ≤ T) :
    (∫ t in (0 : ℝ)..T, h t / x t) = 0 := by
  calc
    (∫ t in (0 : ℝ)..T, h t / x t) = ∫ t in (0 : ℝ)..T, a t := by
      apply intervalIntegral.integral_congr
      intro t ht
      exact (hs.acceleration_eq_div (by simpa only [uIcc_of_le hT] using ht)).symm
    _ = 0 := hs.integral_acceleration_zero hT

/-- The sign-change necessary condition for nonzero forcing. -/
theorem forcing_changes_sign {T : ℝ} {h x v a : ℝ → ℝ}
    (hs : IsClassicalSolution T h x v a) (hT : 0 < T)
    (hnz : ∃ t ∈ Icc 0 T, h t ≠ 0) : ChangesSignOn T h := by
  have hanz : ∃ t ∈ Icc 0 T, a t ≠ 0 := by
    obtain ⟨t, ht, hht⟩ := hnz
    refine ⟨t, ht, ?_⟩
    intro hat
    apply hht
    rw [← hs.equation t ht, hat, mul_zero]
  obtain ⟨⟨t, ht, hat⟩, ⟨s, hst, has⟩⟩ :=
    continuous_zero_integral_changesSign hT hs.continuous_a
      (hs.integral_acceleration_zero hT.le) hanz
  constructor
  · refine ⟨t, ht, ?_⟩
    rw [← hs.equation t ht]
    exact mul_neg_of_pos_of_neg (hs.positive t ht) hat
  · refine ⟨s, hst, ?_⟩
    rw [← hs.equation s hst]
    exact mul_pos (hs.positive s hst) has

/-- The normalized mean in the problem fixes the kinetic energy exactly. -/
theorem energy_eq_one {h x v a : ℝ → ℝ}
    (hs : IsClassicalSolution 1 h x v a)
    (hmean : (∫ t in (0 : ℝ)..1, h t) = -1) :
    (∫ t in (0 : ℝ)..1, (v t) ^ 2) = 1 := by
  have hid := hs.energy_identity (by norm_num)
  linarith

end IsClassicalSolution

/-- The differentiated logarithmic energy used on the positive sixth-order
profile. No compactness or limiting collision statement is assumed here. -/
theorem logarithmic_energy_derivative {ε t : ℝ} {x v : ℝ → ℝ}
    (hx : HasDerivAt x (v t) t)
    (hv : HasDerivAt v (ε * t ^ 6 / x t) t) (hxt : x t ≠ 0) :
    HasDerivAt (fun s => (v s) ^ 2 / 2 - ε * s ^ 6 * Real.log (x s))
      (-6 * ε * t ^ 5 * Real.log (x t)) t := by
  convert ((hv.pow 2).div_const 2).sub
    ((((hasDerivAt_id t).pow 6).const_mul ε).mul (hx.log hxt)) using 1
  field_simp
  ring

/-- The auxiliary logarithmic energy in the normalized endpoint-slope bound. -/
theorem slope_energy_derivative {lam t : ℝ} {u v : ℝ → ℝ}
    (hu : HasDerivAt u (v t) t)
    (hv : HasDerivAt v (lam * t ^ 6 / u t) t) (hut : u t ≠ 0) :
    HasDerivAt (fun s => (v s) ^ 2 / 2 - lam * Real.log (u s))
      (lam * v t * (t ^ 6 - 1) / u t) t := by
  convert ((hv.pow 2).div_const 2).sub ((hu.log hut).const_mul lam) using 1
  field_simp
  ring

/-- Exact integral for the elementary singular coefficient that appears
when a trajectory has the lower bound `x ≥ d + s`. -/
theorem integral_reciprocal_square {d : ℝ} (hd : 0 < d) :
    (∫ s in (0 : ℝ)..1, 1 / (d + s) ^ 2) = 1 / d - 1 / (d + 1) := by
  have hnz : ∀ s ∈ Icc (0 : ℝ) 1, d + s ≠ 0 := by
    intro s hs
    exact ne_of_gt (add_pos_of_pos_of_nonneg hd hs.1)
  have hderiv : ∀ s ∈ uIcc (0 : ℝ) 1,
      HasDerivAt (fun t : ℝ => -(d + t)⁻¹) (1 / (d + s) ^ 2) s := by
    intro s hs
    have hs' : s ∈ Icc (0 : ℝ) 1 := by simpa using hs
    simpa only [neg_div, neg_neg] using
      (((hasDerivAt_id s).const_add d).inv (hnz s hs')).neg
  have hcont : ContinuousOn (fun s : ℝ => 1 / (d + s) ^ 2) (Icc 0 1) :=
    continuousOn_const.div ((continuousOn_const.add continuousOn_id).pow 2)
      (fun s hs => pow_ne_zero 2 (hnz s hs))
  have hFTC := intervalIntegral.integral_eq_sub_of_hasDerivAt hderiv
    (hcont.intervalIntegrable_of_Icc (by norm_num))
  simpa only [add_zero, one_div, neg_sub_neg] using hFTC

/-- The sixth-order zero and fourth-order exit height produce a quadratic
bound for the singular part of the outer variational integral. -/
theorem sixth_order_outer_kernel_bound {ε τ : ℝ} (hε : 0 ≤ ε) (hτ : τ ≠ 0) :
    (∫ s in (0 : ℝ)..1, ε * τ ^ 6 / (τ ^ 4 + s) ^ 2) ≤ ε * τ ^ 2 := by
  have hτ4 : 0 < τ ^ 4 := by
    have hτ2 : τ ^ 2 ≠ 0 := pow_ne_zero 2 hτ
    have hpos := sq_pos_iff.mpr hτ2
    nlinarith
  have hτ6 : 0 ≤ τ ^ 6 := by nlinarith [sq_nonneg (τ ^ 3)]
  have hfactor : 0 ≤ ε * τ ^ 6 := mul_nonneg hε hτ6
  calc
    (∫ s in (0 : ℝ)..1, ε * τ ^ 6 / (τ ^ 4 + s) ^ 2)
        = ε * τ ^ 6 * (∫ s in (0 : ℝ)..1, 1 / (τ ^ 4 + s) ^ 2) := by
          rw [← intervalIntegral.integral_const_mul]
          apply intervalIntegral.integral_congr
          intro s _
          ring
    _ = ε * τ ^ 6 * (1 / τ ^ 4 - 1 / (τ ^ 4 + 1)) := by
      rw [integral_reciprocal_square hτ4]
    _ ≤ ε * τ ^ 6 * (1 / τ ^ 4) := by
      apply mul_le_mul_of_nonneg_left _ hfactor
      have hp : 0 ≤ 1 / (τ ^ 4 + 1) :=
        div_nonneg (by norm_num) (by linarith)
      linarith
    _ = ε * τ ^ 2 := by
      field_simp
      ring

/-- The same singular integral with a positive outgoing speed `c`. -/
theorem scaled_sixth_order_kernel_bound {τ c : ℝ} (hτ : τ ≠ 0) (hc : 0 < c) :
    (∫ s in (0 : ℝ)..1, τ ^ 6 / (τ ^ 4 + c * s) ^ 2) ≤ τ ^ 2 / c := by
  have hτ4 : 0 < τ ^ 4 := by
    have hpos := sq_pos_iff.mpr (pow_ne_zero 2 hτ)
    nlinarith
  have hτ6 : 0 ≤ τ ^ 6 := by nlinarith [sq_nonneg (τ ^ 3)]
  have hc0 := ne_of_gt hc
  have hfactor : 0 ≤ τ ^ 6 / c ^ 2 := div_nonneg hτ6 (sq_nonneg c)
  calc
    (∫ s in (0 : ℝ)..1, τ ^ 6 / (τ ^ 4 + c * s) ^ 2)
        = (τ ^ 6 / c ^ 2) * (∫ s in (0 : ℝ)..1, 1 / (τ ^ 4 / c + s) ^ 2) := by
          rw [← intervalIntegral.integral_const_mul]
          apply intervalIntegral.integral_congr
          intro s _
          field_simp
          ring
    _ = (τ ^ 6 / c ^ 2) * (1 / (τ ^ 4 / c) - 1 / (τ ^ 4 / c + 1)) := by
      rw [integral_reciprocal_square (div_pos hτ4 hc)]
    _ ≤ (τ ^ 6 / c ^ 2) * (1 / (τ ^ 4 / c)) := by
      apply mul_le_mul_of_nonneg_left _ hfactor
      have hp : 0 ≤ 1 / (τ ^ 4 / c + 1) :=
        div_nonneg (by norm_num) (by linarith [div_pos hτ4 hc])
      linarith
    _ = τ ^ 2 / c := by
      field_simp
      ring

/-- A quantified outer variational estimate from the manuscript's actual
trajectory lower bound and time-coordinate bound. For fixed positive `c`
and fixed `K`, the right side is `O(ε * (1 + τ²))` uniformly in `τ ≠ 0`.
This proves the integral estimate only; it does not assert existence of the
trajectories or their parameter derivatives. -/
theorem outer_variational_integral_bound {ε τ c K : ℝ} {θ y : ℝ → ℝ}
    (hε : 0 ≤ ε) (hτ : τ ≠ 0) (hc : 0 < c) (hK : 0 ≤ K)
    (hθ : ContinuousOn θ (Icc (0 : ℝ) 1))
    (hy : ContinuousOn y (Icc (0 : ℝ) 1))
    (hlower : ∀ s ∈ Icc (0 : ℝ) 1, τ ^ 4 + c * s ≤ y s)
    (hupper : ∀ s ∈ Icc (0 : ℝ) 1, |θ s| ≤ K * (|τ| + s)) :
    (∫ s in (0 : ℝ)..1, ε * (θ s) ^ 6 / (y s) ^ 2)
      ≤ 32 * ε * K ^ 6 * (τ ^ 2 / c + 1 / c ^ 2) := by
  have hτ4 : 0 < τ ^ 4 := by
    have hpos := sq_pos_iff.mpr (pow_ne_zero 2 hτ)
    nlinarith
  have hτ6 : 0 ≤ τ ^ 6 := by nlinarith [sq_nonneg (τ ^ 3)]
  have hc2 : 0 < c ^ 2 := sq_pos_iff.mpr (ne_of_gt hc)
  have hK6 : 0 ≤ K ^ 6 := pow_nonneg hK 6
  have hfactor : 0 ≤ 32 * ε * K ^ 6 := mul_nonneg (by linarith) hK6
  have hbase : ∀ s ∈ Icc (0 : ℝ) 1, 0 < τ ^ 4 + c * s := by
    intro s hs
    exact add_pos_of_pos_of_nonneg hτ4 (mul_nonneg hc.le hs.1)
  have hypos : ∀ s ∈ Icc (0 : ℝ) 1, 0 < y s := by
    intro s hs
    exact lt_of_lt_of_le (hbase s hs) (hlower s hs)
  have hg : ContinuousOn (fun s : ℝ => τ ^ 6 / (τ ^ 4 + c * s) ^ 2) (Icc 0 1) :=
    continuousOn_const.div
      ((continuousOn_const.add (continuousOn_const.mul continuousOn_id)).pow 2)
      (fun s hs => pow_ne_zero 2 (ne_of_gt (hbase s hs)))
  have hleft : ContinuousOn (fun s : ℝ => ε * (θ s) ^ 6 / (y s) ^ 2) (Icc 0 1) :=
    (continuousOn_const.mul (hθ.pow 6)).div (hy.pow 2)
      (fun s hs => pow_ne_zero 2 (ne_of_gt (hypos s hs)))
  have hpoint : ∀ s ∈ Icc (0 : ℝ) 1,
      ε * (θ s) ^ 6 / (y s) ^ 2
        ≤ (32 * ε * K ^ 6) * (τ ^ 6 / (τ ^ 4 + c * s) ^ 2 + 1 / c ^ 2) := by
    intro s hs
    have heven : Even (6 : ℕ) := by decide
    have hadd := add_pow_le (abs_nonneg τ) hs.1 6
    norm_num [heven.pow_abs] at hadd
    have hnum : (θ s) ^ 6 ≤ (32 * K ^ 6) * (τ ^ 6 + s ^ 6) := by
      calc
        (θ s) ^ 6 = |θ s| ^ 6 := (heven.pow_abs (θ s)).symm
        _ ≤ (K * (|τ| + s)) ^ 6 := pow_le_pow_left₀ (abs_nonneg (θ s)) (hupper s hs) 6
        _ = K ^ 6 * (|τ| + s) ^ 6 := mul_pow _ _ _
        _ ≤ K ^ 6 * (32 * (τ ^ 6 + s ^ 6)) := mul_le_mul_of_nonneg_left hadd hK6
        _ = (32 * K ^ 6) * (τ ^ 6 + s ^ 6) := by ring
    have hden : (τ ^ 4 + c * s) ^ 2 ≤ (y s) ^ 2 :=
      pow_le_pow_left₀ (hbase s hs).le (hlower s hs) 2
    have hfirst : τ ^ 6 / (y s) ^ 2 ≤ τ ^ 6 / (τ ^ 4 + c * s) ^ 2 :=
      div_le_div_of_nonneg_left hτ6 (sq_pos_iff.mpr (ne_of_gt (hbase s hs))) hden
    have hlast : s ^ 6 / (y s) ^ 2 ≤ 1 / c ^ 2 := by
      have hs62 : s ^ 6 ≤ s ^ 2 := pow_le_pow_of_le_one hs.1 hs.2 (by norm_num)
      have hcs : c * s ≤ y s := by linarith [hlower s hs]
      have hcs2 : (c * s) ^ 2 ≤ (y s) ^ 2 :=
        pow_le_pow_left₀ (mul_nonneg hc.le hs.1) hcs 2
      apply (div_le_div_iff₀ (sq_pos_iff.mpr (ne_of_gt (hypos s hs))) hc2).2
      nlinarith [mul_le_mul_of_nonneg_left hs62 hc2.le]
    calc
      ε * (θ s) ^ 6 / (y s) ^ 2
          ≤ ε * ((32 * K ^ 6) * (τ ^ 6 + s ^ 6)) / (y s) ^ 2 :=
        div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left hnum hε) (sq_nonneg (y s))
      _ = (32 * ε * K ^ 6) * (τ ^ 6 / (y s) ^ 2 + s ^ 6 / (y s) ^ 2) := by ring
      _ ≤ (32 * ε * K ^ 6) * (τ ^ 6 / (τ ^ 4 + c * s) ^ 2 + 1 / c ^ 2) :=
        mul_le_mul_of_nonneg_left (add_le_add hfirst hlast) hfactor
  calc
    (∫ s in (0 : ℝ)..1, ε * (θ s) ^ 6 / (y s) ^ 2)
        ≤ ∫ s in (0 : ℝ)..1,
            (32 * ε * K ^ 6) * (τ ^ 6 / (τ ^ 4 + c * s) ^ 2 + 1 / c ^ 2) :=
      intervalIntegral.integral_mono_on (by norm_num)
        (hleft.intervalIntegrable_of_Icc (by norm_num))
        ((continuousOn_const.mul (hg.add continuousOn_const)).intervalIntegrable_of_Icc
          (by norm_num)) hpoint
    _ = (32 * ε * K ^ 6) *
        ((∫ s in (0 : ℝ)..1, τ ^ 6 / (τ ^ 4 + c * s) ^ 2) + 1 / c ^ 2) := by
      rw [intervalIntegral.integral_const_mul,
        intervalIntegral.integral_add (hg.intervalIntegrable_of_Icc (by norm_num))
          (continuous_const.intervalIntegrable 0 1)]
      simp
    _ ≤ 32 * ε * K ^ 6 * (τ ^ 2 / c + 1 / c ^ 2) :=
      mul_le_mul_of_nonneg_left (add_le_add_right (scaled_sixth_order_kernel_bound hτ hc) _) hfactor

/-- A classical arc without positivity or endpoint matching. This permits
separate incoming and outgoing velocities at a collision endpoint. -/
structure ClassicalArc (l r : ℝ) (f x v a : ℝ → ℝ) : Prop where
  continuous_v : ContinuousOn v (Icc l r)
  continuous_a : ContinuousOn a (Icc l r)
  dx : ∀ t ∈ Icc l r, HasDerivWithinAt x (v t) (Icc l r) t
  dv : ∀ t ∈ Icc l r, HasDerivWithinAt v (a t) (Icc l r) t
  equation : ∀ t ∈ Icc l r, x t * a t = f t

/-- Energy identity on a single closed classical arc. -/
theorem ClassicalArc.energy_identity {l r : ℝ} {f x v a : ℝ → ℝ}
    (hs : ClassicalArc l r f x v a) (hlr : l ≤ r) :
    (∫ t in l..r, (v t) ^ 2)
      = x r * v r - x l * v l - (∫ t in l..r, f t) := by
  have hdx : ∀ t ∈ uIcc l r, HasDerivWithinAt x (v t) (uIcc l r) t := by
    simpa only [uIcc_of_le hlr] using hs.dx
  have hdv : ∀ t ∈ uIcc l r, HasDerivWithinAt v (a t) (uIcc l r) t := by
    simpa only [uIcc_of_le hlr] using hs.dv
  have hip := intervalIntegral.integral_mul_deriv_eq_deriv_mul_of_hasDerivWithinAt
    hdx hdv (hs.continuous_v.intervalIntegrable_of_Icc hlr)
    (hs.continuous_a.intervalIntegrable_of_Icc hlr)
  have heq : (∫ t in l..r, f t) = ∫ t in l..r, x t * a t := by
    apply intervalIntegral.integral_congr
    intro t ht
    exact (hs.equation t (by simpa only [uIcc_of_le hlr] using ht)).symm
  rw [← heq] at hip
  simp only [← pow_two] at hip
  linarith

/-- The impulsive energy identity, including a collision at zero. Incoming
and outgoing velocities at zero may differ: the boundary terms disappear
because `x 0 = 0`. The hypotheses explicitly require classical one-sided
arcs; no distributional integration rule is assumed. -/
theorem collision_impulse_energy_identity {ε A : ℝ}
    {x vMinus vPlus aMinus aPlus : ℝ → ℝ}
    (hleft : ClassicalArc (-1) 0 (fun t => ε * t ^ 6) x vMinus aMinus)
    (hright : ClassicalArc 0 1 (fun t => ε * t ^ 6) x vPlus aPlus)
    (hzero : x 0 = 0) (hxleft : x (-1) = A) (hxright : x 1 = A)
    (hA : A ≠ 0) (hkick : vPlus 1 - vMinus (-1) = 2 / A) :
    (∫ t in (-1 : ℝ)..0, (vMinus t) ^ 2) +
      (∫ t in (0 : ℝ)..1, (vPlus t) ^ 2) = 2 - 2 * ε / 7 := by
  have hEL := hleft.energy_identity (by norm_num)
  have hER := hright.energy_identity (by norm_num)
  have hpL : (∫ t in (-1 : ℝ)..0, ε * t ^ 6) = ε / 7 := by
    rw [intervalIntegral.integral_const_mul, integral_pow]
    norm_num
    ring
  have hpR : (∫ t in (0 : ℝ)..1, ε * t ^ 6) = ε / 7 := by
    rw [intervalIntegral.integral_const_mul, integral_pow]
    norm_num
    ring
  rw [hzero, hxleft, zero_mul, hpL] at hEL
  rw [hzero, hxright, zero_mul, hpR] at hER
  have hjump : A * (vPlus 1 - vMinus (-1)) = 2 := by
    rw [hkick]
    field_simp
  nlinarith

#print axioms IsClassicalSolution.energy_identity
#print axioms IsClassicalSolution.mean_negative
#print axioms IsClassicalSolution.force_balance
#print axioms IsClassicalSolution.forcing_changes_sign
#print axioms logarithmic_energy_derivative
#print axioms slope_energy_derivative
#print axioms sixth_order_outer_kernel_bound
#print axioms outer_variational_integral_bound
#print axioms collision_impulse_energy_identity

end ReciprocalCounterexample
