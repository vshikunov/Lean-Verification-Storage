import ReciprocalCounterexample.FlatCoreLogApplication
import ReciprocalCounterexample.FlatCoreParameters
import ReciprocalCounterexample.FlatCorePulse

/-!
# The flat-core counterexample

This file assembles the actual ODE estimates for the smooth flat-core forcing
and normalizes its period and negative mean to those in the original problem.
-/
noncomputable section
open Set MeasureTheory
open scoped Interval

namespace ReciprocalCounterexample


/-- Every sufficiently small member of the explicit smooth family has no
strictly positive classical periodic solution. -/
theorem flatCore_raw_nonexistence {eta : ℝ} (heta : 0 < eta)
    (heta4 : eta ≤ 1/4) (hsmall : flatCoreErrorModulus eta < 1/2) :
    ¬ HasPositivePeriodicSolution (fullPeriod (eta^4/4096))
      (flatCoreRawForcing (eta^2) (eta^4/4096)) := by
  rintro ⟨x, v, a, hs⟩
  have had := flatCore_parameter_admissible heta heta4
  have heps := had.1
  have hδ := had.2.1
  have heta1 : eta ≤ 1 := by linarith
  have heps4 : eta^2 ≤ 1/4 := by nlinarith
  have heta4le : eta^4 ≤ 1 := pow_le_one₀ heta.le heta1
  have hδ2 : eta^4/4096 ≤ 1/2 := by linarith
  have hT4 : fullPeriod (eta^4/4096) ≤ 4 := by
    unfold fullPeriod halfPeriod
    linarith
  have hb := hs.flatCore_bowl hδ
  have hheight := hs.flatCore_bowl_height_le_six heps.le heps4 hδ hδ2
  obtain ⟨hdisp, hacc, hpulse⟩ := hs.flatCore_eta_pulse_bounds heta heta1
  have hdisplacement :
      |x (halfPeriod (eta^4/4096) + 1) - x (halfPeriod (eta^4/4096) + (-1))| ≤
        eta^2/16 := by
    rw [hb.integral_velocity] at hdisp
    exact hdisp
  have hkin0 := hs.flatCore_bowl_kinetic_defect_le heps.le hδ hpulse
  have hkin : |(∫ t in (-1 : ℝ)..1,
      (v (halfPeriod (eta^4/4096) + t))^2) - 2| ≤ 14 * eta^2 := by
    have hmain := mul_le_mul_of_nonneg_left hT4 heps.le
    linarith only [hkin0, hmain, heps]
  have hlower := hb.flatCore_error_modulus_lower heta heta1 hheight hacc hdisplacement hkin
  exact (not_lt_of_ge hlower) hsmall

/-- The original theorem: a smooth even sign-changing one-periodic forcing
of mean minus one whose equation has no positive classical periodic solution. -/
theorem mainTheorem_flatCore : MainTheorem := by
  obtain ⟨eta, heta, heta4, hsmall⟩ := exists_small_flatCore_parameter
  have had := flatCore_parameter_admissible heta heta4
  exact main_of_flatCore_nonexistence had.1 had.2.1
    (lt_trans had.2.2.2 (by norm_num)) (flatCore_raw_nonexistence heta heta4 hsmall)

#print axioms flatCore_raw_nonexistence
#print axioms mainTheorem_flatCore

end ReciprocalCounterexample
