import ReciprocalCounterexample.FlatCoreSolution
import Mathlib.Analysis.SpecialFunctions.Sqrt

/-! Algebra of the small parameters in the smooth counterexample family. -/
noncomputable section
open Set MeasureTheory
open scoped Interval
namespace ReciprocalCounterexample

/-- The pulse is much shorter than the positive forcing scale. -/
theorem flatCore_parameter_admissible {eta : ℝ} (heta : 0 < eta)
    (heta4 : eta ≤ 1/4) :
    0 < eta^2 ∧ 0 < eta^4 / 4096 ∧
      eta^4 / 4096 ≤ eta^2 / 2048 ∧
      eta^2 * fullPeriod (eta^4 / 4096) < 1 := by
  have heta1 : eta ≤ 1 := by linarith
  have he2 : 0 < eta^2 := sq_pos_of_pos heta
  have he4 : 0 < eta^4 := pow_pos heta 4
  have he21 : eta^2 ≤ 1 := pow_le_one₀ heta.le heta1
  have he41 : eta^4 ≤ 1 := pow_le_one₀ heta.le heta1
  have he24 : eta^2 ≤ 1/16 := by nlinarith
  have he42 : eta^4 ≤ eta^2 := by nlinarith [sq_nonneg (eta^2 - 1/2)]
  have hδ : 0 < eta^4 / 4096 := div_pos he4 (by norm_num)
  have hδ1 : eta^4 / 4096 ≤ 1/4096 := by linarith
  have hT : fullPeriod (eta^4/4096) ≤ 3 := by
    unfold fullPeriod halfPeriod
    linarith
  refine ⟨he2, hδ, ?_, ?_⟩
  · nlinarith
  · have hp := mul_le_mul_of_nonneg_left hT he2.le
    nlinarith


/-- The square root of the pulse width has an exact polynomial form. -/
theorem flatCore_parameter_sqrt_delta (eta : ℝ) :
    Real.sqrt (eta^4 / 4096) = eta^2 / 64 := by
  have heq : eta^4 / 4096 = (eta^2 / 64)^2 := by ring
  rw [heq, Real.sqrt_sq_eq_abs, abs_of_nonneg (div_nonneg (sq_nonneg eta) (by norm_num))]

/-- The explicit pulse-energy majorant is small relative to the parameter. -/
theorem flatCore_parameter_kinetic_error {eta : ℝ} (heta : 0 < eta)
    (heta4 : eta ≤ 1/4) :
    eta^2 * fullPeriod (eta^4 / 4096) + 32 * (eta^4 / 4096)^2 +
      36864 * (eta^4 / 4096) / eta^2 ≤ 13 * eta^2 := by
  have he2 : 0 < eta^2 := sq_pos_of_pos heta
  have he4 : eta^4 ≤ 1 := pow_le_one₀ heta.le (by linarith : eta ≤ 1)
  have had := flatCore_parameter_admissible heta heta4
  have hd0 := had.2.1
  have hdε := had.2.2.1
  have hd1 : eta^4 / 4096 ≤ 1 := by linarith
  have hT : fullPeriod (eta^4 / 4096) ≤ 3 := by
    unfold fullPeriod halfPeriod
    linarith
  have hmain := mul_le_mul_of_nonneg_left hT he2.le
  have hdsq : (eta^4/4096)^2 ≤ eta^4/4096 := by
    nlinarith [mul_nonneg hd0.le (sub_nonneg.mpr hd1)]
  have hsmall : 32 * (eta^4/4096)^2 ≤ eta^2 := by nlinarith
  have hratio : 36864 * (eta^4 / 4096) / eta^2 = 9 * eta^2 := by
    field_simp
    ring
  rw [hratio]
  linarith only [hmain, hsmall]

end ReciprocalCounterexample
