import ReciprocalCounterexample.FlatCoreMain
import ReciprocalCounterexample.FlatCoreExplicit

/-! A specified forcing together with all of the requested properties. -/
noncomputable section
open Set MeasureTheory
open scoped Interval ContDiff
namespace ReciprocalCounterexample

def explicitCounterexampleForcing : ℝ → ℝ :=
  normalizedForcing
    (fullPeriod (explicitFlatCoreParameter ^ 4 / 4096))
    (flatCoreMass (explicitFlatCoreParameter ^ 2) (explicitFlatCoreParameter ^ 4 / 4096))
    (flatCoreRawForcing (explicitFlatCoreParameter ^ 2) (explicitFlatCoreParameter ^ 4 / 4096))

/-- An actual named forcing, with every property checked and no remaining
nonexistence hypothesis. -/
theorem explicitCounterexampleForcing_isCounterexample :
    IsCounterexample explicitCounterexampleForcing := by
  let η := explicitFlatCoreParameter
  let ε := η ^ 2
  let δ := η ^ 4 / 4096
  have had := flatCore_parameter_admissible explicitFlatCoreParameter_pos
    explicitFlatCoreParameter_le_quarter
  have hε : 0 < ε := had.1
  have hδ : 0 < δ := had.2.1
  have hmass : ε * fullPeriod δ < 1 := had.2.2.2
  have hT : 0 < fullPeriod δ := by unfold fullPeriod halfPeriod; linarith
  have hM : 0 < flatCoreMass ε δ := by
    linarith [(flatCoreMass_bounds hε.le hδ).1]
  have hno : ¬ HasPositivePeriodicSolution (fullPeriod δ) (flatCoreRawForcing ε δ) :=
    flatCore_raw_nonexistence explicitFlatCoreParameter_pos
      explicitFlatCoreParameter_le_quarter explicitFlatCoreParameter_error
  exact normalized_isCounterexample hT hM (flatCoreRawForcing_contDiff hδ)
    (flatCoreRawForcing_periodic ε δ) (flatCoreRawForcing_even ε δ)
    (flatCoreRawForcing_sign_change hε hδ) (flatCoreRawForcing_integral hδ) hno

/-- Unconditional main theorem with the specified witness above. -/
theorem mainTheorem_explicit : MainTheorem :=
  ⟨explicitCounterexampleForcing, explicitCounterexampleForcing_isCounterexample⟩

#print axioms explicitCounterexampleForcing_isCounterexample
#print axioms mainTheorem_explicit
end ReciprocalCounterexample
