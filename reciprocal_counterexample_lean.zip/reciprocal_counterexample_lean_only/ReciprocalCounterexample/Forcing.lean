import Mathlib.Analysis.SpecialFunctions.SmoothTransition
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Basic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Linarith

/-!
# The exact smooth half-period forcing

This file treats the explicit profile on the real line whose restriction to
`[0, 1 + 2*δ]` is reflected and then repeated in the manuscript.  It does not
assert smoothness of that periodic extension or the nonexistence of solutions.
-/

noncomputable section

open scoped ContDiff
open MeasureTheory Set

namespace ReciprocalCounterexample

/-- The piecewise exponential function printed in equation (2.1). -/
def flatBump (s : ℝ) : ℝ := if 0 < s then Real.exp (-1 / s) else 0

theorem expNegInvGlue_eq_flatBump (s : ℝ) : expNegInvGlue s = flatBump s := by
  by_cases hs : s ≤ 0
  · simp [expNegInvGlue, flatBump, hs, not_lt.mpr hs]
  · simp [expNegInvGlue, flatBump, hs, lt_of_not_ge hs, div_eq_mul_inv]

/-- The exact transition function used in the manuscript. -/
def smoothStep : ℝ → ℝ := Real.smoothTransition

theorem smoothStep_exact_formula (s : ℝ) :
    smoothStep s = flatBump s / (flatBump s + flatBump (1 - s)) := by
  simp [smoothStep, Real.smoothTransition, expNegInvGlue_eq_flatBump]

theorem smoothStep_contDiff : ContDiff ℝ ∞ smoothStep :=
  Real.smoothTransition.contDiff

theorem smoothStep_zero_of_nonpos {s : ℝ} (hs : s ≤ 0) : smoothStep s = 0 :=
  Real.smoothTransition.zero_of_nonpos hs

theorem smoothStep_one_of_one_le {s : ℝ} (hs : 1 ≤ s) : smoothStep s = 1 :=
  Real.smoothTransition.one_of_one_le hs

theorem smoothStep_nonneg (s : ℝ) : 0 ≤ smoothStep s :=
  Real.smoothTransition.nonneg s

theorem smoothStep_le_one (s : ℝ) : smoothStep s ≤ 1 :=
  Real.smoothTransition.le_one s

theorem smoothStep_reflection (s : ℝ) : smoothStep (1 - s) = 1 - smoothStep s := by
  have hd : expNegInvGlue s + expNegInvGlue (1 - s) ≠ 0 :=
    ne_of_gt (Real.smoothTransition.pos_denom s)
  unfold smoothStep Real.smoothTransition
  rw [show 1 - (1 - s) = s by ring,
    add_comm (expNegInvGlue (1 - s)) (expNegInvGlue s)]
  field_simp

theorem smoothStep_integral : (∫ s in (0 : ℝ)..1, smoothStep s) = 1 / 2 := by
  have hI : IntervalIntegrable smoothStep volume (0 : ℝ) 1 :=
    smoothStep_contDiff.continuous.intervalIntegrable 0 1
  have hreflect : (∫ s in (0 : ℝ)..1, smoothStep (1 - s)) =
      ∫ s in (0 : ℝ)..1, smoothStep s := by
    rw [intervalIntegral.integral_comp_sub_left]
    norm_num
  simp_rw [smoothStep_reflection] at hreflect
  rw [intervalIntegral.integral_sub intervalIntegrable_const hI] at hreflect
  norm_num at hreflect ⊢
  linarith

/-- The half-period length in the manuscript. -/
def halfPeriod (δ : ℝ) : ℝ := 1 + 2 * δ

/-- Smooth cutoff of the positive sixth-order profile. -/
def positiveProfile (ε δ s : ℝ) : ℝ :=
  ε * s ^ 6 * (1 - smoothStep ((s - 1) / δ))

/-- The nonnegative magnitude of the negative pulse on the half period. -/
def negativePulse (δ s : ℝ) : ℝ :=
  (2 / δ) * smoothStep ((s - 1 - δ) / δ)

/-- The actual expression in equation (2.2), before reflection and repetition. -/
def halfForcing (ε δ s : ℝ) : ℝ :=
  positiveProfile ε δ s - negativePulse δ s

theorem positiveProfile_contDiff (ε δ : ℝ) : ContDiff ℝ ∞ (positiveProfile ε δ) := by
  unfold positiveProfile
  exact (contDiff_const.mul (contDiff_id.pow 6)).mul
    (contDiff_const.sub (smoothStep_contDiff.comp ((contDiff_id.sub contDiff_const).div_const δ)))

theorem negativePulse_contDiff (δ : ℝ) : ContDiff ℝ ∞ (negativePulse δ) := by
  unfold negativePulse
  exact contDiff_const.mul (smoothStep_contDiff.comp
    (((contDiff_id.sub contDiff_const).sub contDiff_const).div_const δ))

theorem halfForcing_contDiff (ε δ : ℝ) : ContDiff ℝ ∞ (halfForcing ε δ) :=
  (positiveProfile_contDiff ε δ).sub (negativePulse_contDiff δ)

theorem halfForcing_eq_bowl (ε δ s : ℝ) (hδ : 0 < δ) (hs : s ≤ 1) :
    halfForcing ε δ s = ε * s ^ 6 := by
  have h₁ : (s - 1) / δ ≤ 0 := div_nonpos_of_nonpos_of_nonneg (by linarith) hδ.le
  have h₂ : (s - 1 - δ) / δ ≤ 0 :=
    div_nonpos_of_nonpos_of_nonneg (by linarith) hδ.le
  simp [halfForcing, positiveProfile, negativePulse,
    smoothStep_zero_of_nonpos h₁, smoothStep_zero_of_nonpos h₂]

theorem halfForcing_pos_on_bowl (ε δ s : ℝ)
    (hε : 0 < ε) (hδ : 0 < δ) (hs : 0 < s) (hs₁ : s ≤ 1) :
    0 < halfForcing ε δ s := by
  rw [halfForcing_eq_bowl ε δ s hδ hs₁]
  exact mul_pos hε (pow_pos hs 6)

theorem halfForcing_at_halfPeriod (ε δ : ℝ) (hδ : 0 < δ) :
    halfForcing ε δ (halfPeriod δ) = -(2 / δ) := by
  have hδ0 : δ ≠ 0 := ne_of_gt hδ
  have h₁ : (halfPeriod δ - 1) / δ = 2 := by
    unfold halfPeriod
    field_simp
  have h₂ : (halfPeriod δ - 1 - δ) / δ = 1 := by
    unfold halfPeriod
    field_simp
    ring
  simp [halfForcing, positiveProfile, negativePulse, h₁, h₂,
    smoothStep_one_of_one_le (by norm_num : (1 : ℝ) ≤ 2),
    smoothStep_one_of_one_le (le_refl (1 : ℝ))]

theorem halfForcing_negative_at_halfPeriod (ε δ : ℝ) (hδ : 0 < δ) :
    halfForcing ε δ (halfPeriod δ) < 0 := by
  rw [halfForcing_at_halfPeriod ε δ hδ]
  exact neg_neg_of_pos (div_pos (by norm_num) hδ)

theorem halfForcing_sign_change (ε δ : ℝ) (hε : 0 < ε) (hδ : 0 < δ) :
    (∃ s, 0 < halfForcing ε δ s) ∧ (∃ s, halfForcing ε δ s < 0) := by
  constructor
  · exact ⟨1, halfForcing_pos_on_bowl ε δ 1 hε hδ (by norm_num) le_rfl⟩
  · exact ⟨halfPeriod δ, halfForcing_negative_at_halfPeriod ε δ hδ⟩

theorem negativePulse_zero_before (δ s : ℝ) (hδ : 0 < δ) (hs : s ≤ 1 + δ) :
    negativePulse δ s = 0 := by
  have ht : (s - 1 - δ) / δ ≤ 0 :=
    div_nonpos_of_nonpos_of_nonneg (by linarith) hδ.le
  simp [negativePulse, smoothStep_zero_of_nonpos ht]

theorem negativePulse_integral_transition (δ : ℝ) (hδ : 0 < δ) :
    (∫ s in (1 + δ)..halfPeriod δ, negativePulse δ s) = 1 := by
  have hδ0 : δ ≠ 0 := ne_of_gt hδ
  have harg (s : ℝ) : (s - 1 - δ) / δ = s / δ + (-1 - δ) / δ := by ring
  have hlo : (1 + δ) / δ + (-1 - δ) / δ = 0 := by
    field_simp
  have hhi : halfPeriod δ / δ + (-1 - δ) / δ = 1 := by
    unfold halfPeriod
    field_simp
    ring
  unfold negativePulse
  rw [intervalIntegral.integral_const_mul]
  simp_rw [harg]
  rw [intervalIntegral.integral_comp_div_add smoothStep hδ0 ((-1 - δ) / δ),
    hlo, hhi, smoothStep_integral]
  simp only [smul_eq_mul]
  field_simp

/-- The negative pulse has mass exactly one on each half period. -/
theorem negativePulse_integral_halfPeriod (δ : ℝ) (hδ : 0 < δ) :
    (∫ s in (0 : ℝ)..halfPeriod δ, negativePulse δ s) = 1 := by
  have hI (a b : ℝ) : IntervalIntegrable (negativePulse δ) volume a b :=
    (negativePulse_contDiff δ).continuous.intervalIntegrable a b
  have hzero : (∫ s in (0 : ℝ)..(1 + δ), negativePulse δ s) = 0 := by
    calc
      (∫ s in (0 : ℝ)..(1 + δ), negativePulse δ s) =
          ∫ _s in (0 : ℝ)..(1 + δ), (0 : ℝ) := by
        apply intervalIntegral.integral_congr
        intro s hs
        rw [uIcc_of_le (by linarith : (0 : ℝ) ≤ 1 + δ)] at hs
        exact negativePulse_zero_before δ s hδ hs.2
      _ = 0 := by simp
  rw [← intervalIntegral.integral_add_adjacent_intervals (hI 0 (1 + δ))
    (hI (1 + δ) (halfPeriod δ)), hzero, zero_add]
  exact negativePulse_integral_transition δ hδ

/-- A deliberately coarse explicit bound, sufficient for a negative mean. -/
theorem positiveProfile_integral_bound (ε δ : ℝ)
    (hε : 0 ≤ ε) (hδ : 0 < δ) (hδsmall : δ ≤ 1 / 2) :
    (∫ s in (0 : ℝ)..halfPeriod δ, positiveProfile ε δ s) ≤ 128 * ε := by
  have hL : 0 ≤ halfPeriod δ := by unfold halfPeriod; linarith
  have hL₂ : halfPeriod δ ≤ 2 := by unfold halfPeriod; linarith
  have hpoint : ∀ s ∈ Icc (0 : ℝ) (halfPeriod δ), positiveProfile ε δ s ≤ 64 * ε := by
    intro s hs
    have hs₂ : s ≤ 2 := le_trans hs.2 hL₂
    have hp : s ^ 6 ≤ 64 := by
      have := pow_le_pow_left₀ hs.1 hs₂ 6
      norm_num at this
      exact this
    have hp₀ : 0 ≤ ε * s ^ 6 := mul_nonneg hε (pow_nonneg hs.1 6)
    have hcut : 1 - smoothStep ((s - 1) / δ) ≤ 1 := by
      linarith [smoothStep_nonneg ((s - 1) / δ)]
    unfold positiveProfile
    calc
      ε * s ^ 6 * (1 - smoothStep ((s - 1) / δ)) ≤ ε * s ^ 6 * 1 :=
        mul_le_mul_of_nonneg_left hcut hp₀
      _ ≤ 64 * ε := by nlinarith
  have hbound := intervalIntegral.integral_mono_on hL
    ((positiveProfile_contDiff ε δ).continuous.intervalIntegrable 0 (halfPeriod δ))
    (intervalIntegrable_const : IntervalIntegrable (fun _ : ℝ => 64 * ε) volume
      (0 : ℝ) (halfPeriod δ)) hpoint
  simp only [intervalIntegral.integral_const, sub_zero, smul_eq_mul] at hbound
  nlinarith

/-- Negativity of the half-period integral is established for concrete small-parameter ranges. -/
theorem halfForcing_integral_negative (ε δ : ℝ)
    (hε : 0 ≤ ε) (hεsmall : ε < 1 / 128) (hδ : 0 < δ) (hδsmall : δ ≤ 1 / 2) :
    (∫ s in (0 : ℝ)..halfPeriod δ, halfForcing ε δ s) < 0 := by
  have hp := positiveProfile_integral_bound ε δ hε hδ hδsmall
  unfold halfForcing
  rw [intervalIntegral.integral_sub
    ((positiveProfile_contDiff ε δ).continuous.intervalIntegrable 0 (halfPeriod δ))
    ((negativePulse_contDiff δ).continuous.intervalIntegrable 0 (halfPeriod δ)),
    negativePulse_integral_halfPeriod δ hδ]
  linarith

end ReciprocalCounterexample

#print axioms ReciprocalCounterexample.smoothStep_contDiff
#print axioms ReciprocalCounterexample.smoothStep_exact_formula
#print axioms ReciprocalCounterexample.smoothStep_integral
#print axioms ReciprocalCounterexample.halfForcing_contDiff
#print axioms ReciprocalCounterexample.halfForcing_sign_change
#print axioms ReciprocalCounterexample.negativePulse_integral_halfPeriod
#print axioms ReciprocalCounterexample.halfForcing_integral_negative
