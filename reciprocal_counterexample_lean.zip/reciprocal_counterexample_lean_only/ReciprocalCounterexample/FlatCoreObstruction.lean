import Mathlib.MeasureTheory.Integral.IntervalIntegral.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# A quantitative obstruction caused by an affine core

A nondecreasing velocity with equal values at the two ends of a centered core
cannot have both small mean and squared speed close to one in L1. This removes
the need to identify a subsequential limiting reflected trajectory.
-/
noncomputable section
open Set MeasureTheory
open scoped Interval

namespace ReciprocalCounterexample

lemma velocity_abs_bound (z : ℝ) : |z| ≤ 1 + |z ^ 2 - 1| := by
  by_cases h : |z| ≤ 1
  · linarith [abs_nonneg (z ^ 2 - 1)]
  · have hp : 0 ≤ |z| * (|z| - 1) := mul_nonneg (abs_nonneg z) (by linarith)
    nlinarith [sq_abs z, le_abs_self (z ^ 2 - 1)]

lemma nonnegative_velocity_lower {z : ℝ} (hz : 0 ≤ z) :
    1 - |z ^ 2 - 1| ≤ z := by
  by_cases h : 1 ≤ z
  · linarith [abs_nonneg (z ^ 2 - 1)]
  · have hp : 0 ≤ z * (1 - z) := mul_nonneg hz (by linarith)
    nlinarith [neg_le_abs (z ^ 2 - 1)]

lemma nonpositive_velocity_upper {z : ℝ} (hz : z ≤ 0) :
    z ≤ -1 + |z ^ 2 - 1| := by
  have h := nonnegative_velocity_lower (z := -z) (by linarith)
  simpa only [neg_sq] using (show z ≤ -1 + |(-z) ^ 2 - 1| by linarith)

/-- The lower integral bound when the velocity is nonnegative at `-a`.
No uniform velocity bound is required. -/
theorem flatCore_integral_lower {a : ℝ} {v : ℝ → ℝ}
    (ha : 0 ≤ a) (ha1 : a ≤ 1)
    (hv : ContinuousOn v (Icc (-1 : ℝ) 1))
    (hmono : MonotoneOn v (Icc (-1 : ℝ) 1))
    (hcore : 0 ≤ v (-a)) :
    2 * a ≤ (∫ t in (-1 : ℝ)..1, v t) +
      (∫ t in (-1 : ℝ)..1, |(v t) ^ 2 - 1|) := by
  let D : ℝ → ℝ := fun t => |(v t) ^ 2 - 1|
  have hD : ContinuousOn D (Icc (-1 : ℝ) 1) := (hv.pow 2 |>.sub continuousOn_const).abs
  have hleft : (-1 : ℝ) ≤ -a := by linarith
  have hright : -a ≤ (1 : ℝ) := by linarith
  have hsubL : Icc (-1 : ℝ) (-a) ⊆ Icc (-1 : ℝ) 1 := Icc_subset_Icc le_rfl hright
  have hsubR : Icc (-a) (1 : ℝ) ⊆ Icc (-1 : ℝ) 1 := Icc_subset_Icc hleft le_rfl
  have hvL : IntervalIntegrable v volume (-1) (-a) := (hv.mono hsubL).intervalIntegrable_of_Icc hleft
  have hvR : IntervalIntegrable v volume (-a) 1 := (hv.mono hsubR).intervalIntegrable_of_Icc hright
  have hDL : IntervalIntegrable D volume (-1) (-a) := (hD.mono hsubL).intervalIntegrable_of_Icc hleft
  have hDR : IntervalIntegrable D volume (-a) 1 := (hD.mono hsubR).intervalIntegrable_of_Icc hright
  have hlow : (∫ t in (-1 : ℝ)..(-a), -1 - D t) ≤ ∫ t in (-1 : ℝ)..(-a), v t := by
    apply intervalIntegral.integral_mono_on hleft
      (intervalIntegrable_const.sub hDL) hvL
    intro t ht
    have h := velocity_abs_bound (v t)
    have h' := neg_abs_le (v t)
    dsimp [D]
    linarith
  have hupp : (∫ t in (-a)..(1 : ℝ), 1 - D t) ≤ ∫ t in (-a)..(1 : ℝ), v t := by
    apply intervalIntegral.integral_mono_on hright
      (intervalIntegrable_const.sub hDR) hvR
    intro t ht
    have hvt : 0 ≤ v t := le_trans hcore (hmono ⟨hleft, hright⟩ (hsubR ht) ht.1)
    exact nonnegative_velocity_lower hvt
  rw [intervalIntegral.integral_sub intervalIntegrable_const hDL,
    intervalIntegral.integral_const] at hlow
  rw [intervalIntegral.integral_sub intervalIntegrable_const hDR,
    intervalIntegral.integral_const] at hupp
  simp only [smul_eq_mul] at hlow hupp
  have hsumv := intervalIntegral.integral_add_adjacent_intervals hvL hvR
  have hsumD := intervalIntegral.integral_add_adjacent_intervals hDL hDR
  change 2 * a ≤ (∫ t in (-1 : ℝ)..1, v t) + (∫ t in (-1 : ℝ)..1, D t)
  linarith

/-- A symmetric upper integral estimate when velocity is nonpositive at `a`. -/
theorem flatCore_integral_upper {a : ℝ} {v : ℝ → ℝ}
    (ha : 0 ≤ a) (ha1 : a ≤ 1)
    (hv : ContinuousOn v (Icc (-1 : ℝ) 1))
    (hmono : MonotoneOn v (Icc (-1 : ℝ) 1))
    (hcore : v a ≤ 0) :
    2 * a ≤ -(∫ t in (-1 : ℝ)..1, v t) +
      (∫ t in (-1 : ℝ)..1, |(v t) ^ 2 - 1|) := by
  let D : ℝ → ℝ := fun t => |(v t) ^ 2 - 1|
  have hD : ContinuousOn D (Icc (-1 : ℝ) 1) := (hv.pow 2 |>.sub continuousOn_const).abs
  have hleft : (-1 : ℝ) ≤ a := by linarith
  have hsubL : Icc (-1 : ℝ) a ⊆ Icc (-1 : ℝ) 1 := Icc_subset_Icc le_rfl ha1
  have hsubR : Icc a (1 : ℝ) ⊆ Icc (-1 : ℝ) 1 := Icc_subset_Icc hleft le_rfl
  have hvL : IntervalIntegrable v volume (-1) a := (hv.mono hsubL).intervalIntegrable_of_Icc hleft
  have hvR : IntervalIntegrable v volume a 1 := (hv.mono hsubR).intervalIntegrable_of_Icc ha1
  have hDL : IntervalIntegrable D volume (-1) a := (hD.mono hsubL).intervalIntegrable_of_Icc hleft
  have hDR : IntervalIntegrable D volume a 1 := (hD.mono hsubR).intervalIntegrable_of_Icc ha1
  have hlow : (∫ t in (-1 : ℝ)..a, v t) ≤ ∫ t in (-1 : ℝ)..a, -1 + D t := by
    apply intervalIntegral.integral_mono_on hleft hvL
      (intervalIntegrable_const.add hDL)
    intro t ht
    have hvt : v t ≤ 0 := le_trans (hmono (hsubL ht) ⟨hleft, ha1⟩ ht.2) hcore
    exact nonpositive_velocity_upper hvt
  have hupp : (∫ t in a..(1 : ℝ), v t) ≤ ∫ t in a..(1 : ℝ), 1 + D t := by
    apply intervalIntegral.integral_mono_on ha1 hvR
      (intervalIntegrable_const.add hDR)
    intro t ht
    have h := velocity_abs_bound (v t)
    have h' := le_abs_self (v t)
    dsimp [D]
    linarith
  rw [intervalIntegral.integral_add intervalIntegrable_const hDL,
    intervalIntegral.integral_const] at hlow
  rw [intervalIntegral.integral_add intervalIntegrable_const hDR,
    intervalIntegral.integral_const] at hupp
  simp only [smul_eq_mul] at hlow hupp
  have hsumv := intervalIntegral.integral_add_adjacent_intervals hvL hvR
  have hsumD := intervalIntegral.integral_add_adjacent_intervals hDL hDR
  change 2 * a ≤ -(∫ t in (-1 : ℝ)..1, v t) + (∫ t in (-1 : ℝ)..1, D t)
  linarith

/-- Quantitative flat-core obstruction. Equal velocities at the core endpoints
are sufficient; monotonicity then forces constancy throughout the core. -/
theorem flatCore_obstruction {a : ℝ} {v : ℝ → ℝ}
    (ha : 0 ≤ a) (ha1 : a ≤ 1)
    (hv : ContinuousOn v (Icc (-1 : ℝ) 1))
    (hmono : MonotoneOn v (Icc (-1 : ℝ) 1))
    (hcore : v (-a) = v a) :
    2 * a ≤ |∫ t in (-1 : ℝ)..1, v t| +
      (∫ t in (-1 : ℝ)..1, |(v t) ^ 2 - 1|) := by
  by_cases h : 0 ≤ v (-a)
  · exact (flatCore_integral_lower ha ha1 hv hmono h).trans
      (add_le_add_right (le_abs_self _) _)
  · have h' : v a ≤ 0 := by rw [← hcore]; linarith
    exact (flatCore_integral_upper ha ha1 hv hmono h').trans
      (add_le_add_right (neg_le_abs _) _)

#print axioms flatCore_obstruction
end ReciprocalCounterexample
