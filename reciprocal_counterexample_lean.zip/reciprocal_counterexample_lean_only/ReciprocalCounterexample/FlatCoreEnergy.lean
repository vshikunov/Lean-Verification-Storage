import ReciprocalCounterexample.FlatCoreBounds
import ReciprocalCounterexample.EnergyControl

/-!
# Logarithmic energy for an actual positive bowl

The energy derivative and integral oscillation estimates apply to arbitrary
smooth profiles. Their hypotheses are properties of the actual differential
solution, rather than assumed estimates on an abstract limiting object.
-/
noncomputable section
open Set MeasureTheory
open scoped Interval

namespace ReciprocalCounterexample

def profileEnergy (ε : ℝ) (f x v : ℝ → ℝ) (t : ℝ) : ℝ :=
  (v t)^2 / 2 - ε * f t * Real.log (x t)

namespace PositiveBowl
variable {ε : ℝ} {f fp x v a : ℝ → ℝ}

theorem continuous_log (hs : PositiveBowl ε f x v a) :
    ContinuousOn (fun t => Real.log (x t)) (Icc (-1 : ℝ) 1) :=
  hs.continuous_x.log (fun t ht => ne_of_gt (hs.positive t ht))

theorem continuous_energy (hs : PositiveBowl ε f x v a)
    (hf : ContinuousOn f (Icc (-1 : ℝ) 1)) :
    ContinuousOn (profileEnergy ε f x v) (Icc (-1 : ℝ) 1) :=
  ((hs.continuous_v.pow 2).div_const 2).sub
    ((continuousOn_const.mul hf).mul hs.continuous_log)

theorem energy_derivative (hs : PositiveBowl ε f x v a)
    (hdf : ∀ t ∈ Icc (-1 : ℝ) 1, HasDerivAt f (fp t) t)
    {t : ℝ} (ht : t ∈ Icc (-1 : ℝ) 1) :
    HasDerivWithinAt (profileEnergy ε f x v)
      (-ε * fp t * Real.log (x t)) (Icc (-1 : ℝ) 1) t := by
  have hv := hs.dv t ht
  rw [hs.acceleration_eq ht] at hv
  have hx := hs.dx t ht
  have hxt := ne_of_gt (hs.positive t ht)
  convert ((hv.pow 2).div_const 2).sub
    (((hdf t ht).hasDerivWithinAt.const_mul ε).mul (hx.log hxt)) using 1
  field_simp
  ring

/-- The oscillation of the energy is bounded by its actual weighted logarithmic
integral over the bowl. -/
theorem energy_oscillation (hs : PositiveBowl ε f x v a)
    (hε : 0 ≤ ε)
    (hf : ContinuousOn f (Icc (-1 : ℝ) 1))
    (hfp : ContinuousOn fp (Icc (-1 : ℝ) 1))
    (hdf : ∀ t ∈ Icc (-1 : ℝ) 1, HasDerivAt f (fp t) t)
    {s t : ℝ} (hs' : s ∈ Icc (-1 : ℝ) 1) (ht : t ∈ Icc (-1 : ℝ) 1) :
    |profileEnergy ε f x v s - profileEnergy ε f x v t| ≤
      ε * (∫ r in (-1 : ℝ)..1, |fp r| * |Real.log (x r)|) := by
  let g : ℝ → ℝ := fun r => -ε * fp r * Real.log (x r)
  have hgc : ContinuousOn g (Icc (-1 : ℝ) 1) :=
    (continuousOn_const.mul hfp).mul hs.continuous_log
  have hgabs : IntervalIntegrable (fun r => |g r|) volume (-1 : ℝ) 1 :=
    hgc.abs.intervalIntegrable_of_Icc (by norm_num)
  have hfull : (∫ r in (-1 : ℝ)..1, |g r|) =
      ε * (∫ r in (-1 : ℝ)..1, |fp r| * |Real.log (x r)|) := by
    rw [← intervalIntegral.integral_const_mul]
    apply intervalIntegral.integral_congr
    intro r _
    simp only [g, abs_mul, abs_neg, abs_of_nonneg hε]
    ring
  have hordered : ∀ s ∈ Icc (-1 : ℝ) 1, ∀ t ∈ Icc (-1 : ℝ) 1, s ≤ t →
      |profileEnergy ε f x v s - profileEnergy ε f x v t| ≤
        ∫ r in (-1 : ℝ)..1, |g r| := by
    intro s hs' t ht hst
    have hsub : Icc s t ⊆ Icc (-1 : ℝ) 1 := Icc_subset_Icc hs'.1 ht.2
    have hFTC : (∫ r in s..t, g r) =
        profileEnergy ε f x v t - profileEnergy ε f x v s := by
      apply intervalIntegral.integral_eq_sub_of_hasDerivAt_of_le hst
        ((hs.continuous_energy hf).mono hsub)
      · intro r hr
        exact ((hs.energy_derivative hdf (hsub (mem_Icc_of_Ioo hr))).mono hsub).hasDerivAt
          (Icc_mem_nhds hr.1 hr.2)
      · exact (hgc.mono hsub).intervalIntegrable_of_Icc hst
    calc
      |profileEnergy ε f x v s - profileEnergy ε f x v t| = |∫ r in s..t, g r| := by
        rw [hFTC, abs_sub_comm]
      _ ≤ ∫ r in s..t, |g r| := intervalIntegral.abs_integral_le_integral_abs hst
      _ ≤ ∫ r in (-1 : ℝ)..1, |g r| :=
        intervalIntegral.integral_mono_interval hs'.1 hst ht.2
          (Filter.Eventually.of_forall (fun r => abs_nonneg (g r))) hgabs
  rcases le_total s t with hst | hts
  · simpa only [hfull] using hordered s hs' t ht hst
  · have h := hordered t ht s hs' hts
    rw [abs_sub_comm] at h
    simpa only [hfull] using h

/-- After height normalization, the logarithmic term has a nonnegative sign. -/
theorem energy_ge_kinetic (hs : PositiveBowl ε f x v a)
    (hε : 0 ≤ ε) (hf : ∀ t ∈ Icc (-1 : ℝ) 1, 0 ≤ f t)
    (hx1 : ∀ t ∈ Icc (-1 : ℝ) 1, x t ≤ 1)
    {t : ℝ} (ht : t ∈ Icc (-1 : ℝ) 1) :
    (v t)^2 / 2 ≤ profileEnergy ε f x v t := by
  have hlog : Real.log (x t) ≤ 0 := Real.log_nonpos (hs.positive t ht).le (hx1 t ht)
  have hmul := mul_nonpos_of_nonneg_of_nonpos (mul_nonneg hε (hf t ht)) hlog
  dsimp [profileEnergy]
  linarith

/-- Exact mean-energy formula for a height-normalized solution. -/
theorem energy_integral (hs : PositiveBowl ε f x v a)
    (hf : ContinuousOn f (Icc (-1 : ℝ) 1))
    (hx1 : ∀ t ∈ Icc (-1 : ℝ) 1, x t ≤ 1) :
    (∫ t in (-1 : ℝ)..1, profileEnergy ε f x v t) =
      (∫ t in (-1 : ℝ)..1, (v t)^2) / 2 +
      ε * (∫ t in (-1 : ℝ)..1, f t * |Real.log (x t)|) := by
  have heq : (∫ t in (-1 : ℝ)..1, profileEnergy ε f x v t) =
      ∫ t in (-1 : ℝ)..1, (v t)^2 / 2 + ε * (f t * |Real.log (x t)|) := by
    apply intervalIntegral.integral_congr
    intro t ht
    have ht' : t ∈ Icc (-1 : ℝ) 1 := by simpa using ht
    have hlog := Real.log_nonpos (hs.positive t ht').le (hx1 t ht')
    dsimp [profileEnergy]
    rw [abs_of_nonpos hlog]
    ring
  rw [heq, intervalIntegral.integral_add
    (((hs.continuous_v.pow 2).div_const 2).intervalIntegrable_of_Icc (by norm_num))
    ((continuousOn_const.mul (hf.mul hs.continuous_log.abs)).intervalIntegrable_of_Icc
      (by norm_num)), intervalIntegral.integral_div, intervalIntegral.integral_const_mul]

end PositiveBowl

#print axioms PositiveBowl.energy_oscillation
#print axioms PositiveBowl.energy_integral
end ReciprocalCounterexample
