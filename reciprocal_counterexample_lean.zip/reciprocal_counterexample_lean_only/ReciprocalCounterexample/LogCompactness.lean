import ReciprocalCounterexample.WeightedLog
import ReciprocalCounterexample.EnergyControl
import Mathlib.Analysis.SpecialFunctions.Log.NegMulLog
import Mathlib.Tactic.NormNum

/-!
# Uniform weighted logarithmic control of the singular trajectories

The logarithmic estimate needed for global and local compactness follows from
an acceleration-mass bound by the elementary inequality log(1+Y) <= Y.
This avoids normalizing a parameter-dependent measure. The local estimate is
O(r^5), which suffices for energy matching through a collision.
-/
noncomputable section
open Set MeasureTheory Filter
open scoped Interval Topology

namespace ReciprocalCounterexample

def reciprocalBowlAccel (ε : ℝ) (x : ℝ → ℝ) (t : ℝ) : ℝ :=
  ε * |t| ^ 6 / x t

def weightedAbsLog (x : ℝ → ℝ) (t : ℝ) : ℝ :=
  |t| ^ 5 * |Real.log (x t)|

/-- An elementary bound eliminating the logarithmic singularity at the
origin after multiplication by the fifth-order weight. -/
theorem fifth_power_neg_log_bound {u : ℝ} (hu : 0 ≤ u) :
    u ^ 5 * (-Real.log u) ≤ u ^ 4 := by
  rcases eq_or_lt_of_le hu with hzero | hpos
  · simp [← hzero]
  have hlog : -Real.log u ≤ u⁻¹ - 1 := by
    simpa only [Real.log_inv] using Real.log_le_sub_one_of_pos (inv_pos.mpr hpos)
  have hbase : u * (-Real.log u) ≤ 1 := by
    calc
      u * (-Real.log u) ≤ u * (u⁻¹ - 1) := mul_le_mul_of_nonneg_left hlog hu
      _ = 1 - u := by rw [mul_sub, mul_inv_cancel₀ (ne_of_gt hpos), mul_one]
      _ ≤ 1 := by linarith
  calc
    u ^ 5 * (-Real.log u) = u ^ 4 * (u * (-Real.log u)) := by ring
    _ ≤ u ^ 4 * 1 := mul_le_mul_of_nonneg_left hbase (pow_nonneg hu 4)
    _ = u ^ 4 := mul_one _

/-- The pointwise majorant is uniform even when the positive minimum of x
is arbitrarily small. Its only trajectory-dependent term is acceleration. -/
theorem weighted_log_pointwise_bound {ε r B t : ℝ} {x : ℝ → ℝ}
    (hε : 0 < ε) (hε1 : ε ≤ 1) (hr : 0 ≤ r) (hr1 : r ≤ 1)
    (hB : 0 ≤ B) (ht : t ∈ Icc (-r) r)
    (hpos : t ≠ 0 → 0 < x t) (hupper : x t ≤ B) :
    weightedAbsLog x t ≤ r ^ 5 * reciprocalBowlAccel ε x t +
      r ^ 5 * (Real.log (1 + B) + |Real.log ε|) + 6 * r ^ 4 := by
  have hC : 0 ≤ Real.log (1 + B) + |Real.log ε| :=
    add_nonneg (Real.log_nonneg (by linarith)) (abs_nonneg _)
  by_cases ht0 : t = 0
  · simp only [ht0, weightedAbsLog, reciprocalBowlAccel, abs_zero, zero_pow (by decide : 5 ≠ 0),
      zero_pow (by decide : 6 ≠ 0), zero_mul, mul_zero, zero_div, zero_add]
    positivity
  have hx := hpos ht0
  have hu : 0 < |t| := abs_pos.mpr ht0
  have hur : |t| ≤ r := abs_le.mpr ht
  have hu1 : |t| ≤ 1 := le_trans hur hr1
  have hpow1 : |t| ^ 6 ≤ 1 := pow_le_one₀ hu.le hu1
  have hα : 0 < ε * |t| ^ 6 := mul_pos hε (pow_pos hu 6)
  have hα1 : ε * |t| ^ 6 ≤ 1 :=
    le_trans (mul_le_mul_of_nonneg_left hpow1 hε.le) (by simpa using hε1)
  have hY : 0 ≤ reciprocalBowlAccel ε x t := div_nonneg hα.le hx.le
  have hmain := abs_log_control hx hupper hα hα1
  have hlin : Real.log (1 + reciprocalBowlAccel ε x t) ≤ reciprocalBowlAccel ε x t := by
    have := Real.log_le_sub_one_of_pos (show 0 < 1 + reciprocalBowlAccel ε x t by linarith)
    linarith
  have hlogα : Real.log (ε * |t| ^ 6) = Real.log ε + 6 * Real.log |t| := by
    rw [Real.log_mul (ne_of_gt hε) (pow_ne_zero _ (ne_of_gt hu)), Real.log_pow]
    norm_num
  change |Real.log (x t)| ≤ Real.log (1 + B) +
    Real.log (1 + reciprocalBowlAccel ε x t) - Real.log (ε * |t| ^ 6) at hmain
  rw [hlogα] at hmain
  have hmain' : |Real.log (x t)| ≤
      reciprocalBowlAccel ε x t + (Real.log (1 + B) + |Real.log ε|) +
        6 * (-Real.log |t|) := by
    have hεabs := neg_le_abs (Real.log ε)
    linarith
  have hpow5 : |t| ^ 5 ≤ r ^ 5 := pow_le_pow_left₀ hu.le hur 5
  have hpow4 : |t| ^ 4 ≤ r ^ 4 := pow_le_pow_left₀ hu.le hur 4
  have hwlog : |t| ^ 5 * (-Real.log |t|) ≤ r ^ 4 :=
    le_trans (fifth_power_neg_log_bound hu.le) hpow4
  have hWY := mul_le_mul_of_nonneg_right hpow5 hY
  have hWC := mul_le_mul_of_nonneg_right hpow5 hC
  have hm := mul_le_mul_of_nonneg_left hmain' (pow_nonneg hu.le 5)
  unfold weightedAbsLog
  nlinarith

end ReciprocalCounterexample
