import ReciprocalCounterexample.Energy
import ReciprocalCounterexample.FlatCoreObstruction
import Mathlib.Analysis.Convex.Deriv
import Mathlib.Analysis.Calculus.Deriv.MeanValue

/-!
# Positive bowls and uniform endpoint control

The solution structure below imposes the actual differential equation and
positivity on the bowl; no slope, compactness, or energy estimate is a field.
-/
noncomputable section
open Set MeasureTheory
open scoped Interval

namespace ReciprocalCounterexample

structure PositiveBowl (ε : ℝ) (f x v a : ℝ → ℝ) : Prop
    extends ClassicalArc (-1) 1 (fun t => ε * f t) x v a where
  positive : ∀ t ∈ Icc (-1 : ℝ) 1, 0 < x t

namespace PositiveBowl

variable {ε : ℝ} {f x v a : ℝ → ℝ}

theorem continuous_x (hs : PositiveBowl ε f x v a) :
    ContinuousOn x (Icc (-1 : ℝ) 1) :=
  fun t ht => (hs.dx t ht).continuousWithinAt

theorem acceleration_eq (hs : PositiveBowl ε f x v a)
    {t : ℝ} (ht : t ∈ Icc (-1 : ℝ) 1) :
    a t = ε * f t / x t := by
  apply (eq_div_iff (ne_of_gt (hs.positive t ht))).2
  simpa only [mul_comm] using hs.equation t ht

theorem acceleration_nonneg (hs : PositiveBowl ε f x v a)
    (hε : 0 ≤ ε) (hf : ∀ t ∈ Icc (-1 : ℝ) 1, 0 ≤ f t)
    {t : ℝ} (ht : t ∈ Icc (-1 : ℝ) 1) : 0 ≤ a t := by
  rw [hs.acceleration_eq ht]
  exact div_nonneg (mul_nonneg hε (hf t ht)) (hs.positive t ht).le

theorem velocity_monotone (hs : PositiveBowl ε f x v a)
    (hε : 0 ≤ ε) (hf : ∀ t ∈ Icc (-1 : ℝ) 1, 0 ≤ f t) :
    MonotoneOn v (Icc (-1 : ℝ) 1) := by
  apply monotoneOn_of_hasDerivWithinAt_nonneg (convex_Icc _ _) hs.continuous_v
  · intro t ht
    exact (hs.dv t (interior_subset ht)).mono interior_subset
  · intro t ht
    exact hs.acceleration_nonneg hε hf (interior_subset ht)

theorem position_convex (hs : PositiveBowl ε f x v a)
    (hε : 0 ≤ ε) (hf : ∀ t ∈ Icc (-1 : ℝ) 1, 0 ≤ f t) :
    ConvexOn ℝ (Icc (-1 : ℝ) 1) x := by
  apply convexOn_of_hasDerivWithinAt2_nonneg (convex_Icc _ _) hs.continuous_x
  · intro t ht
    exact (hs.dx t (interior_subset ht)).mono interior_subset
  · intro t ht
    exact (hs.dv t (interior_subset ht)).mono interior_subset
  · intro t ht
    exact hs.acceleration_nonneg hε hf (interior_subset ht)

/-- Every bowl height is bounded by the larger endpoint height. -/
theorem height_le_max_endpoints (hs : PositiveBowl ε f x v a)
    (hε : 0 ≤ ε) (hf : ∀ t ∈ Icc (-1 : ℝ) 1, 0 ≤ f t)
    {t : ℝ} (ht : t ∈ Icc (-1 : ℝ) 1) :
    x t ≤ max (x (-1)) (x 1) := by
  have hc := (hs.position_convex hε hf).2
    (show (-1 : ℝ) ∈ Icc (-1 : ℝ) 1 by norm_num)
    (show (1 : ℝ) ∈ Icc (-1 : ℝ) 1 by norm_num)
    (show 0 ≤ (1 - t) / 2 by linarith [ht.2])
    (show 0 ≤ (1 + t) / 2 by linarith [ht.1])
    (show (1 - t) / 2 + (1 + t) / 2 = 1 by ring)
  simp only [smul_eq_mul] at hc
  have harg : (1 - t) / 2 * (-1) + (1 + t) / 2 * 1 = t := by ring
  rw [harg] at hc
  have hleft := mul_le_mul_of_nonneg_left (le_max_left (x (-1)) (x 1))
    (show 0 ≤ (1 - t) / 2 by linarith [ht.2])
  have hright := mul_le_mul_of_nonneg_left (le_max_right (x (-1)) (x 1))
    (show 0 ≤ (1 + t) / 2 by linarith [ht.1])
  nlinarith

/-- A fixed positive collar gives a uniform upper bound for the normalized
forcing parameter, even when the two endpoint heights differ. -/
theorem normalized_parameter_le (hs : PositiveBowl ε f x v a)
    (hε : 0 ≤ ε)
    (hx1 : ∀ t ∈ Icc (-1 : ℝ) 1, x t ≤ 1)
    (hcollar : ∀ t ∈ Icc (-1 : ℝ) (-1 / 2), f t = 1) : ε ≤ 32 := by
  let q : ℝ → ℝ := fun t => x t - ε * t ^ 2 / 2
  let q' : ℝ → ℝ := fun t => v t - ε * t
  have hsub : Icc (-1 : ℝ) (-1 / 2) ⊆ Icc (-1 : ℝ) 1 :=
    Icc_subset_Icc le_rfl (by norm_num)
  have hqc : ContinuousOn q (Icc (-1 : ℝ) (-1 / 2)) :=
    (hs.continuous_x.mono hsub).sub
      ((continuousOn_const.mul (continuousOn_id.pow 2)).div_const 2)
  have hq : ConvexOn ℝ (Icc (-1 : ℝ) (-1 / 2)) q := by
    apply convexOn_of_hasDerivWithinAt2_nonneg (convex_Icc _ _) hqc
      (f' := q') (f'' := fun t => a t - ε)
    · intro t ht
      have htx := hs.dx t (hsub (interior_subset ht))
      have hp := (((hasDerivAt_id t).pow 2).const_mul ε).div_const 2
      convert (htx.mono (subset_trans interior_subset hsub)).sub hp.hasDerivWithinAt using 1 <;>
        dsimp [q, q'] <;> ring
    · intro t ht
      have htv := hs.dv t (hsub (interior_subset ht))
      have hp := (hasDerivAt_id t).const_mul ε
      convert (htv.mono (subset_trans interior_subset hsub)).sub hp.hasDerivWithinAt using 1 <;>
        dsimp [q'] <;> ring
    · intro t ht
      have htb := hsub (interior_subset ht)
      have heq := hs.equation t htb
      rw [hcollar t (interior_subset ht), mul_one] at heq
      have hp := hs.positive t htb
      have hacc : 0 ≤ a t := by
        rw [← heq] at hε
        exact nonneg_of_mul_nonneg_right hε hp
      nlinarith [hx1 t htb]
  have hmid := hq.2
    (show (-1 : ℝ) ∈ Icc (-1 : ℝ) (-1/2) by norm_num)
    (show (-1/2 : ℝ) ∈ Icc (-1 : ℝ) (-1/2) by norm_num)
    (show (0 : ℝ) ≤ 1/2 by norm_num)
    (show (0 : ℝ) ≤ 1/2 by norm_num)
    (show (1/2 : ℝ) + 1/2 = 1 by norm_num)
  norm_num [smul_eq_mul, q] at hmid
  have hm := hs.positive (-3/4) (by norm_num)
  have hl := hx1 (-1) (by norm_num)
  have hr := hx1 (-1/2) (by norm_num)
  linarith

/-- The displacement is the integral of the actual velocity. -/
theorem integral_velocity (hs : PositiveBowl ε f x v a) :
    (∫ t in (-1 : ℝ)..1, v t) = x 1 - x (-1) := by
  exact intervalIntegral.integral_eq_sub_of_hasDerivAt_of_le (by norm_num)
    hs.continuous_x
    (fun t ht => (hs.dx t (mem_Icc_of_Ioo ht)).hasDerivAt (Icc_mem_nhds ht.1 ht.2))
    (hs.continuous_v.intervalIntegrable_of_Icc (by norm_num))

/-- The total positive acceleration is the endpoint slope difference. -/
theorem integral_acceleration (hs : PositiveBowl ε f x v a) :
    (∫ t in (-1 : ℝ)..1, a t) = v 1 - v (-1) := by
  exact intervalIntegral.integral_eq_sub_of_hasDerivAt_of_le (by norm_num)
    hs.continuous_v
    (fun t ht => (hs.dv t (mem_Icc_of_Ioo ht)).hasDerivAt (Icc_mem_nhds ht.1 ht.2))
    (hs.continuous_a.intervalIntegrable_of_Icc (by norm_num))

/-- On a flat part of the forcing the actual velocity is constant. -/
theorem velocity_eq_of_forcing_zero (hs : PositiveBowl ε f x v a)
    {l r : ℝ} (hl : -1 ≤ l) (hr : r ≤ 1) (hlr : l ≤ r)
    (hz : ∀ t ∈ Icc l r, f t = 0) : v r = v l := by
  have hsub : Icc l r ⊆ Icc (-1 : ℝ) 1 := Icc_subset_Icc hl hr
  have hzero : ∀ t ∈ Icc l r, a t = 0 := by
    intro t ht
    rw [hs.acceleration_eq (hsub ht), hz t ht, mul_zero, zero_div]
  have hFTC := intervalIntegral.integral_eq_sub_of_hasDerivAt_of_le hlr
    (hs.continuous_v.mono hsub)
    (fun t ht => ((hs.dv t (hsub (mem_Icc_of_Ioo ht))).mono hsub).hasDerivAt
      (Icc_mem_nhds ht.1 ht.2))
    ((hs.continuous_a.mono hsub).intervalIntegrable_of_Icc hlr)
  have hint : (∫ t in l..r, a t) = 0 := by
    calc
      (∫ t in l..r, a t) = ∫ t in l..r, (0 : ℝ) := by
        apply intervalIntegral.integral_congr
        intro t ht
        exact hzero t (by simpa only [uIcc_of_le hlr] using ht)
      _ = 0 := by simp
  linarith

/-- The kinetic integral is controlled by endpoint slopes after height normalization. -/
theorem kinetic_integral_le (hs : PositiveBowl ε f x v a)
    (hε : 0 ≤ ε) (hf : ∀ t ∈ Icc (-1 : ℝ) 1, 0 ≤ f t)
    (hx1 : ∀ t ∈ Icc (-1 : ℝ) 1, x t ≤ 1) :
    (∫ t in (-1 : ℝ)..1, (v t)^2) ≤ |v (-1)| + |v 1| := by
  have hE := hs.toClassicalArc.energy_identity (by norm_num)
  have hint : 0 ≤ ∫ t in (-1 : ℝ)..1, ε * f t :=
    intervalIntegral.integral_nonneg (by norm_num) (fun t ht => mul_nonneg hε (hf t ht))
  have hr : x 1 * v 1 ≤ |v 1| := by
    calc
      x 1 * v 1 ≤ x 1 * |v 1| :=
        mul_le_mul_of_nonneg_left (le_abs_self _) (hs.positive 1 (by norm_num)).le
      _ ≤ 1 * |v 1| := mul_le_mul_of_nonneg_right (hx1 1 (by norm_num)) (abs_nonneg _)
      _ = |v 1| := one_mul _
  have hl : -(x (-1) * v (-1)) ≤ |v (-1)| := by
    calc
      -(x (-1) * v (-1)) = x (-1) * (-v (-1)) := by ring
      _ ≤ x (-1) * |v (-1)| := mul_le_mul_of_nonneg_left (neg_le_abs _)
        (hs.positive (-1) (by norm_num)).le
      _ ≤ 1 * |v (-1)| :=
        mul_le_mul_of_nonneg_right (hx1 (-1) (by norm_num)) (abs_nonneg _)
      _ = |v (-1)| := one_mul _
  linarith

/-- Scaling height and velocity divides the forcing parameter by the square
of the height scale, with all classical-solution properties retained. -/
theorem div_const (hs : PositiveBowl ε f x v a) {A : ℝ} (hA : 0 < A) :
    PositiveBowl (ε / A^2) f (fun t => x t / A) (fun t => v t / A)
      (fun t => a t / A) where
  continuous_v := hs.continuous_v.div_const A
  continuous_a := hs.continuous_a.div_const A
  dx := fun t ht => (hs.dx t ht).div_const A
  dv := fun t ht => (hs.dv t ht).div_const A
  equation := by
    intro t ht
    have heq := hs.equation t ht
    calc
      x t / A * (a t / A) = (x t * a t) / A^2 := by ring
      _ = (ε / A^2) * f t := by rw [heq]; ring
  positive := fun t ht => div_pos (hs.positive t ht) hA

end PositiveBowl
#print axioms PositiveBowl.normalized_parameter_le
end ReciprocalCounterexample
