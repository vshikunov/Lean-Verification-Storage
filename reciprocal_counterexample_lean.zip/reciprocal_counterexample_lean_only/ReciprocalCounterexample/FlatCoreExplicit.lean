import ReciprocalCounterexample.FlatCoreLogApplication

/-!
# A specified admissible parameter

The smallness condition can be met without a limiting argument.  The formula
below uses only the fixed derivative bound and entropy moment of the exact
smooth profile, and does not depend on a hypothetical trajectory.
-/
noncomputable section
open Set MeasureTheory
open scoped Interval
namespace ReciprocalCounterexample

theorem square_mul_log_abs_le {eta : ℝ} (heta : 0 < eta) (heta1 : eta ≤ 1) :
    |eta ^ 2 * Real.log (eta ^ 2)| ≤ 2 * eta := by
  have hu := unit_mul_abs_log_le_one heta.le heta1
  have hm := mul_le_mul_of_nonneg_left hu (show 0 ≤ 2 * eta by positivity)
  rw [Real.log_pow, abs_mul, abs_of_nonneg (sq_nonneg eta), abs_mul]
  norm_num
  nlinarith only [hm]

theorem flatCoreSquareLogModulus_le_linear {eta D J : ℝ}
    (heta : 0 < eta) (heta1 : eta ≤ 1) (hD : 0 ≤ D) (hJ : 0 ≤ J) :
    flatCoreSquareLogModulus 6 D 36 J eta ≤ (52 * D + J) * eta := by
  have he2 : eta ^ 2 ≤ eta := by nlinarith
  have hl : Real.log 7 ≤ 6 := by
    have h := Real.log_le_sub_one_of_pos (by norm_num : (0:ℝ) < 7)
    norm_num at h
    exact h
  have hlmul := mul_le_mul_of_nonneg_left hl (show 0 ≤ 2 * D by positivity)
  have hcoef : 2 * D * Real.log 7 + J ≤ 12 * D + J := by nlinarith
  have hfirst := mul_le_mul_of_nonneg_left hcoef (sq_nonneg eta)
  have hsecond := mul_le_mul_of_nonneg_right he2 (show 0 ≤ 12 * D + J by positivity)
  have hlast := mul_le_mul_of_nonneg_left (square_mul_log_abs_le heta heta1)
    (show 0 ≤ 2 * D by positivity)
  unfold flatCoreSquareLogModulus
  rw [show (1 : ℝ) + 6 = 7 by norm_num]
  nlinarith only [hfirst, hsecond, hlast]

theorem flatCoreErrorModulus_le_linear {eta : ℝ}
    (heta : 0 < eta) (heta1 : eta ≤ 1) :
    flatCoreErrorModulus eta ≤
      231 * (1 + flatCoreDerivativeConstant + flatCoreEntropyMoment) * eta := by
  have hD := flatCoreDerivativeConstant_pos.le
  have hJ := flatCoreEntropyMoment_nonneg
  have hd := flatCoreSquareLogModulus_le_linear heta heta1 hD hJ
  have hf := flatCoreSquareLogModulus_le_linear heta heta1
    (by norm_num : (0:ℝ) ≤ 1) (by norm_num : (0:ℝ) ≤ 2)
  have he2 : eta ^ 2 ≤ eta := by nlinarith
  have hDe := mul_nonneg hD heta.le
  have hJe := mul_nonneg hJ heta.le
  unfold flatCoreErrorModulus
  nlinarith only [hd, hf, he2, hDe, hJe]

def explicitFlatCoreParameter : ℝ :=
  1 / (1000 * (1 + flatCoreDerivativeConstant + flatCoreEntropyMoment))

theorem explicitFlatCoreParameter_pos : 0 < explicitFlatCoreParameter := by
  unfold explicitFlatCoreParameter
  have hD := flatCoreDerivativeConstant_pos
  have hJ := flatCoreEntropyMoment_nonneg
  positivity

theorem explicitFlatCoreParameter_le_quarter : explicitFlatCoreParameter ≤ 1 / 4 := by
  have hD := flatCoreDerivativeConstant_pos
  have hJ := flatCoreEntropyMoment_nonneg
  have hd : 0 < 1000 * (1 + flatCoreDerivativeConstant + flatCoreEntropyMoment) := by positivity
  unfold explicitFlatCoreParameter
  apply (div_le_iff₀ hd).2
  nlinarith

theorem explicitFlatCoreParameter_error : flatCoreErrorModulus explicitFlatCoreParameter < 1 / 2 := by
  have hD := flatCoreDerivativeConstant_pos
  have hJ := flatCoreEntropyMoment_nonneg
  have hd : 1 + flatCoreDerivativeConstant + flatCoreEntropyMoment ≠ 0 := by positivity
  have h := flatCoreErrorModulus_le_linear explicitFlatCoreParameter_pos
    (explicitFlatCoreParameter_le_quarter.trans (by norm_num))
  have heq : 231 * (1 + flatCoreDerivativeConstant + flatCoreEntropyMoment) *
      explicitFlatCoreParameter = 231 / 1000 := by
    unfold explicitFlatCoreParameter
    field_simp
    ring
  rw [heq] at h
  exact h.trans_lt (by norm_num)

#print axioms explicitFlatCoreParameter_error
end ReciprocalCounterexample
