import ReciprocalCounterexample.Forcing
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Analysis.Calculus.LocalExtr.Basic

/-!
# A smooth forcing profile with an exact flat central interval

The profile is built from the same exponential smooth step as the manuscript,
but vanishes on a whole interval. This permits a direct compactness obstruction
without constructing a singular collision passage map.
-/
noncomputable section
open Set MeasureTheory Filter
open scoped Interval Topology ContDiff

namespace ReciprocalCounterexample

def flatCoreProfile (t : ℝ) : ℝ := smoothStep (4 * t - 1) + smoothStep (-4 * t - 1)

theorem flatCoreProfile_contDiff : ContDiff ℝ ∞ flatCoreProfile := by
  exact (smoothStep_contDiff.comp ((contDiff_const.mul contDiff_id).sub contDiff_const)).add
    (smoothStep_contDiff.comp ((contDiff_const.mul contDiff_id).sub contDiff_const))

theorem flatCoreProfile_even (t : ℝ) : flatCoreProfile (-t) = flatCoreProfile t := by
  unfold flatCoreProfile
  have h1 : 4 * -t - 1 = -4 * t - 1 := by ring
  have h2 : -4 * -t - 1 = 4 * t - 1 := by ring
  rw [h1, h2, add_comm]

theorem flatCoreProfile_nonneg (t : ℝ) : 0 ≤ flatCoreProfile t :=
  add_nonneg (smoothStep_nonneg _) (smoothStep_nonneg _)

theorem flatCoreProfile_le_one (t : ℝ) : flatCoreProfile t ≤ 1 := by
  unfold flatCoreProfile
  rcases le_total 0 t with ht | ht
  · rw [smoothStep_zero_of_nonpos (by linarith : -4 * t - 1 ≤ 0), add_zero]
    exact smoothStep_le_one _
  · rw [smoothStep_zero_of_nonpos (by linarith : 4 * t - 1 ≤ 0), zero_add]
    exact smoothStep_le_one _

theorem flatCoreProfile_zero_of_abs_le_quarter {t : ℝ} (ht : |t| ≤ 1 / 4) :
    flatCoreProfile t = 0 := by
  have habs := abs_le.mp ht
  unfold flatCoreProfile
  rw [smoothStep_zero_of_nonpos (by linarith : 4 * t - 1 ≤ 0),
    smoothStep_zero_of_nonpos (by linarith : -4 * t - 1 ≤ 0), add_zero]

theorem flatCoreProfile_one_of_half_le_abs {t : ℝ} (ht : 1 / 2 ≤ |t|) :
    flatCoreProfile t = 1 := by
  unfold flatCoreProfile
  rcases le_total 0 t with h | h
  · rw [abs_of_nonneg h] at ht
    rw [smoothStep_one_of_one_le (by linarith : 1 ≤ 4 * t - 1),
      smoothStep_zero_of_nonpos (by linarith : -4 * t - 1 ≤ 0), add_zero]
  · rw [abs_of_nonpos h] at ht
    rw [smoothStep_zero_of_nonpos (by linarith : 4 * t - 1 ≤ 0),
      smoothStep_one_of_one_le (by linarith : 1 ≤ -4 * t - 1), zero_add]

private def cutoffDenom (s : ℝ) : ℝ := expNegInvGlue s + expNegInvGlue (1 - s)

private theorem cutoffDenom_pos (s : ℝ) : 0 < cutoffDenom s :=
  Real.smoothTransition.pos_denom s

private theorem cutoffDenom_contDiff : ContDiff ℝ ∞ cutoffDenom := by
  exact expNegInvGlue.contDiff.add
    (expNegInvGlue.contDiff.comp (contDiff_const.sub contDiff_id))

/-- Smoothness of the entropy of the exact cutoff. The apparent log singularity
cancels against the exponentially flat numerator. -/
theorem smoothStep_entropy_contDiff :
    ContDiff ℝ ∞ (fun s : ℝ => smoothStep s * Real.log (smoothStep s)) := by
  have hInvGlue : ContDiff ℝ ∞ (fun s : ℝ => s⁻¹ * expNegInvGlue s) := by
    simpa using (expNegInvGlue.contDiff_polynomial_eval_inv_mul (n := ⊤) Polynomial.X)
  have heq : (fun s : ℝ => smoothStep s * Real.log (smoothStep s)) =
      (fun s => -(s⁻¹ * expNegInvGlue s) / cutoffDenom s -
        smoothStep s * Real.log (cutoffDenom s)) := by
    funext s
    by_cases hs : expNegInvGlue s = 0
    · simp [smoothStep, Real.smoothTransition, hs, cutoffDenom]
    have hspos : 0 < s := lt_of_not_ge (fun hn => hs (expNegInvGlue.zero_of_nonpos hn))
    have hlog : Real.log (expNegInvGlue s) = -s⁻¹ := by
      simp [expNegInvGlue, not_le.mpr hspos]
    change (expNegInvGlue s / cutoffDenom s) *
      Real.log (expNegInvGlue s / cutoffDenom s) = _
    rw [Real.log_div hs (ne_of_gt (cutoffDenom_pos s)), hlog]
    change (expNegInvGlue s / cutoffDenom s) * (-s⁻¹ - Real.log (cutoffDenom s)) =
      -(s⁻¹ * expNegInvGlue s) / cutoffDenom s -
        (expNegInvGlue s / cutoffDenom s) * Real.log (cutoffDenom s)
    ring
  rw [heq]
  exact (hInvGlue.neg.div cutoffDenom_contDiff (fun s => ne_of_gt (cutoffDenom_pos s))).sub
    (smoothStep_contDiff.mul
      (cutoffDenom_contDiff.log (fun s => ne_of_gt (cutoffDenom_pos s))))

/-- At most one cutoff is active, so entropy commutes with the two-term sum. -/
theorem flatCoreProfile_entropy_contDiff :
    ContDiff ℝ ∞ (fun t : ℝ => flatCoreProfile t * Real.log (flatCoreProfile t)) := by
  have heq : (fun t : ℝ => flatCoreProfile t * Real.log (flatCoreProfile t)) =
      (fun t => smoothStep (4 * t - 1) * Real.log (smoothStep (4 * t - 1)) +
        smoothStep (-4 * t - 1) * Real.log (smoothStep (-4 * t - 1))) := by
    funext t
    unfold flatCoreProfile
    rcases le_total 0 t with ht | ht
    · rw [smoothStep_zero_of_nonpos (by linarith : -4 * t - 1 ≤ 0)]
      simp
    · rw [smoothStep_zero_of_nonpos (by linarith : 4 * t - 1 ≤ 0)]
      simp
  rw [heq]
  exact (smoothStep_entropy_contDiff.comp ((contDiff_const.mul contDiff_id).sub contDiff_const)).add
    (smoothStep_entropy_contDiff.comp ((contDiff_const.mul contDiff_id).sub contDiff_const))

/-- The logarithmic derivative product extends continuously across every
zero of the flat profile. -/
theorem flatCoreProfile_deriv_log_identity (t : ℝ) :
    deriv flatCoreProfile t * Real.log (flatCoreProfile t) =
      deriv (fun s => flatCoreProfile s * Real.log (flatCoreProfile s)) t -
        deriv flatCoreProfile t := by
  by_cases hz : flatCoreProfile t = 0
  · have hmin : IsLocalMin flatCoreProfile t := by
      change ∀ᶠ s in 𝓝 t, flatCoreProfile t ≤ flatCoreProfile s
      exact Filter.Eventually.of_forall (fun s => by rw [hz]; exact flatCoreProfile_nonneg s)
    have hmax : IsLocalMax (fun s => flatCoreProfile s * Real.log (flatCoreProfile s)) t := by
      change ∀ᶠ s in 𝓝 t,
        flatCoreProfile s * Real.log (flatCoreProfile s) ≤
          flatCoreProfile t * Real.log (flatCoreProfile t)
      apply Filter.Eventually.of_forall
      intro s
      rw [hz, zero_mul]
      exact mul_nonpos_of_nonneg_of_nonpos (flatCoreProfile_nonneg s)
        (Real.log_nonpos (flatCoreProfile_nonneg s) (flatCoreProfile_le_one s))
    rw [hmin.deriv_eq_zero, hmax.deriv_eq_zero]
    simp
  · have hdf := (flatCoreProfile_contDiff.differentiable (by simp) t).hasDerivAt
    have he := (hdf.mul (hdf.log hz)).deriv
    rw [mul_div_cancel₀ _ hz] at he
    linarith

theorem flatCoreProfile_deriv_log_continuous :
    Continuous (fun t => deriv flatCoreProfile t * Real.log (flatCoreProfile t)) := by
  have heq : (fun t => deriv flatCoreProfile t * Real.log (flatCoreProfile t)) =
      (fun t => deriv (fun s => flatCoreProfile s * Real.log (flatCoreProfile s)) t -
        deriv flatCoreProfile t) := funext flatCoreProfile_deriv_log_identity
  rw [heq]
  exact (flatCoreProfile_entropy_contDiff.continuous_deriv (by simp)).sub
    (flatCoreProfile_contDiff.continuous_deriv (by simp))

theorem flatCoreProfile_logMoment_continuous :
    Continuous (fun t => |deriv flatCoreProfile t| * |Real.log (flatCoreProfile t)|) := by
  simpa only [abs_mul] using flatCoreProfile_deriv_log_continuous.abs

theorem flatCoreProfile_logMoment_intervalIntegrable (a b : ℝ) :
    IntervalIntegrable (fun t => |deriv flatCoreProfile t| * |Real.log (flatCoreProfile t)|)
      volume a b := flatCoreProfile_logMoment_continuous.intervalIntegrable a b

theorem flatCoreProfile_deriv_eq_zero_of_profile_zero {t : ℝ} (ht : flatCoreProfile t = 0) :
    deriv flatCoreProfile t = 0 := by
  have hmin : IsLocalMin flatCoreProfile t := by
    change ∀ᶠ s in 𝓝 t, flatCoreProfile t ≤ flatCoreProfile s
    exact Filter.Eventually.of_forall (fun s => by rw [ht]; exact flatCoreProfile_nonneg s)
  exact hmin.deriv_eq_zero

/-- Uniform scalar entropy bound on the unit interval. -/
theorem unit_mul_abs_log_le_one {z : ℝ} (hz : 0 ≤ z) (hz1 : z ≤ 1) :
    z * |Real.log z| ≤ 1 := by
  rcases eq_or_lt_of_le hz with hzero | hpos
  · simp [← hzero]
  rw [abs_of_nonpos (Real.log_nonpos hz hz1)]
  have hh : -Real.log z ≤ z⁻¹ - 1 := by
    simpa only [Real.log_inv] using Real.log_le_sub_one_of_pos (inv_pos.mpr hpos)
  calc
    z * (-Real.log z) ≤ z * (z⁻¹ - 1) := mul_le_mul_of_nonneg_left hh hz
    _ = 1 - z := by rw [mul_sub, mul_inv_cancel₀ (ne_of_gt hpos), mul_one]
    _ ≤ 1 := by linarith

theorem flatCoreProfile_entropy_abs_continuous :
    Continuous (fun t => flatCoreProfile t * |Real.log (flatCoreProfile t)|) := by
  convert flatCoreProfile_entropy_contDiff.continuous.neg using 1
  ext t
  rw [abs_of_nonpos (Real.log_nonpos (flatCoreProfile_nonneg t) (flatCoreProfile_le_one t))]
  ring

theorem flatCoreProfile_entropy_integral_le_two :
    (∫ t in (-1 : ℝ)..1, flatCoreProfile t * |Real.log (flatCoreProfile t)|) ≤ 2 := by
  have h := intervalIntegral.integral_mono_on (by norm_num : (-1 : ℝ) ≤ 1)
    (flatCoreProfile_entropy_abs_continuous.intervalIntegrable (-1) 1)
    (intervalIntegrable_const (μ := volume) (c := (1 : ℝ)))
    (fun t _ => unit_mul_abs_log_le_one (flatCoreProfile_nonneg t) (flatCoreProfile_le_one t))
  norm_num at h ⊢
  exact h

#print axioms flatCoreProfile_entropy_contDiff
#print axioms flatCoreProfile_deriv_log_continuous
#print axioms flatCoreProfile_logMoment_intervalIntegrable

end ReciprocalCounterexample
