import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.MeasureTheory.Function.SpecialFunctions.Basic
import Mathlib.MeasureTheory.Integral.Bochner.Basic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Positivity

/-!
# The finite-measure logarithmic estimate

The central Jensen estimate used in the manuscript is proved here directly
from the tangent inequality for log. This is valid for any finite nonzero
measure, including the weighted measures occurring in Sections 3 and 6.
Application to a family of colliding trajectories still requires the
trajectory-specific integrability and acceleration bounds.
-/

noncomputable section
open Set MeasureTheory Filter

namespace ReciprocalCounterexample

theorem log_one_add_tangent {y r : ℝ} (hy : 0 ≤ y) (hr : 0 ≤ r) :
    Real.log (1 + y) ≤ Real.log (1 + r) + (y - r) / (1 + r) := by
  have hyr : 0 < (1 + y) / (1 + r) := div_pos (by linarith) (by linarith)
  have h := Real.log_le_sub_one_of_pos hyr
  rw [Real.log_div (by linarith : 1 + y ≠ 0) (by linarith : 1 + r ≠ 0)] at h
  have heq : (1 + y) / (1 + r) - 1 = (y - r) / (1 + r) := by
    field_simp
  rw [heq] at h
  linarith

/-- The reciprocal logarithm decomposition used before weighted integration. -/
theorem log_reciprocal_control {x α : ℝ}
    (hx : 0 < x) (hα : 0 < α) (hα1 : α ≤ 1) :
    Real.log (1 + 1 / x) ≤ Real.log (1 + α / x) - Real.log α := by
  rw [← Real.log_div (ne_of_gt (show 0 < 1 + α / x by positivity)) (ne_of_gt hα)]
  apply Real.log_le_log (by positivity)
  apply (le_div_iff₀ hα).2
  calc
    (1 + 1 / x) * α = α + α / x := by ring
    _ ≤ 1 + α / x := add_le_add_right hα1 _

/-- Pointwise domination of the absolute logarithm, retaining the upper
height bound and the exact small forcing coefficient. -/
theorem abs_log_control {x α B : ℝ}
    (hx : 0 < x) (hB : x ≤ B) (hα : 0 < α) (hα1 : α ≤ 1) :
    |Real.log x| ≤ Real.log (1 + B) + Real.log (1 + α / x) - Real.log α := by
  have hBpos : 0 < B := lt_of_lt_of_le hx hB
  have hBnonneg : 0 ≤ Real.log (1 + B) := Real.log_nonneg (by linarith)
  have hupper : Real.log x ≤ Real.log (1 + B) :=
    Real.log_le_log hx (by linarith)
  have hlower : -Real.log x ≤ Real.log (1 + 1 / x) := by
    rw [← Real.log_inv]
    apply Real.log_le_log (inv_pos.mpr hx)
    simp only [one_div]
    linarith
  have hrecip := log_reciprocal_control hx hα hα1
  have hylog : 0 ≤ Real.log (1 + α / x) := Real.log_nonneg (le_add_of_nonneg_right (div_nonneg hα.le hx.le))
  have hαlog : Real.log α ≤ 0 := Real.log_nonpos hα.le hα1
  apply abs_le.mpr
  constructor <;> linarith

variable {α : Type*} [MeasurableSpace α] {μ : Measure α}

theorem integrable_log_one_add {Y : α → ℝ}
    (hY : Integrable Y μ) (hpos : ∀ᵐ s ∂μ, 0 ≤ Y s) :
    Integrable (fun s => Real.log (1 + Y s)) μ := by
  apply hY.mono'
  · exact (aemeasurable_const.add hY.aemeasurable).log.aestronglyMeasurable
  · filter_upwards [hpos] with s hs
    rw [Real.norm_eq_abs, abs_of_nonneg (Real.log_nonneg (by linarith))]
    have h := Real.log_le_sub_one_of_pos (by linarith : 0 < 1 + Y s)
    linarith

/-- Finite-measure Jensen bound with no unproved convexity premise. -/
theorem integral_log_one_add_le [IsFiniteMeasure μ] {Y : α → ℝ}
    (hμ : 0 < μ.real univ) (hY : Integrable Y μ)
    (hpos : ∀ᵐ s ∂μ, 0 ≤ Y s) :
    (∫ s, Real.log (1 + Y s) ∂μ) ≤
      μ.real univ * Real.log (1 + (∫ s, Y s ∂μ) / μ.real univ) := by
  let r : ℝ := (∫ s, Y s ∂μ) / μ.real univ
  have hr : 0 ≤ r := div_nonneg (integral_nonneg_of_ae hpos) hμ.le
  have hlog := integrable_log_one_add hY hpos
  have hdiff : Integrable (fun s => Y s - r) μ := hY.sub (integrable_const r)
  have hquot : Integrable (fun s => (Y s - r) / (1 + r)) μ := hdiff.div_const _
  have hc : Integrable (fun _ : α => Real.log (1 + r)) μ := integrable_const _
  have hlin : Integrable (fun s => Real.log (1 + r) + (Y s - r) / (1 + r)) μ :=
    hc.add hquot
  have hmono : (∫ s, Real.log (1 + Y s) ∂μ) ≤
      ∫ s, (Real.log (1 + r) + (Y s - r) / (1 + r)) ∂μ := by
    apply integral_mono_ae hlog hlin
    filter_upwards [hpos] with s hs
    exact log_one_add_tangent hs hr
  have hvalue : (∫ s, (Real.log (1 + r) + (Y s - r) / (1 + r)) ∂μ) =
      μ.real univ * Real.log (1 + r) := by
    rw [integral_add hc hquot, integral_div, integral_sub hY (integrable_const r),
      integral_const, integral_const]
    simp only [smul_eq_mul]
    have hcancel : (∫ s, Y s ∂μ) - μ.real univ * r = 0 := by
      dsimp [r]
      rw [mul_div_cancel₀ _ (ne_of_gt hμ), sub_self]
    rw [hcancel, zero_div, add_zero]
  rw [hvalue] at hmono
  exact hmono

#print axioms log_reciprocal_control
#print axioms abs_log_control
#print axioms log_one_add_tangent
#print axioms integrable_log_one_add
#print axioms integral_log_one_add_le
end ReciprocalCounterexample
