import ReciprocalCounterexample.FlatCoreSmallLog
import ReciprocalCounterexample.FlatCoreDefect

/-!
# Logarithmic estimates applied to actual classical bowls

All solution information in this module comes from PositiveBowl. Its structure
stores only the classical differential equation, its derivatives, continuity,
and positivity. The logarithmic moment and derivative constants below belong
to the explicit forcing profile and are independent of the trajectory.
-/

noncomputable section
open Set MeasureTheory Filter
open scoped Interval Topology

namespace ReciprocalCounterexample

def flatCoreDerivativeConstant : ℝ :=
  Classical.choose flatCoreProfile_exists_deriv_bound

theorem flatCoreDerivativeConstant_pos : 0 < flatCoreDerivativeConstant :=
  (Classical.choose_spec flatCoreProfile_exists_deriv_bound).1

theorem flatCoreDerivativeConstant_bound :
    ∀ t ∈ Icc (-1 : ℝ) 1, |deriv flatCoreProfile t| ≤ flatCoreDerivativeConstant :=
  (Classical.choose_spec flatCoreProfile_exists_deriv_bound).2

def flatCoreEntropyMoment : ℝ :=
  ∫ t in (-1 : ℝ)..1, |deriv flatCoreProfile t| * |Real.log (flatCoreProfile t)|

theorem flatCoreEntropyMoment_nonneg : 0 ≤ flatCoreEntropyMoment :=
  intervalIntegral.integral_nonneg (by norm_num)
    (fun t _ => mul_nonneg (abs_nonneg _) (abs_nonneg _))

namespace PositiveBowl

variable {eps : ℝ} {x v a : ℝ → ℝ}

theorem integral_flatAcceleration (hs : PositiveBowl eps flatCoreProfile x v a) :
    (∫ t in (-1 : ℝ)..1, flatAcceleration eps x t) = ∫ t in (-1 : ℝ)..1, a t := by
  apply intervalIntegral.integral_congr
  intro t ht
  have ht' : t ∈ Icc (-1 : ℝ) 1 := by simpa using ht
  exact (hs.acceleration_eq ht').symm

theorem flatCore_deriv_log_control (hs : PositiveBowl eps flatCoreProfile x v a)
    {R : ℝ} (heps : 0 < eps) (heps1 : eps ≤ 1)
    (hheight : ∀ t ∈ Icc (-1 : ℝ) 1, x t ≤ 6)
    (hacc : eps * (∫ t in (-1 : ℝ)..1, a t) ≤ R) :
    eps * (∫ t in (-1 : ℝ)..1, |deriv flatCoreProfile t| * |Real.log (x t)|) ≤
      flatCoreDerivativeConstant * R + eps *
        (2 * flatCoreDerivativeConstant * Real.log 7 + flatCoreEntropyMoment) +
          2 * flatCoreDerivativeConstant * |eps * Real.log eps| := by
  have hR : eps * (∫ t in (-1 : ℝ)..1, flatAcceleration eps x t) ≤ R := by
    rw [hs.integral_flatAcceleration]
    exact hacc
  have h := flatCore_small_deriv_log_bound_of_scaled_acceleration heps heps1
    (by norm_num : (0 : ℝ) ≤ 6) flatCoreDerivativeConstant_pos.le
    hs.continuous_x hs.positive hheight flatCoreDerivativeConstant_bound hR
  norm_num [flatCoreEntropyMoment] at h ⊢
  exact h

theorem flatCore_profile_log_control (hs : PositiveBowl eps flatCoreProfile x v a)
    {R : ℝ} (heps : 0 < eps) (heps1 : eps ≤ 1)
    (hheight : ∀ t ∈ Icc (-1 : ℝ) 1, x t ≤ 6)
    (hacc : eps * (∫ t in (-1 : ℝ)..1, a t) ≤ R) :
    eps * (∫ t in (-1 : ℝ)..1, flatCoreProfile t * |Real.log (x t)|) ≤
      R + eps * (2 * Real.log 7 + 2) + 2 * |eps * Real.log eps| := by
  have hR : eps * (∫ t in (-1 : ℝ)..1, flatAcceleration eps x t) ≤ R := by
    rw [hs.integral_flatAcceleration]
    exact hacc
  have h := flatCore_small_profile_log_bound_of_scaled_acceleration heps heps1
    (by norm_num : (0 : ℝ) ≤ 6) hs.continuous_x hs.positive hheight hR
  norm_num at h ⊢
  exact h

theorem flatCore_square_log_control {eta C : ℝ}
    (hs : PositiveBowl (eta ^ 2) flatCoreProfile x v a)
    (heta : 0 < eta) (heta1 : eta ≤ 1)
    (hheight : ∀ t ∈ Icc (-1 : ℝ) 1, x t ≤ 6)
    (hacc : eta ^ 2 * (∫ t in (-1 : ℝ)..1, a t) ≤ C * eta) :
    (eta ^ 2 * (∫ t in (-1 : ℝ)..1,
      |deriv flatCoreProfile t| * |Real.log (x t)|) ≤
        flatCoreSquareLogModulus 6 flatCoreDerivativeConstant C flatCoreEntropyMoment eta) ∧
    (eta ^ 2 * (∫ t in (-1 : ℝ)..1, flatCoreProfile t * |Real.log (x t)|) ≤
      flatCoreSquareLogModulus 6 1 C 2 eta) := by
  have heps : 0 < eta ^ 2 := sq_pos_of_pos heta
  have heps1 : eta ^ 2 ≤ 1 := pow_le_one₀ heta.le heta1
  constructor
  · have h := hs.flatCore_deriv_log_control heps heps1 hheight hacc
    norm_num [flatCoreSquareLogModulus, mul_assoc] at h ⊢
    exact h
  · have h := hs.flatCore_profile_log_control heps heps1 hheight hacc
    norm_num [flatCoreSquareLogModulus] at h ⊢
    exact h

end PositiveBowl

/-- A single continuous error majorant for the explicit eta family. -/
def flatCoreErrorModulus (eta : ℝ) : ℝ :=
  15 * eta ^ 2 +
    4 * flatCoreSquareLogModulus 6 flatCoreDerivativeConstant 36 flatCoreEntropyMoment eta +
      4 * flatCoreSquareLogModulus 6 1 36 2 eta

theorem flatCoreErrorModulus_continuous : Continuous flatCoreErrorModulus :=
  ((continuous_const.mul (continuous_id.pow 2)).add
    (continuous_const.mul (flatCoreSquareLogModulus_continuous _ _ _ _))).add
      (continuous_const.mul (flatCoreSquareLogModulus_continuous _ _ _ _))

@[simp] theorem flatCoreErrorModulus_zero : flatCoreErrorModulus 0 = 0 := by
  simp [flatCoreErrorModulus]

theorem flatCoreErrorModulus_tendsto_zero :
    Tendsto flatCoreErrorModulus (𝓝 0) (𝓝 0) := by
  simpa using flatCoreErrorModulus_continuous.continuousAt.tendsto (x := 0)

theorem exists_small_flatCore_parameter :
    ∃ eta : ℝ, 0 < eta ∧ eta ≤ 1 / 4 ∧ flatCoreErrorModulus eta < 1 / 2 := by
  have he : ∀ᶠ eta in 𝓝 (0 : ℝ), flatCoreErrorModulus eta < 1 / 2 :=
    flatCoreErrorModulus_tendsto_zero.eventually
      (eventually_lt_nhds (by norm_num : (0 : ℝ) < 1 / 2))
  obtain ⟨d, hd, hdmem⟩ := Metric.mem_nhds_iff.mp he
  let eta := min (d / 2) (1 / 8)
  have heta : 0 < eta := lt_min (half_pos hd) (by norm_num)
  have hetaD : eta < d := lt_of_le_of_lt (min_le_left _ _) (by linarith)
  refine ⟨eta, heta, (min_le_right _ _).trans (by norm_num), ?_⟩
  apply hdmem
  simpa only [Metric.mem_ball, Real.dist_eq, sub_zero, abs_of_pos heta] using hetaD

/-- The quantitative analytic estimates contradict the exact flat core. -/
theorem PositiveBowl.flatCore_error_modulus_lower {eta : ℝ} {x v a : ℝ → ℝ}
    (hs : PositiveBowl (eta ^ 2) flatCoreProfile x v a)
    (heta : 0 < eta) (heta1 : eta ≤ 1)
    (hheight : ∀ t ∈ Icc (-1 : ℝ) 1, x t ≤ 6)
    (hacc : eta ^ 2 * (∫ t in (-1 : ℝ)..1, a t) ≤ 36 * eta)
    (hdisp : |x 1 - x (-1)| ≤ eta ^ 2 / 16)
    (hkin : |(∫ t in (-1 : ℝ)..1, (v t) ^ 2) - 2| ≤ 14 * eta ^ 2) :
    1 / 2 ≤ flatCoreErrorModulus eta := by
  have hnecessary := hs.flat_core_necessary_inequality (sq_nonneg eta)
  obtain ⟨hlogD, hlogF⟩ := hs.flatCore_square_log_control heta heta1 hheight hacc
  unfold flatCoreErrorModulus
  nlinarith [sq_nonneg eta]

#print axioms PositiveBowl.flatCore_deriv_log_control
#print axioms PositiveBowl.flatCore_profile_log_control
#print axioms PositiveBowl.flatCore_error_modulus_lower
#print axioms exists_small_flatCore_parameter

end ReciprocalCounterexample
