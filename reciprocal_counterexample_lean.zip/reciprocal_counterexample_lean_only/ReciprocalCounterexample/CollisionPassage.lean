import ReciprocalCounterexample.Energy
import Mathlib.Topology.MetricSpace.Contracting
import Mathlib.Topology.ContinuousMap.Compact
import Mathlib.Topology.Order.ProjIcc
import Mathlib.MeasureTheory.Integral.Bochner.Set
import Mathlib.Tactic.FunProp

/-!
# Construction of the finite-speed collision branch

This module constructs the desingularized collision solution U=X/t by an
actual contraction on C([0,1]). The denominator is initially clamped below by
b; the fixed point automatically lies above b, so the clamp disappears.
This does not assert the full positive-minimum C1 passage theorem.
-/
noncomputable section
open Set MeasureTheory
open scoped Topology NNReal
namespace ReciprocalCounterexample
namespace Collision

abbrev UnitI := Icc (0 : ℝ) 1
abbrev Path := C(UnitI, ℝ)

def clip (s : ℝ) : UnitI := projIcc 0 1 zero_le_one s

def extend (u : Path) (s : ℝ) : ℝ := u (clip s)

lemma continuous_extend (u : Path) : Continuous (extend u) :=
  u.continuous.comp (continuous_projIcc (h := zero_le_one))

lemma extend_eq (u : Path) (s : UnitI) : extend u s = u s := by
  simp [extend, clip]

lemma reciprocal_clamp_lipschitz {b a c : ℝ} (hb : 0 < b) :
    |1 / max b a - 1 / max b c| ≤ |a - c| / b ^ 2 := by
  have ha : 0 < max b a := lt_of_lt_of_le hb (le_max_left _ _)
  have hc : 0 < max b c := lt_of_lt_of_le hb (le_max_left _ _)
  have hn : |max b c - max b a| ≤ |a - c| := by
    simpa [max_comm, abs_sub_comm] using abs_max_sub_max_le_abs c a b
  have hd : b ^ 2 ≤ max b a * max b c := by
    calc
      b ^ 2 = b * b := pow_two b
      _ ≤ max b a * max b c := mul_le_mul (le_max_left _ _) (le_max_left _ _) hb.le ha.le
  simp only [one_div]
  rw [inv_sub_inv (ne_of_gt ha) (ne_of_gt hc), abs_div, abs_of_pos (mul_pos ha hc)]
  exact div_le_div₀ (abs_nonneg _) hn (sq_pos_of_pos hb) hd

def kernel (b : ℝ) (u : Path) (t r : ℝ) : ℝ :=
  (1 - r) * r ^ 5 / max b (extend u (t * r))

lemma continuous_kernel {b : ℝ} (hb : 0 < b) (u : Path) :
    Continuous (fun p : ℝ × ℝ => kernel b u p.1 p.2) := by
  unfold kernel
  apply Continuous.div
  · fun_prop
  · exact continuous_const.max ((continuous_extend u).comp (continuous_fst.mul continuous_snd))
  · intro p
    exact ne_of_gt (lt_of_lt_of_le hb (le_max_left _ _))

lemma kernel_integrable {b : ℝ} (hb : 0 < b) (u : Path) (t : ℝ) :
    IntegrableOn (kernel b u t) (Icc 0 1) := by
  have hc : Continuous (kernel b u t) :=
    (continuous_kernel hb u).comp (continuous_const.prodMk continuous_id)
  exact hc.continuousOn.integrableOn_compact isCompact_Icc

lemma weight_bounds {r : ℝ} (hr : r ∈ Icc (0 : ℝ) 1) :
    0 ≤ (1-r)*r^5 ∧ (1-r)*r^5 ≤ 1 := by
  have hp : 0 ≤ r^5 := pow_nonneg hr.1 _
  have hp1 : r^5 ≤ 1 := pow_le_one₀ hr.1 hr.2
  constructor
  · exact mul_nonneg (sub_nonneg.mpr hr.2) hp
  · calc
      (1-r)*r^5 ≤ 1*1 := mul_le_mul (by linarith [hr.1]) hp1 hp (by norm_num)
      _ = 1 := by ring

lemma kernel_nonneg {b : ℝ} (hb : 0 < b) (u : Path) (t : ℝ)
    {r : ℝ} (hr : r ∈ Icc (0 : ℝ) 1) : 0 ≤ kernel b u t r := by
  exact div_nonneg (weight_bounds hr).1 (le_trans hb.le (le_max_left _ _))

lemma kernel_le {b : ℝ} (hb : 0 < b) (u : Path) (t : ℝ)
    {r : ℝ} (hr : r ∈ Icc (0 : ℝ) 1) : kernel b u t r ≤ 1 / b := by
  exact div_le_div₀ (by norm_num) (weight_bounds hr).2 hb (le_max_left _ _)

lemma kernel_difference_bound {b : ℝ} (hb : 0 < b) (u v : Path) (t : ℝ)
    {r : ℝ} (hr : r ∈ Icc (0 : ℝ) 1) :
    |kernel b u t r - kernel b v t r| ≤ dist u v / b^2 := by
  have hp := weight_bounds hr
  have hrec := reciprocal_clamp_lipschitz (a := extend u (t*r))
    (c := extend v (t*r)) hb
  have hd : |extend u (t*r)-extend v (t*r)| ≤ dist u v := by
    simpa only [extend, Real.dist_eq] using
      (ContinuousMap.dist_apply_le_dist (f := u) (g := v) (clip (t*r)))
  calc
    |kernel b u t r-kernel b v t r| =
        ((1-r)*r^5)*|1/max b (extend u (t*r))-1/max b (extend v (t*r))| := by
      unfold kernel
      have heq : (1-r)*r^5 / max b (extend u (t*r)) -
          (1-r)*r^5 / max b (extend v (t*r)) =
          ((1-r)*r^5)*(1/max b (extend u (t*r))-1/max b (extend v (t*r))) := by ring
      rw [heq, abs_mul, abs_of_nonneg hp.1]
    _ ≤ 1 * (dist u v / b^2) := mul_le_mul hp.2
      (hrec.trans ((div_le_div_iff_of_pos_right (sq_pos_of_pos hb)).2 hd))
      (abs_nonneg _) (by norm_num)
    _ = dist u v / b^2 := one_mul _

def operator (b ε : ℝ) (hb : 0 < b) (u : Path) : Path where
  toFun t := b + ε * (t : ℝ)^6 * ∫ r in Icc (0 : ℝ) 1, kernel b u t r
  continuous_toFun := by
    have hc : Continuous (fun t : ℝ => ∫ r in Icc (0 : ℝ) 1, kernel b u t r) :=
      continuous_parametric_integral_of_continuous (continuous_kernel hb u) isCompact_Icc
    exact continuous_const.add ((continuous_const.mul (continuous_subtype_val.pow 6)).mul
      (hc.comp continuous_subtype_val))

lemma operator_lower {b ε : ℝ} (hb : 0 < b) (hε : 0 ≤ ε) (u : Path) (t : UnitI) :
    b ≤ operator b ε hb u t := by
  have hi : 0 ≤ ∫ r in Icc (0 : ℝ) 1, kernel b u t r :=
    setIntegral_nonneg measurableSet_Icc (fun r hr => kernel_nonneg hb u t hr)
  change b ≤ b + _
  exact le_add_of_nonneg_right (mul_nonneg (mul_nonneg hε (pow_nonneg t.property.1 6)) hi)

lemma integral_kernel_upper {b : ℝ} (hb : 0 < b) (u : Path) (t : ℝ) :
    (∫ r in Icc (0 : ℝ) 1, kernel b u t r) ≤ 1 / b := by
  have hc : IntegrableOn (fun _ : ℝ => 1 / b) (Icc 0 1) :=
    continuous_const.continuousOn.integrableOn_compact isCompact_Icc
  have h := setIntegral_mono_on (kernel_integrable hb u t) hc
    measurableSet_Icc (fun r hr => kernel_le hb u t hr)
  simpa [setIntegral_const, Real.volume_real_Icc] using h

lemma integral_kernel_difference_bound {b : ℝ} (hb : 0 < b) (u v : Path) (t : ℝ) :
    |(∫ r in Icc (0 : ℝ) 1, kernel b u t r)-
      (∫ r in Icc (0 : ℝ) 1, kernel b v t r)| ≤ dist u v / b^2 := by
  rw [← integral_sub (kernel_integrable hb u t) (kernel_integrable hb v t)]
  have h := norm_setIntegral_le_of_norm_le_const (μ := volume)
    (s := Icc (0 : ℝ) 1) isCompact_Icc.measure_lt_top
    (fun r hr => (show ‖kernel b u t r-kernel b v t r‖ ≤ dist u v/b^2 from
      kernel_difference_bound hb u v t hr))
  simpa [Real.norm_eq_abs, Real.volume_real_Icc] using h

lemma operator_distance_bound {b ε : ℝ} (hb : 0 < b) (hε : 0 ≤ ε)
    (u v : Path) :
    dist (operator b ε hb u) (operator b ε hb v) ≤ (ε / b^2) * dist u v := by
  apply (ContinuousMap.dist_le (mul_nonneg (div_nonneg hε (sq_nonneg b)) dist_nonneg)).2
  intro t
  have ht0 := t.property.1
  have ht1 : (t:ℝ)^6 ≤ 1 := pow_le_one₀ ht0 t.property.2
  have ht6 : 0 ≤ (t:ℝ)^6 := pow_nonneg ht0 6
  rw [Real.dist_eq]
  change |(b+ε*(t:ℝ)^6*_)-(b+ε*(t:ℝ)^6*_)| ≤ _
  rw [add_sub_add_left_eq_sub, ← mul_sub, abs_mul, abs_of_nonneg (mul_nonneg hε ht6)]
  calc
    ε*(t:ℝ)^6*|_ - _| ≤ ε*1*(dist u v/b^2) :=
      mul_le_mul (mul_le_mul_of_nonneg_left ht1 hε)
        (integral_kernel_difference_bound hb u v t) (abs_nonneg _) (by positivity)
    _ = (ε/b^2)*dist u v := by ring

lemma operator_contracting {b ε : ℝ} (hb : 0 < b) (hε : 0 ≤ ε)
    (hsmall : ε ≤ b^2/2) : ContractingWith (1/2) (operator b ε hb) := by
  constructor
  · rw [div_lt_iff₀ (by norm_num : (0 : ℝ≥0) < 2)]
    norm_num
  · apply LipschitzWith.of_dist_le_mul
    intro u v
    calc
      dist (operator b ε hb u) (operator b ε hb v) ≤ (ε/b^2)*dist u v :=
        operator_distance_bound hb hε u v
      _ ≤ (1/2 : ℝ)*dist u v := by
        apply mul_le_mul_of_nonneg_right _ dist_nonneg
        apply (div_le_iff₀ (sq_pos_of_pos hb)).2
        linarith

/-- An actual global solution of the desingularized collision integral equation. -/
theorem exists_collision_fixedPoint {b ε : ℝ} (hb : 0 < b) (hε : 0 ≤ ε)
    (hsmall : ε ≤ b^2/2) :
    ∃ u : Path, (∀ t, b ≤ u t) ∧
      (∀ t : UnitI, u t = b + ε*(t:ℝ)^6 *
        ∫ r in Icc (0 : ℝ) 1, (1-r)*r^5 / extend u ((t:ℝ)*r)) ∧
      (∀ t : UnitI, u t ≤ b + (ε/b)*(t:ℝ)^6) := by
  let hc := operator_contracting hb hε hsmall
  let u := hc.fixedPoint (operator b ε hb)
  have hu : operator b ε hb u = u := hc.fixedPoint_isFixedPt
  have hlo : ∀ t, b ≤ u t := by
    intro t
    rw [← hu]
    exact operator_lower hb hε u t
  refine ⟨u, hlo, ?_, ?_⟩
  · intro t
    have heq := congrArg (fun f : Path => f t) hu
    change operator b ε hb u t = u t at heq
    rw [← heq]
    change b + _ * _ = b + _ * _
    congr 2
    apply integral_congr_ae
    filter_upwards with r
    unfold kernel extend
    rw [max_eq_right (hlo (clip ((t:ℝ)*r)))]
  · intro t
    have heq := congrArg (fun f : Path => f t) hu
    change operator b ε hb u t = u t at heq
    rw [← heq]
    change b + ε*(t:ℝ)^6*_ ≤ _
    have hi := integral_kernel_upper hb u t
    have hm := mul_le_mul_of_nonneg_left hi (mul_nonneg hε (pow_nonneg t.property.1 6))
    calc
      b+ε*(t:ℝ)^6*_ ≤ b+ε*(t:ℝ)^6*(1/b) := add_le_add_left hm b
      _ = b+(ε/b)*(t:ℝ)^6 := by ring

#print axioms exists_collision_fixedPoint
end Collision
end ReciprocalCounterexample
