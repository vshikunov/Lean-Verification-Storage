import Mathlib.Analysis.Calculus.ContDiff.Basic
import Mathlib.Analysis.Calculus.Deriv.Basic
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Basic
import Mathlib.Algebra.Ring.Periodic

/-!
# The exact boundary-value problem and the main target

These definitions encode a classical solution on the closed interval using
continuous position, velocity, acceleration, and within-derivatives. They do
not assume a global extension of the solution. The equation is written as
`x * a = h`; positivity makes it equivalent to `a = h / x`.

`MainTheorem` is the proposition asserted in Theorem 1.1 of the revised manuscript.
Its unconditional proofs are in FlatCoreMain.lean and FlatCoreWitness.lean.
-/

noncomputable section
open Set MeasureTheory
open scoped Interval ContDiff

namespace ReciprocalCounterexample

/-- A positive classical solution on `[0,T]` with both periodic boundary
conditions. Within-derivatives at the endpoints are one-sided. -/
structure IsClassicalSolution (T : ℝ) (h x v a : ℝ → ℝ) : Prop where
  continuous_x : ContinuousOn x (Icc 0 T)
  continuous_v : ContinuousOn v (Icc 0 T)
  continuous_a : ContinuousOn a (Icc 0 T)
  dx : ∀ t ∈ Icc 0 T, HasDerivWithinAt x (v t) (Icc 0 T) t
  dv : ∀ t ∈ Icc 0 T, HasDerivWithinAt v (a t) (Icc 0 T) t
  positive : ∀ t ∈ Icc 0 T, 0 < x t
  equation : ∀ t ∈ Icc 0 T, x t * a t = h t
  endpoint_x : x 0 = x T
  endpoint_v : v 0 = v T

def HasPositivePeriodicSolution (T : ℝ) (h : ℝ → ℝ) : Prop :=
  ∃ x v a, IsClassicalSolution T h x v a

def ChangesSignOn (T : ℝ) (h : ℝ → ℝ) : Prop :=
  (∃ t ∈ Icc 0 T, h t < 0) ∧ (∃ t ∈ Icc 0 T, 0 < h t)

/-- All properties requested in the problem, plus the evenness asserted by
the manuscript. Smooth periodic real functions represent smooth functions
on `ℝ/ℤ`. -/
def IsCounterexample (h : ℝ → ℝ) : Prop :=
  ContDiff ℝ ∞ h ∧
  Function.Periodic h 1 ∧
  (∀ t, h (-t) = h t) ∧
  ChangesSignOn 1 h ∧
  (∫ t in (0 : ℝ)..1, h t) = -1 ∧
  ¬ HasPositivePeriodicSolution 1 h

/-- The manuscript's actual existence/nonexistence assertion. No proof of
this proposition is asserted by its definition. -/
def MainTheorem : Prop := ∃ h : ℝ → ℝ, IsCounterexample h

namespace IsClassicalSolution

theorem acceleration_eq_div {T : ℝ} {h x v a : ℝ → ℝ}
    (hs : IsClassicalSolution T h x v a) {t : ℝ} (ht : t ∈ Icc 0 T) :
    a t = h t / x t := by
  apply (eq_div_iff (ne_of_gt (hs.positive t ht))).2
  simpa [mul_comm] using hs.equation t ht

end IsClassicalSolution
end ReciprocalCounterexample
