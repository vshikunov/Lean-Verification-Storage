import ReciprocalCounterexample.FlatCoreProfile
import ReciprocalCounterexample.WeightedLog

/-!
# Quantitative logarithmic control for the flat-core equation

These estimates apply to the actual acceleration lambda*f/u. For normalized
trajectories 0<u<=1, lambda<=32, they bound logarithmic energy variation by a
linear function of total acceleration. No collision map is assumed.
-/
noncomputable section
open Set MeasureTheory Filter
open scoped Interval Topology

namespace ReciprocalCounterexample

def flatAcceleration (lam : ℝ) (u : ℝ → ℝ) (t : ℝ) : ℝ :=
  lam * flatCoreProfile t / u t

theorem lambda_log_ratio_bound {lam : ℝ} (hlam : 0 < lam) (hlam32 : lam ≤ 32) :
    lam * |Real.log (lam / 32)| ≤ 32 := by
  have hz : 0 ≤ lam / 32 := div_nonneg hlam.le (by norm_num)
  have hz1 : lam / 32 ≤ 1 := (div_le_one (by norm_num : (0 : ℝ) < 32)).2 hlam32
  have h := unit_mul_abs_log_le_one hz hz1
  nlinarith

/-- Actual pointwise normalized logarithmic-energy bound. -/
theorem flatCore_unit_weighted_log_pointwise {lam D t : ℝ} {u w : ℝ → ℝ}
    (hlam : 0 < lam) (hlam32 : lam ≤ 32) (hD : 0 ≤ D)
    (hu : 0 < u t) (hu1 : u t ≤ 1) (hw : 0 ≤ w t) (hwD : w t ≤ D)
    (hwzero : flatCoreProfile t = 0 → w t = 0) :
    lam * (w t * |Real.log (u t)|) ≤
      D * flatAcceleration lam u t + 32 * D +
        32 * (w t * |Real.log (flatCoreProfile t)|) := by
  by_cases hfzero : flatCoreProfile t = 0
  · rw [hwzero hfzero]
    simp only [flatAcceleration, hfzero, mul_zero, zero_div, zero_mul, zero_add, add_zero]
    positivity
  have hfpos : 0 < flatCoreProfile t := lt_of_le_of_ne (flatCoreProfile_nonneg t) (Ne.symm hfzero)
  let η : ℝ := lam / 32
  have hη : 0 < η := div_pos hlam (by norm_num)
  have hη1 : η ≤ 1 := (div_le_one (by norm_num : (0 : ℝ) < 32)).2 hlam32
  have hα : 0 < η * flatCoreProfile t := mul_pos hη hfpos
  have hα1 : η * flatCoreProfile t ≤ 1 :=
    le_trans (mul_le_mul_of_nonneg_left (flatCoreProfile_le_one t) hη.le)
      (by simpa using hη1)
  have hrecip := log_reciprocal_control hu hα hα1
  have huinv : -Real.log (u t) ≤ Real.log (1 + 1 / u t) := by
    rw [← Real.log_inv]
    apply Real.log_le_log (inv_pos.mpr hu)
    simp only [one_div]
    linarith
  have hY : 0 ≤ flatAcceleration lam u t :=
    div_nonneg (mul_nonneg hlam.le (flatCoreProfile_nonneg t)) hu.le
  have hloglin : Real.log (1 + η * flatCoreProfile t / u t) ≤
      η * flatCoreProfile t / u t := by
    have := Real.log_le_sub_one_of_pos
      (show 0 < 1 + η * flatCoreProfile t / u t by positivity)
    linarith
  have hlogα : Real.log (η * flatCoreProfile t) = Real.log η + Real.log (flatCoreProfile t) :=
    Real.log_mul (ne_of_gt hη) hfzero
  rw [hlogα] at hrecip
  have hscaled : η * flatCoreProfile t / u t = flatAcceleration lam u t / 32 := by
    dsimp [η, flatAcceleration]
    ring
  rw [hscaled] at hloglin
  have hrecip' : Real.log (1 + 1 / u t) ≤
      Real.log (1 + flatAcceleration lam u t / 32) -
        (Real.log η + Real.log (flatCoreProfile t)) := by
    simpa only [hscaled] using hrecip
  have hmajor : |Real.log (u t)| ≤ flatAcceleration lam u t / 32 +
      |Real.log η| + |Real.log (flatCoreProfile t)| := by
    rw [abs_of_nonpos (Real.log_nonpos hu.le hu1)]
    have hηabs := neg_le_abs (Real.log η)
    have hFabs := neg_le_abs (Real.log (flatCoreProfile t))
    linarith
  have hlamw : lam * w t ≤ 32 * D := mul_le_mul hlam32 hwD hw (by norm_num)
  have hfirst : (lam * w t / 32) * flatAcceleration lam u t ≤ D * flatAcceleration lam u t :=
    mul_le_mul_of_nonneg_right ((div_le_iff₀ (by norm_num : (0 : ℝ) < 32)).2 (by linarith)) hY
  have hlogratio : lam * |Real.log η| ≤ 32 := lambda_log_ratio_bound hlam hlam32
  have hsecond : w t * (lam * |Real.log η|) ≤ 32 * D := by
    calc
      w t * (lam * |Real.log η|) ≤ w t * 32 := mul_le_mul_of_nonneg_left hlogratio hw
      _ ≤ D * 32 := mul_le_mul_of_nonneg_right hwD (by norm_num)
      _ = 32 * D := by ring
  have hthird : lam * (w t * |Real.log (flatCoreProfile t)|) ≤
      32 * (w t * |Real.log (flatCoreProfile t)|) :=
    mul_le_mul_of_nonneg_right hlam32 (mul_nonneg hw (abs_nonneg _))
  calc
    lam * (w t * |Real.log (u t)|) ≤ lam * w t *
        (flatAcceleration lam u t / 32 + |Real.log η| + |Real.log (flatCoreProfile t)|) := by
      simpa only [mul_assoc] using mul_le_mul_of_nonneg_left hmajor (mul_nonneg hlam.le hw)
    _ = (lam * w t / 32) * flatAcceleration lam u t +
        w t * (lam * |Real.log η|) + lam * (w t * |Real.log (flatCoreProfile t)|) := by ring
    _ ≤ D * flatAcceleration lam u t + 32 * D +
        32 * (w t * |Real.log (flatCoreProfile t)|) :=
      add_le_add (add_le_add hfirst hsecond) hthird

/-- Uniform integral estimate with the total actual acceleration on the right.
The weight may be |f'| or f; their logarithmic moments are proved separately. -/
theorem flatCore_unit_weighted_log_integral_bound {lam D : ℝ} {u w : ℝ → ℝ}
    (hlam : 0 < lam) (hlam32 : lam ≤ 32) (hD : 0 ≤ D)
    (hucont : ContinuousOn u (Icc (-1 : ℝ) 1))
    (hupos : ∀ t ∈ Icc (-1 : ℝ) 1, 0 < u t)
    (hu1 : ∀ t ∈ Icc (-1 : ℝ) 1, u t ≤ 1)
    (hwcont : ContinuousOn w (Icc (-1 : ℝ) 1))
    (hwnonneg : ∀ t ∈ Icc (-1 : ℝ) 1, 0 ≤ w t)
    (hwD : ∀ t ∈ Icc (-1 : ℝ) 1, w t ≤ D)
    (hwzero : ∀ t ∈ Icc (-1 : ℝ) 1, flatCoreProfile t = 0 → w t = 0)
    (hmoment : IntervalIntegrable (fun t => w t * |Real.log (flatCoreProfile t)|)
      volume (-1) 1) :
    lam * (∫ t in (-1 : ℝ)..1, w t * |Real.log (u t)|) ≤
      D * (∫ t in (-1 : ℝ)..1, flatAcceleration lam u t) + 64 * D +
        32 * (∫ t in (-1 : ℝ)..1, w t * |Real.log (flatCoreProfile t)|) := by
  have hlog : ContinuousOn (fun t => |Real.log (u t)|) (Icc (-1 : ℝ) 1) :=
    (hucont.log (fun t ht => ne_of_gt (hupos t ht))).abs
  have hleft : IntervalIntegrable (fun t => w t * |Real.log (u t)|) volume (-1) 1 :=
    (hwcont.mul hlog).intervalIntegrable_of_Icc (by norm_num)
  have hacc : IntervalIntegrable (flatAcceleration lam u) volume (-1) 1 :=
    ((continuousOn_const.mul flatCoreProfile_contDiff.continuous.continuousOn).div hucont
      (fun t ht => ne_of_gt (hupos t ht))).intervalIntegrable_of_Icc (by norm_num)
  have hfirst := hacc.const_mul D
  have hc : IntervalIntegrable (fun _ : ℝ => 32 * D) volume (-1) 1 := intervalIntegrable_const
  have hthird := hmoment.const_mul (32 : ℝ)
  have hmono := intervalIntegral.integral_mono_on (by norm_num : (-1 : ℝ) ≤ 1)
    (hleft.const_mul lam) ((hfirst.add hc).add hthird)
    (fun t ht => flatCore_unit_weighted_log_pointwise hlam hlam32 hD (hupos t ht) (hu1 t ht)
      (hwnonneg t ht) (hwD t ht) (hwzero t ht))
  rw [intervalIntegral.integral_const_mul,
    intervalIntegral.integral_add (hfirst.add hc) hthird,
    intervalIntegral.integral_add hfirst hc,
    intervalIntegral.integral_const_mul, intervalIntegral.integral_const,
    intervalIntegral.integral_const_mul] at hmono
  norm_num [smul_eq_mul] at hmono
  nlinarith

/-- The derivative-weight estimate used to control the energy oscillation. -/
theorem flatCore_unit_deriv_log_integral_bound {lam D : ℝ} {u : ℝ → ℝ}
    (hlam : 0 < lam) (hlam32 : lam ≤ 32) (hD : 0 ≤ D)
    (hucont : ContinuousOn u (Icc (-1 : ℝ) 1))
    (hupos : ∀ t ∈ Icc (-1 : ℝ) 1, 0 < u t)
    (hu1 : ∀ t ∈ Icc (-1 : ℝ) 1, u t ≤ 1)
    (hderiv : ∀ t ∈ Icc (-1 : ℝ) 1, |deriv flatCoreProfile t| ≤ D) :
    lam * (∫ t in (-1 : ℝ)..1, |deriv flatCoreProfile t| * |Real.log (u t)|) ≤
      D * (∫ t in (-1 : ℝ)..1, flatAcceleration lam u t) + 64 * D +
        32 * (∫ t in (-1 : ℝ)..1,
          |deriv flatCoreProfile t| * |Real.log (flatCoreProfile t)|) := by
  exact flatCore_unit_weighted_log_integral_bound hlam hlam32 hD hucont hupos hu1
    (flatCoreProfile_contDiff.continuous_deriv (by simp)).abs.continuousOn
    (fun t _ => abs_nonneg _) hderiv
    (fun t _ hz => by rw [flatCoreProfile_deriv_eq_zero_of_profile_zero hz, abs_zero])
    (flatCoreProfile_logMoment_intervalIntegrable (-1) 1)

/-- The profile-weight estimate controlling the mean of logarithmic energy. -/
theorem flatCore_unit_profile_log_integral_bound {lam : ℝ} {u : ℝ → ℝ}
    (hlam : 0 < lam) (hlam32 : lam ≤ 32)
    (hucont : ContinuousOn u (Icc (-1 : ℝ) 1))
    (hupos : ∀ t ∈ Icc (-1 : ℝ) 1, 0 < u t)
    (hu1 : ∀ t ∈ Icc (-1 : ℝ) 1, u t ≤ 1) :
    lam * (∫ t in (-1 : ℝ)..1, flatCoreProfile t * |Real.log (u t)|) ≤
      (∫ t in (-1 : ℝ)..1, flatAcceleration lam u t) + 128 := by
  have h := flatCore_unit_weighted_log_integral_bound hlam hlam32 (by norm_num : (0 : ℝ) ≤ 1)
    hucont hupos hu1 flatCoreProfile_contDiff.continuous.continuousOn
    (fun t _ => flatCoreProfile_nonneg t) (fun t _ => flatCoreProfile_le_one t)
    (fun _ _ hz => hz) (flatCoreProfile_entropy_abs_continuous.intervalIntegrable (-1) 1)
  have hj := flatCoreProfile_entropy_integral_le_two
  nlinarith

#print axioms flatCore_unit_weighted_log_integral_bound
#print axioms flatCore_unit_deriv_log_integral_bound
#print axioms flatCore_unit_profile_log_integral_bound

end ReciprocalCounterexample
