import ReciprocalCounterexample.FlatCoreEnergy
import ReciprocalCounterexample.FlatCoreLog
import Mathlib.Topology.Order.Compact

/-!
# A uniform slope bound for the flat-core bowl

This module closes the normalized endpoint-slope estimate from the actual ODE,
including unequal endpoint heights. Its uniform constant depends only on the
fixed smooth forcing profile.
-/
noncomputable section
open Set MeasureTheory
open scoped Interval

namespace ReciprocalCounterexample

def flatCoreLogMoment : ℝ :=
  ∫ t in (-1 : ℝ)..1, |deriv flatCoreProfile t| * |Real.log (flatCoreProfile t)|

def flatCoreSlopeConstant (D : ℝ) : ℝ := 132 * (D + 1) + 64 * flatCoreLogMoment

theorem flatCoreLogMoment_nonneg : 0 ≤ flatCoreLogMoment :=
  intervalIntegral.integral_nonneg (by norm_num)
    (fun t _ => mul_nonneg (abs_nonneg _) (abs_nonneg _))

theorem flatCoreSlopeConstant_pos {D : ℝ} (hD : 0 ≤ D) :
    0 < flatCoreSlopeConstant D := by
  dsimp [flatCoreSlopeConstant]
  linarith [flatCoreLogMoment_nonneg]

private theorem quadratic_bound {V A B : ℝ} (hA : 0 ≤ A) (hB : 0 ≤ B)
    (hq : V^2 ≤ A * V + B) : V ≤ A + B + 1 := by
  by_contra h
  have hV : A + B + 1 < V := lt_of_not_ge h
  have h1 : 1 < V := by linarith
  have hVA : 0 < V - A := by linarith
  have hp := mul_pos (sub_pos.mpr h1) hVA
  nlinarith

namespace PositiveBowl
variable {ε : ℝ} {x v a : ℝ → ℝ}

theorem flat_integral_acceleration (hs : PositiveBowl ε flatCoreProfile x v a) :
    (∫ t in (-1 : ℝ)..1, flatAcceleration ε x t) = v 1 - v (-1) := by
  calc
    (∫ t in (-1 : ℝ)..1, flatAcceleration ε x t) =
        ∫ t in (-1 : ℝ)..1, a t := by
      apply intervalIntegral.integral_congr
      intro t ht
      exact (hs.acceleration_eq (by simpa using ht)).symm
    _ = v 1 - v (-1) := hs.integral_acceleration

/-- A normalized solution has uniformly bounded velocity on the entire bowl. -/
theorem flat_normalized_velocity_bound (hs : PositiveBowl ε flatCoreProfile x v a)
    {D : ℝ} (hε : 0 < ε) (hD : 0 ≤ D)
    (hderiv : ∀ t ∈ Icc (-1 : ℝ) 1, |deriv flatCoreProfile t| ≤ D)
    (hx1 : ∀ t ∈ Icc (-1 : ℝ) 1, x t ≤ 1)
    {t : ℝ} (ht : t ∈ Icc (-1 : ℝ) 1) :
    |v t| ≤ flatCoreSlopeConstant D := by
  have hε32 : ε ≤ 32 := hs.normalized_parameter_le hε.le hx1 (by
    intro s hs'
    apply flatCoreProfile_one_of_half_le_abs
    rw [abs_of_nonpos (by linarith [hs'.2] : s ≤ 0)]
    linarith [hs'.2])
  have hprofile := flatCore_unit_profile_log_integral_bound hε hε32
    hs.continuous_x hs.positive hx1
  have hlog := flatCore_unit_deriv_log_integral_bound hε hε32 hD
    hs.continuous_x hs.positive hx1 hderiv
  rw [hs.flat_integral_acceleration] at hprofile hlog
  have hfc : ContinuousOn flatCoreProfile (Icc (-1 : ℝ) 1) :=
    flatCoreProfile_contDiff.continuous.continuousOn
  have hfpc : ContinuousOn (deriv flatCoreProfile) (Icc (-1 : ℝ) 1) :=
    (flatCoreProfile_contDiff.continuous_deriv (by simp)).continuousOn
  have hdf : ∀ s ∈ Icc (-1 : ℝ) 1,
      HasDerivAt flatCoreProfile (deriv flatCoreProfile s) s :=
    fun s _ => (flatCoreProfile_contDiff.differentiable (by simp) s).hasDerivAt
  let S : ℝ := |v (-1)| + |v 1|
  let V : ℝ := max |v (-1)| |v 1|
  have hS : S ≤ 2 * V := by
    dsimp [S, V]
    linarith [le_max_left |v (-1)| |v 1|, le_max_right |v (-1)| |v 1|]
  have htot : v 1 - v (-1) ≤ S := by
    dsimp [S]
    linarith [le_abs_self (v 1), neg_le_abs (v (-1))]
  have hmean : bowlAverage (profileEnergy ε flatCoreProfile x v) ≤ 3 * S / 4 + 64 := by
    have hE := hs.energy_integral hfc hx1
    have hK := hs.kinetic_integral_le hε.le (fun s _ => flatCoreProfile_nonneg s) hx1
    dsimp [bowlAverage]
    dsimp [S] at htot ⊢
    linarith
  have hosc : ∀ s ∈ Icc (-1 : ℝ) 1, ∀ r ∈ Icc (-1 : ℝ) 1,
      |profileEnergy ε flatCoreProfile x v s - profileEnergy ε flatCoreProfile x v r| ≤
        D * S + 64 * D + 32 * flatCoreLogMoment := by
    intro s hs' r hr
    have he := hs.energy_oscillation hε.le hfc hfpc hdf hs' hr
    have hmul := mul_le_mul_of_nonneg_left htot hD
    dsimp [flatCoreLogMoment] at *
    linarith
  have hpoint : ∀ s ∈ Icc (-1 : ℝ) 1,
      (v s)^2 / 2 ≤ 3 * S / 4 + 64 + D * S + 64 * D + 32 * flatCoreLogMoment := by
    intro s hs'
    have he := hs.energy_ge_kinetic hε.le (fun r _ => flatCoreProfile_nonneg r) hx1 hs'
    have hd := (abs_le.mp (distance_bowlAverage_le (hs.continuous_energy hfc) hosc hs')).2
    calc
      (v s)^2 / 2 ≤ profileEnergy ε flatCoreProfile x v s := he
      _ ≤ (D * S + 64 * D + 32 * flatCoreLogMoment) +
          bowlAverage (profileEnergy ε flatCoreProfile x v) := (sub_le_iff_le_add).mp hd
      _ ≤ (D * S + 64 * D + 32 * flatCoreLogMoment) + (3 * S / 4 + 64) :=
        add_le_add_left hmean _
      _ = _ := by ring
  have hVL := hpoint (-1) (by norm_num)
  have hVR := hpoint 1 (by norm_num)
  have hVsq : V^2 / 2 ≤ 3 * S / 4 + 64 + D * S + 64 * D + 32 * flatCoreLogMoment := by
    rcases le_total |v (-1)| |v 1| with h | h
    · simpa only [V, max_eq_right h, sq_abs] using hVR
    · simpa only [V, max_eq_left h, sq_abs] using hVL
  have hDS := mul_le_mul_of_nonneg_left hS hD
  have hq : V^2 ≤ (3 + 4 * D) * V + (128 + 128 * D + 64 * flatCoreLogMoment) := by
    have hstep : V^2 ≤ (3 * S / 4 + 64 + D * S + 64 * D +
        32 * flatCoreLogMoment) * 2 := (div_le_iff₀ (by norm_num : (0 : ℝ) < 2)).mp hVsq
    have hSscaled := mul_le_mul_of_nonneg_left hS (show (0 : ℝ) ≤ 3/2 by norm_num)
    have hDSscaled := mul_le_mul_of_nonneg_left hDS (show (0 : ℝ) ≤ 2 by norm_num)
    dsimp [S, V, flatCoreLogMoment] at hstep hSscaled hDSscaled ⊢
    linarith only [hstep, hSscaled, hDSscaled]
  have hVbound : V ≤ flatCoreSlopeConstant D := by
    have hh := quadratic_bound (by linarith : 0 ≤ 3 + 4 * D)
      (by linarith [flatCoreLogMoment_nonneg] : 0 ≤ 128 + 128 * D + 64 * flatCoreLogMoment) hq
    dsimp [flatCoreSlopeConstant]
    linarith
  have hmono := hs.velocity_monotone hε.le (fun s _ => flatCoreProfile_nonneg s)
  have hleft := hmono (by norm_num : (-1 : ℝ) ∈ Icc (-1 : ℝ) 1) ht ht.1
  have hright := hmono ht (by norm_num : (1 : ℝ) ∈ Icc (-1 : ℝ) 1) ht.2
  have htv : |v t| ≤ V := by
    apply abs_le.mpr
    dsimp [V]
    constructor
    · linarith [le_max_left |v (-1)| |v 1|, neg_le_abs (v (-1))]
    · linarith [le_max_right |v (-1)| |v 1|, le_abs_self (v 1)]
  exact htv.trans hVbound

/-- Undoing the height normalization gives the slope bound needed across the
short smooth negative pulse. -/
theorem flat_velocity_bound (hs : PositiveBowl ε flatCoreProfile x v a)
    {D : ℝ} (hε : 0 < ε) (hD : 0 ≤ D)
    (hderiv : ∀ t ∈ Icc (-1 : ℝ) 1, |deriv flatCoreProfile t| ≤ D)
    {t : ℝ} (ht : t ∈ Icc (-1 : ℝ) 1) :
    |v t| ≤ flatCoreSlopeConstant D * max (x (-1)) (x 1) := by
  let A := max (x (-1)) (x 1)
  have hA : 0 < A := lt_of_lt_of_le (hs.positive (-1) (by norm_num)) (le_max_left _ _)
  have hu := hs.div_const hA
  have hu1 : ∀ s ∈ Icc (-1 : ℝ) 1, x s / A ≤ 1 := by
    intro s hs'
    apply (div_le_one hA).2
    exact hs.height_le_max_endpoints hε.le (fun r _ => flatCoreProfile_nonneg r) hs'
  have hbound := hu.flat_normalized_velocity_bound
    (div_pos hε (sq_pos_of_pos hA)) hD hderiv hu1 ht
  change |v t / A| ≤ flatCoreSlopeConstant D at hbound
  rw [abs_div, abs_of_pos hA] at hbound
  exact (div_le_iff₀ hA).mp hbound

end PositiveBowl

/-- One fixed positive constant works for every positive flat-profile bowl. -/
theorem exists_flatCore_slope_bound : ∃ C : ℝ, 0 < C ∧
    ∀ (ε : ℝ) (x v a : ℝ → ℝ), 0 < ε → PositiveBowl ε flatCoreProfile x v a →
      ∀ t ∈ Icc (-1 : ℝ) 1, |v t| ≤ C * max (x (-1)) (x 1) := by
  obtain ⟨s, hs, hmax⟩ := isCompact_Icc.exists_isMaxOn
    (show (Icc (-1 : ℝ) 1).Nonempty by exact ⟨0, by norm_num⟩)
    ((flatCoreProfile_contDiff.continuous_deriv (by simp)).abs.continuousOn)
  let D := |deriv flatCoreProfile s|
  have hD : 0 ≤ D := abs_nonneg _
  have hderiv : ∀ t ∈ Icc (-1 : ℝ) 1, |deriv flatCoreProfile t| ≤ D := hmax
  refine ⟨flatCoreSlopeConstant D, flatCoreSlopeConstant_pos hD, ?_⟩
  intro ε x v a hε hb t ht
  exact hb.flat_velocity_bound hε hD hderiv ht

#print axioms PositiveBowl.flat_normalized_velocity_bound
#print axioms PositiveBowl.flat_velocity_bound
#print axioms exists_flatCore_slope_bound
end ReciprocalCounterexample
