import ReciprocalCounterexample.FlatCoreForcing
import ReciprocalCounterexample.SmoothPulseBounds

/-! Exact positive/negative mass accounting for the translated flat-core forcing. -/
noncomputable section
open Set MeasureTheory
open scoped ContDiff Interval
namespace ReciprocalCounterexample

def flatCoreRawPositive (ε δ s : ℝ) : ℝ := flatCorePositive ε δ (s - halfPeriod δ)
def flatCoreRawNegative (δ s : ℝ) : ℝ := flatCoreNegative δ (s - halfPeriod δ)

theorem flatCoreRawPositive_continuous (ε δ : ℝ) : Continuous (flatCoreRawPositive ε δ) :=
  (flatCorePositive_contDiff ε δ).continuous.comp (continuous_id.sub continuous_const)

theorem flatCoreRawNegative_continuous (δ : ℝ) : Continuous (flatCoreRawNegative δ) :=
  (flatCoreNegative_contDiff δ).continuous.comp (continuous_id.sub continuous_const)

theorem flatCoreRawPositive_nonneg {ε δ : ℝ} (hε : 0 ≤ ε) (hδ : 0 < δ) (s : ℝ) :
    0 ≤ flatCoreRawPositive ε δ s := flatCorePositive_nonneg hε hδ _

theorem flatCoreRawPositive_le {ε δ : ℝ} (hε : 0 ≤ ε) (hδ : 0 < δ) (s : ℝ) :
    flatCoreRawPositive ε δ s ≤ ε := flatCorePositive_le hε hδ _

theorem flatCoreRawNegative_nonneg {δ : ℝ} (hδ : 0 < δ) (s : ℝ) :
    0 ≤ flatCoreRawNegative δ s := flatCoreNegative_nonneg hδ _

theorem flatCoreRawForcing_decomposition {ε δ s : ℝ} (hδ : 0 < δ)
    (hs : s ∈ Icc 0 (fullPeriod δ)) :
    flatCoreRawForcing ε δ s = flatCoreRawPositive ε δ s - flatCoreRawNegative δ s :=
  flatCoreRawForcing_eq_even hδ hs

theorem flatCoreRawNegative_integral {δ : ℝ} (hδ : 0 < δ) :
    (∫ s in (0 : ℝ)..fullPeriod δ, flatCoreRawNegative δ s) = 2 := by
  unfold flatCoreRawNegative
  rw [intervalIntegral.integral_comp_sub_right, zero_sub,
    show fullPeriod δ - halfPeriod δ = halfPeriod δ by unfold fullPeriod; ring]
  exact flatCoreNegative_integral hδ

theorem flatCoreRawPositive_integral_le {ε δ : ℝ} (hε : 0 ≤ ε) (hδ : 0 < δ) :
    (∫ s in (0 : ℝ)..fullPeriod δ, flatCoreRawPositive ε δ s) ≤ ε * fullPeriod δ := by
  unfold flatCoreRawPositive
  rw [intervalIntegral.integral_comp_sub_right, zero_sub,
    show fullPeriod δ - halfPeriod δ = halfPeriod δ by unfold fullPeriod; ring]
  exact flatCorePositive_integral_le hε hδ

/-- Three adjacent intervals give one exact full-period integral. -/
theorem pulseIntegral_add_bowl {T l r : ℝ} {F : ℝ → ℝ}
    (hF : Continuous F) :
    pulseIntegral T l r F + (∫ s in l..r, F s) = ∫ s in (0 : ℝ)..T, F s := by
  have hI (a b : ℝ) : IntervalIntegrable F volume a b := hF.intervalIntegrable a b
  unfold pulseIntegral
  rw [show (∫ s in (0:ℝ)..l, F s) + (∫ s in r..T, F s) + (∫ s in l..r, F s) =
      ((∫ s in (0:ℝ)..l, F s) + (∫ s in l..r, F s)) + (∫ s in r..T, F s) by ring,
    intervalIntegral.integral_add_adjacent_intervals (hI 0 l) (hI l r),
    intervalIntegral.integral_add_adjacent_intervals (hI 0 r) (hI r T)]

theorem flatCoreRawNegative_zero_on_bowl {δ s : ℝ} (hδ : 0 < δ)
    (hs : s ∈ Icc (halfPeriod δ - 1) (halfPeriod δ + 1)) :
    flatCoreRawNegative δ s = 0 := by
  apply flatCoreNegative_zero hδ
  exact abs_le.mpr ⟨by linarith [hs.1], by linarith [hs.2]⟩

theorem flatCoreRawNegative_bowl_integral {δ : ℝ} (hδ : 0 < δ) :
    (∫ s in (halfPeriod δ - 1)..(halfPeriod δ + 1), flatCoreRawNegative δ s) = 0 := by
  calc
    _ = ∫ s in (halfPeriod δ - 1)..(halfPeriod δ + 1), (0 : ℝ) := by
      apply intervalIntegral.integral_congr
      intro s hs
      rw [uIcc_of_le (by linarith : halfPeriod δ - 1 ≤ halfPeriod δ + 1)] at hs
      exact flatCoreRawNegative_zero_on_bowl hδ hs
    _ = 0 := by simp

theorem flatCoreRawNegative_pulseIntegral {δ : ℝ} (hδ : 0 < δ) :
    pulseIntegral (fullPeriod δ) (halfPeriod δ - 1) (halfPeriod δ + 1)
      (flatCoreRawNegative δ) = 2 := by
  have h := pulseIntegral_add_bowl (T := fullPeriod δ)
    (l := halfPeriod δ - 1) (r := halfPeriod δ + 1) (flatCoreRawNegative_continuous δ)
  rw [flatCoreRawNegative_bowl_integral hδ, flatCoreRawNegative_integral hδ, add_zero] at h
  exact h

theorem flatCoreRawPositive_pulseIntegral_nonneg {ε δ : ℝ}
    (hε : 0 ≤ ε) (hδ : 0 < δ) :
    0 ≤ pulseIntegral (fullPeriod δ) (halfPeriod δ - 1) (halfPeriod δ + 1)
      (flatCoreRawPositive ε δ) := by
  apply pulseIntegral_nonneg (by unfold halfPeriod; linarith)
    (by unfold fullPeriod halfPeriod; linarith)
  intro s _
  exact flatCoreRawPositive_nonneg hε hδ s

theorem flatCoreRawPositive_pulseIntegral_le {ε δ : ℝ}
    (hε : 0 ≤ ε) (hδ : 0 < δ) :
    pulseIntegral (fullPeriod δ) (halfPeriod δ - 1) (halfPeriod δ + 1)
      (flatCoreRawPositive ε δ) ≤ 4 * ε * δ := by
  calc
    _ ≤ pulseIntegral (fullPeriod δ) (halfPeriod δ - 1) (halfPeriod δ + 1)
        (fun _ => ε) := by
      apply pulseIntegral_mono (by unfold halfPeriod; linarith)
        (by unfold fullPeriod halfPeriod; linarith)
        (flatCoreRawPositive_continuous ε δ).continuousOn continuousOn_const
      intro s _
      exact flatCoreRawPositive_le hε hδ s
    _ = 4 * ε * δ := by
      simp only [pulseIntegral, intervalIntegral.integral_const, smul_eq_mul, fullPeriod, halfPeriod]
      ring

end ReciprocalCounterexample
