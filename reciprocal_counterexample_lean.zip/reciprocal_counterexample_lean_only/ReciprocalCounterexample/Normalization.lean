import ReciprocalCounterexample.Definitions
import Mathlib.Analysis.Calculus.ContDiff.Operations
import Mathlib.Analysis.Calculus.Deriv.Comp
import Mathlib.Analysis.Calculus.Deriv.Mul
import Mathlib.Analysis.Calculus.Deriv.Inv
import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring

/-!
# Period and mean normalization

The normalization and solution transport in Section 7 are proved for arbitrary
raw forcings. The last theorem has an EXPLICIT hypothesis that the raw problem
has no positive solution. This file does not prove that analytic hypothesis for
the proposed forcing family.
-/

noncomputable section
open Set MeasureTheory
open scoped Interval ContDiff

namespace ReciprocalCounterexample

def normalizedForcing (T M : ℝ) (H : ℝ → ℝ) (t : ℝ) : ℝ :=
  (T / M) * H (T * t)

def rescale (A T : ℝ) (f : ℝ → ℝ) (s : ℝ) : ℝ :=
  A * f (s / T)

lemma div_mem_unitInterval {T s : ℝ} (hT : 0 < T) (hs : s ∈ Icc 0 T) :
    s / T ∈ Icc (0 : ℝ) 1 := by
  exact ⟨div_nonneg hs.1 hT.le, (div_le_one hT).2 hs.2⟩

lemma rescale_continuousOn {T A : ℝ} {f : ℝ → ℝ} (hT : 0 < T)
    (hf : ContinuousOn f (Icc (0 : ℝ) 1)) :
    ContinuousOn (rescale A T f) (Icc 0 T) := by
  exact continuousOn_const.mul
    (hf.comp (continuous_id.div_const T).continuousOn
      (fun _ hs => div_mem_unitInterval hT hs))

lemma rescale_hasDerivWithinAt {T A s : ℝ} {f g : ℝ → ℝ}
    (hT : 0 < T)
    (hf : HasDerivWithinAt f (g (s / T)) (Icc (0 : ℝ) 1) (s / T)) :
    HasDerivWithinAt (rescale A T f) ((A / T) * g (s / T)) (Icc 0 T) s := by
  have hlin : HasDerivWithinAt (fun t : ℝ => t / T) (1 / T) (Icc 0 T) s :=
    ((hasDerivAt_id s).div_const T).hasDerivWithinAt
  have hc := (hf.comp s hlin (fun _ ht => div_mem_unitInterval hT ht)).const_mul A
  convert hc using 1
  ring

theorem normalized_contDiff {T M : ℝ} {H : ℝ → ℝ}
    (hH : ContDiff ℝ ∞ H) : ContDiff ℝ ∞ (normalizedForcing T M H) := by
  exact contDiff_const.mul (hH.comp (contDiff_const.mul contDiff_id))

theorem normalized_periodic {T M : ℝ} {H : ℝ → ℝ}
    (hH : Function.Periodic H T) : Function.Periodic (normalizedForcing T M H) 1 := by
  intro t
  simp only [normalizedForcing, mul_add, mul_one, hH (T * t)]

theorem normalized_even {T M : ℝ} {H : ℝ → ℝ}
    (hH : ∀ t, H (-t) = H t) :
    ∀ t, normalizedForcing T M H (-t) = normalizedForcing T M H t := by
  intro t
  simp only [normalizedForcing, mul_neg, hH]

theorem normalized_mean {T M : ℝ} {H : ℝ → ℝ}
    (hT : T ≠ 0) (hM : M ≠ 0)
    (hmass : (∫ s in (0 : ℝ)..T, H s) = -M) :
    (∫ t in (0 : ℝ)..1, normalizedForcing T M H t) = -1 := by
  unfold normalizedForcing
  rw [intervalIntegral.integral_const_mul,
    intervalIntegral.integral_comp_mul_left H hT]
  simp only [mul_zero, mul_one, smul_eq_mul, hmass]
  field_simp [hT, hM]
  ring

theorem normalized_changesSign {T M : ℝ} {H : ℝ → ℝ}
    (hT : 0 < T) (hM : 0 < M) (hsign : ChangesSignOn T H) :
    ChangesSignOn 1 (normalizedForcing T M H) := by
  rcases hsign with ⟨⟨s, hs, hneg⟩, ⟨t, ht, hpos⟩⟩
  constructor
  · refine ⟨s / T, div_mem_unitInterval hT hs, ?_⟩
    simpa [normalizedForcing, mul_div_cancel₀ _ (ne_of_gt hT)] using
      mul_neg_of_pos_of_neg (div_pos hT hM) hneg
  · refine ⟨t / T, div_mem_unitInterval hT ht, ?_⟩
    simpa [normalizedForcing, mul_div_cancel₀ _ (ne_of_gt hT)] using
      mul_pos (div_pos hT hM) hpos

lemma scale_equation {A T M Y B F : ℝ}
    (hT : T ≠ 0) (hM : M ≠ 0) (hA : A ^ 2 = T * M)
    (heq : Y * B = (T / M) * F) :
    (A * Y) * ((A / T ^ 2) * B) = F := by
  calc
    (A * Y) * ((A / T ^ 2) * B) = (A ^ 2 / T ^ 2) * (Y * B) := by ring
    _ = (T * M / T ^ 2) * ((T / M) * F) := by rw [hA, heq]
    _ = F := by field_simp [hT, hM]; ring

/-- The actual classical solution is transported, including both derivatives,
positivity, its differential equation, and both endpoint conditions. -/
theorem rescale_solution {T M A : ℝ} {H y v a : ℝ → ℝ}
    (hT : 0 < T) (hM : 0 < M) (hA : 0 < A) (hA2 : A ^ 2 = T * M)
    (hs : IsClassicalSolution 1 (normalizedForcing T M H) y v a) :
    IsClassicalSolution T H (rescale A T y)
      (rescale (A / T) T v) (rescale (A / T ^ 2) T a) := by
  refine ⟨rescale_continuousOn hT hs.continuous_x,
    rescale_continuousOn hT hs.continuous_v,
    rescale_continuousOn hT hs.continuous_a, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · intro t ht
    exact rescale_hasDerivWithinAt hT (hs.dx _ (div_mem_unitInterval hT ht))
  · intro t ht
    have hd := rescale_hasDerivWithinAt (A := A / T) hT
      (hs.dv _ (div_mem_unitInterval hT ht))
    simpa only [rescale, div_div, ← pow_two] using hd
  · intro t ht
    exact mul_pos hA (hs.positive _ (div_mem_unitInterval hT ht))
  · intro t ht
    have heq := hs.equation (t / T) (div_mem_unitInterval hT ht)
    simp only [normalizedForcing, mul_div_cancel₀ _ (ne_of_gt hT)] at heq
    exact scale_equation (ne_of_gt hT) (ne_of_gt hM) hA2 heq
  · simpa [rescale, ne_of_gt hT] using congrArg (fun z : ℝ => A * z) hs.endpoint_x
  · simpa [rescale, ne_of_gt hT] using
      congrArg (fun z : ℝ => (A / T) * z) hs.endpoint_v

/-- Section 7's nonexistence implication. The raw nonexistence hypothesis
`hno` is explicit and is not discharged by this theorem. -/
theorem normalized_no_solution {T M : ℝ} {H : ℝ → ℝ}
    (hT : 0 < T) (hM : 0 < M)
    (hno : ¬ HasPositivePeriodicSolution T H) :
    ¬ HasPositivePeriodicSolution 1 (normalizedForcing T M H) := by
  rintro ⟨y, v, a, hs⟩
  apply hno
  refine ⟨rescale (Real.sqrt (T * M)) T y,
    rescale (Real.sqrt (T * M) / T) T v,
    rescale (Real.sqrt (T * M) / T ^ 2) T a, ?_⟩
  exact rescale_solution hT hM (Real.sqrt_pos.2 (mul_pos hT hM))
    (Real.sq_sqrt (mul_pos hT hM).le) hs

/-- Complete normalization criterion, CONDITIONAL on a raw counterexample.
This is not a proof that the manuscript's raw family satisfies `hno`. -/
theorem normalized_isCounterexample {T M : ℝ} {H : ℝ → ℝ}
    (hT : 0 < T) (hM : 0 < M)
    (hsmooth : ContDiff ℝ ∞ H)
    (hperiodic : Function.Periodic H T)
    (heven : ∀ t, H (-t) = H t)
    (hsign : ChangesSignOn T H)
    (hmass : (∫ s in (0 : ℝ)..T, H s) = -M)
    (hno : ¬ HasPositivePeriodicSolution T H) :
    IsCounterexample (normalizedForcing T M H) := by
  exact ⟨normalized_contDiff hsmooth, normalized_periodic hperiodic,
    normalized_even heven, normalized_changesSign hT hM hsign,
    normalized_mean (ne_of_gt hT) (ne_of_gt hM) hmass,
    normalized_no_solution hT hM hno⟩

#print axioms rescale_solution
#print axioms normalized_mean
#print axioms normalized_isCounterexample

end ReciprocalCounterexample
