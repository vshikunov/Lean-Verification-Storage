import ReciprocalCounterexample.FlatCoreProfile
import ReciprocalCounterexample.PeriodicForcing
import ReciprocalCounterexample.Definitions

/-!
# A smooth periodic forcing with a flat central interval

The positive profile vanishes identically on `[-1/4,1/4]`.  Its negative
pulse has exactly mass two.  The half-period translation places the entire
positive bowl inside the classical solution interval, so no extension of
an arbitrary solution is assumed.
-/
noncomputable section
open Set MeasureTheory Function Filter
open scoped ContDiff Topology
namespace ReciprocalCounterexample

def flatCoreCutoff (δ u : ℝ) : ℝ :=
  1 - smoothStep ((u - 1) / δ) - smoothStep ((-u - 1) / δ)

theorem flatCoreCutoff_contDiff (δ : ℝ) : ContDiff ℝ ∞ (flatCoreCutoff δ) := by
  exact (contDiff_const.sub (smoothStep_contDiff.comp
    ((contDiff_id.sub contDiff_const).div_const δ))).sub
    (smoothStep_contDiff.comp ((contDiff_id.neg.sub contDiff_const).div_const δ))

theorem flatCoreCutoff_even (δ u : ℝ) : flatCoreCutoff δ (-u) = flatCoreCutoff δ u := by
  simp only [flatCoreCutoff, neg_neg]
  ring

theorem flatCoreCutoff_one {δ u : ℝ} (hδ : 0 < δ) (hu : |u| ≤ 1) :
    flatCoreCutoff δ u = 1 := by
  have hu' := abs_le.mp hu
  rw [flatCoreCutoff,
    smoothStep_zero_of_nonpos (div_nonpos_of_nonpos_of_nonneg (by linarith) hδ.le),
    smoothStep_zero_of_nonpos (div_nonpos_of_nonpos_of_nonneg (by linarith) hδ.le)]
  ring

theorem flatCoreCutoff_zero {δ u : ℝ} (hδ : 0 < δ) (hu : 1 + δ ≤ |u|) :
    flatCoreCutoff δ u = 0 := by
  rcases le_total 0 u with hs | hs
  · rw [abs_of_nonneg hs] at hu
    rw [flatCoreCutoff,
      smoothStep_one_of_one_le ((le_div_iff₀ hδ).2 (by linarith)),
      smoothStep_zero_of_nonpos (div_nonpos_of_nonpos_of_nonneg (by linarith) hδ.le)]
    ring
  · rw [abs_of_nonpos hs] at hu
    rw [flatCoreCutoff,
      smoothStep_zero_of_nonpos (div_nonpos_of_nonpos_of_nonneg (by linarith) hδ.le),
      smoothStep_one_of_one_le ((le_div_iff₀ hδ).2 (by linarith))]
    ring

theorem flatCoreCutoff_nonneg {δ : ℝ} (hδ : 0 < δ) (u : ℝ) :
    0 ≤ flatCoreCutoff δ u := by
  rcases le_total 0 u with hs | hs
  · rw [flatCoreCutoff,
      smoothStep_zero_of_nonpos (show (-u - 1) / δ ≤ 0 from
        div_nonpos_of_nonpos_of_nonneg (by linarith) hδ.le), sub_zero]
    linarith [smoothStep_le_one ((u - 1) / δ)]
  · rw [flatCoreCutoff,
      smoothStep_zero_of_nonpos (div_nonpos_of_nonpos_of_nonneg (by linarith) hδ.le), sub_zero]
    linarith [smoothStep_le_one ((-u - 1) / δ)]

theorem flatCoreCutoff_le_one (δ u : ℝ) : flatCoreCutoff δ u ≤ 1 := by
  unfold flatCoreCutoff
  linarith [smoothStep_nonneg ((u - 1) / δ), smoothStep_nonneg ((-u - 1) / δ)]

def flatCorePositive (ε δ u : ℝ) : ℝ := ε * flatCoreProfile u * flatCoreCutoff δ u

def flatCoreNegative (δ u : ℝ) : ℝ := negativePulse δ u + negativePulse δ (-u)

def flatCoreEven (ε δ u : ℝ) : ℝ := flatCorePositive ε δ u - flatCoreNegative δ u

theorem flatCorePositive_contDiff (ε δ : ℝ) : ContDiff ℝ ∞ (flatCorePositive ε δ) :=
  (contDiff_const.mul flatCoreProfile_contDiff).mul (flatCoreCutoff_contDiff δ)

theorem flatCoreNegative_contDiff (δ : ℝ) : ContDiff ℝ ∞ (flatCoreNegative δ) :=
  (negativePulse_contDiff δ).add ((negativePulse_contDiff δ).comp contDiff_id.neg)

theorem flatCoreEven_contDiff (ε δ : ℝ) : ContDiff ℝ ∞ (flatCoreEven ε δ) :=
  (flatCorePositive_contDiff ε δ).sub (flatCoreNegative_contDiff δ)

theorem flatCorePositive_even (ε δ u : ℝ) :
    flatCorePositive ε δ (-u) = flatCorePositive ε δ u := by
  simp only [flatCorePositive, flatCoreProfile_even, flatCoreCutoff_even]

theorem flatCoreNegative_even (δ u : ℝ) : flatCoreNegative δ (-u) = flatCoreNegative δ u := by
  simp only [flatCoreNegative, neg_neg, add_comm]

theorem flatCoreEven_even (ε δ u : ℝ) : flatCoreEven ε δ (-u) = flatCoreEven ε δ u := by
  simp only [flatCoreEven, flatCorePositive_even, flatCoreNegative_even]

theorem flatCorePositive_nonneg {ε δ : ℝ} (hε : 0 ≤ ε) (hδ : 0 < δ) (u : ℝ) :
    0 ≤ flatCorePositive ε δ u :=
  mul_nonneg (mul_nonneg hε (flatCoreProfile_nonneg u)) (flatCoreCutoff_nonneg hδ u)

theorem flatCorePositive_le {ε δ : ℝ} (hε : 0 ≤ ε) (hδ : 0 < δ) (u : ℝ) :
    flatCorePositive ε δ u ≤ ε := by
  calc
    flatCorePositive ε δ u ≤ ε * flatCoreProfile u * 1 :=
      mul_le_mul_of_nonneg_left (flatCoreCutoff_le_one δ u)
        (mul_nonneg hε (flatCoreProfile_nonneg u))
    _ ≤ ε := by simpa using mul_le_mul_of_nonneg_left (flatCoreProfile_le_one u) hε

theorem flatCoreNegative_nonneg {δ : ℝ} (hδ : 0 < δ) (u : ℝ) :
    0 ≤ flatCoreNegative δ u := by
  unfold flatCoreNegative negativePulse
  exact add_nonneg (mul_nonneg (by positivity) (smoothStep_nonneg _))
    (mul_nonneg (by positivity) (smoothStep_nonneg _))

theorem flatCoreNegative_zero {δ u : ℝ} (hδ : 0 < δ) (hu : |u| ≤ 1 + δ) :
    flatCoreNegative δ u = 0 := by
  have hu' := abs_le.mp hu
  rw [flatCoreNegative, negativePulse_zero_before δ u hδ hu'.2,
    negativePulse_zero_before δ (-u) hδ (by linarith)]
  ring

theorem flatCoreEven_bowl {ε δ u : ℝ} (hδ : 0 < δ) (hu : |u| ≤ 1) :
    flatCoreEven ε δ u = ε * flatCoreProfile u := by
  rw [flatCoreEven, flatCorePositive, flatCoreCutoff_one hδ hu,
    flatCoreNegative_zero hδ (by linarith)]
  ring

theorem flatCoreEven_constant_outside {ε δ u : ℝ} (hδ : 0 < δ)
    (hu : halfPeriod δ ≤ |u|) : flatCoreEven ε δ u = -(2 / δ) := by
  have hcut : flatCoreCutoff δ u = 0 := flatCoreCutoff_zero hδ (by
    unfold halfPeriod at hu; linarith)
  have hn : flatCoreNegative δ u = 2 / δ := by
    rcases le_total 0 u with hs | hs
    · rw [abs_of_nonneg hs] at hu
      rw [flatCoreNegative, negativePulse_zero_before δ (-u) hδ (by linarith), add_zero,
        negativePulse, smoothStep_one_of_one_le ((le_div_iff₀ hδ).2 (by
          unfold halfPeriod at hu; linarith)), mul_one]
    · rw [abs_of_nonpos hs] at hu
      rw [flatCoreNegative, negativePulse_zero_before δ u hδ (by linarith), zero_add,
        negativePulse, smoothStep_one_of_one_le ((le_div_iff₀ hδ).2 (by
          unfold halfPeriod at hu; linarith)), mul_one]
  simp only [flatCoreEven, flatCorePositive, hcut, mul_zero, hn, zero_sub]

def flatCoreBump (ε δ u : ℝ) : ℝ := flatCoreEven ε δ u + 2 / δ

theorem flatCoreBump_contDiff (ε δ : ℝ) : ContDiff ℝ ∞ (flatCoreBump ε δ) :=
  (flatCoreEven_contDiff ε δ).add contDiff_const

theorem flatCoreBump_even (ε δ u : ℝ) : flatCoreBump ε δ (-u) = flatCoreBump ε δ u := by
  simp only [flatCoreBump, flatCoreEven_even]

theorem flatCoreBump_zero {ε δ u : ℝ} (hδ : 0 < δ) (hu : halfPeriod δ ≤ |u|) :
    flatCoreBump ε δ u = 0 := by
  rw [flatCoreBump, flatCoreEven_constant_outside hδ hu]
  ring

def flatCorePeriodic (ε δ u : ℝ) : ℝ :=
  (∑ᶠ n : ℤ, flatCoreBump ε δ (u + n * fullPeriod δ)) - 2 / δ

theorem flatCorePeriodic_periodic (ε δ : ℝ) :
    Function.Periodic (flatCorePeriodic ε δ) (fullPeriod δ) := by
  intro u
  unfold flatCorePeriodic
  congr 1
  apply finsum_eq_of_bijective (fun n : ℤ => n + 1) (Equiv.addRight (1 : ℤ)).bijective
  intro n
  congr 1
  push_cast
  ring

theorem flatCorePeriodic_even (ε δ u : ℝ) : flatCorePeriodic ε δ (-u) = flatCorePeriodic ε δ u := by
  unfold flatCorePeriodic
  congr 1
  apply finsum_eq_of_bijective (fun n : ℤ => -n) (Equiv.neg ℤ).bijective
  intro n
  rw [show -u + (n : ℝ) * fullPeriod δ = -(u + (-n : ℤ) * fullPeriod δ) by
    push_cast; ring]
  exact flatCoreBump_even ε δ _

theorem flatCoreBump_shift_zero {ε δ u : ℝ} (hδ : 0 < δ)
    (hu : u ∈ Icc (-halfPeriod δ) (halfPeriod δ)) (n : ℤ) (hn : n ≠ 0) :
    flatCoreBump ε δ (u + n * fullPeriod δ) = 0 := by
  have hL : 0 < halfPeriod δ := by unfold halfPeriod; linarith
  apply flatCoreBump_zero hδ
  rcases lt_or_gt_of_ne hn with hn | hn
  · have hn₁ : (n : ℝ) ≤ -1 := by exact_mod_cast (show n ≤ -1 by omega)
    have hfar : u + n * fullPeriod δ ≤ -halfPeriod δ := by
      unfold fullPeriod; nlinarith [hu.2]
    exact (by linarith : halfPeriod δ ≤ -(u + n * fullPeriod δ)).trans (neg_le_abs _)
  · have hn₁ : (1 : ℝ) ≤ n := by exact_mod_cast (show 1 ≤ n by omega)
    have hfar : halfPeriod δ ≤ u + n * fullPeriod δ := by
      unfold fullPeriod; nlinarith [hu.1]
    exact hfar.trans (le_abs_self _)

theorem flatCorePeriodic_eq_even {ε δ u : ℝ} (hδ : 0 < δ)
    (hu : u ∈ Icc (-halfPeriod δ) (halfPeriod δ)) :
    flatCorePeriodic ε δ u = flatCoreEven ε δ u := by
  unfold flatCorePeriodic
  rw [finsum_eq_single _ (0 : ℤ) (fun n hn => flatCoreBump_shift_zero hδ hu n hn)]
  simp [flatCoreBump]

theorem flatCorePeriodic_contDiff {ε δ : ℝ} (hδ : 0 < δ) :
    ContDiff ℝ ∞ (flatCorePeriodic ε δ) := by
  have hT : 0 < fullPeriod δ := by unfold fullPeriod halfPeriod; linarith
  exact (contDiff_finsum_int_translate (flatCoreBump ε δ) (flatCoreBump_contDiff ε δ)
    (halfPeriod δ) (fullPeriod δ) hT (fun u hu => flatCoreBump_zero hδ hu)).sub
      contDiff_const

def flatCoreRawForcing (ε δ s : ℝ) : ℝ := flatCorePeriodic ε δ (s - halfPeriod δ)

theorem flatCoreRawForcing_contDiff {ε δ : ℝ} (hδ : 0 < δ) :
    ContDiff ℝ ∞ (flatCoreRawForcing ε δ) :=
  (flatCorePeriodic_contDiff hδ).comp (contDiff_id.sub contDiff_const)

theorem flatCoreRawForcing_periodic (ε δ : ℝ) :
    Function.Periodic (flatCoreRawForcing ε δ) (fullPeriod δ) := by
  intro s
  change flatCorePeriodic ε δ (s + fullPeriod δ - halfPeriod δ) = _
  rw [show s + fullPeriod δ - halfPeriod δ = s - halfPeriod δ + fullPeriod δ by ring,
    flatCorePeriodic_periodic]
  rfl

theorem flatCoreRawForcing_even (ε δ s : ℝ) :
    flatCoreRawForcing ε δ (-s) = flatCoreRawForcing ε δ s := by
  unfold flatCoreRawForcing
  rw [show -s - halfPeriod δ = -(s + halfPeriod δ) by ring, flatCorePeriodic_even,
    show s + halfPeriod δ = s - halfPeriod δ + fullPeriod δ by unfold fullPeriod; ring,
    flatCorePeriodic_periodic]

theorem flatCoreRawForcing_eq_even {ε δ s : ℝ} (hδ : 0 < δ)
    (hs : s ∈ Icc 0 (fullPeriod δ)) :
    flatCoreRawForcing ε δ s = flatCoreEven ε δ (s - halfPeriod δ) := by
  apply flatCorePeriodic_eq_even hδ
  unfold fullPeriod at hs
  constructor <;> linarith [hs.1, hs.2]

theorem flatCoreRawForcing_bowl {ε δ t : ℝ} (hδ : 0 < δ) (ht : |t| ≤ 1) :
    flatCoreRawForcing ε δ (halfPeriod δ + t) = ε * flatCoreProfile t := by
  rw [flatCoreRawForcing, add_sub_cancel_left,
    flatCorePeriodic_eq_even hδ (by
      have h := abs_le.mp ht
      unfold halfPeriod
      constructor <;> linarith [h.1, h.2]), flatCoreEven_bowl hδ ht]

theorem flatCoreRawForcing_sign_change {ε δ : ℝ} (hε : 0 < ε) (hδ : 0 < δ) :
    ChangesSignOn (fullPeriod δ) (flatCoreRawForcing ε δ) := by
  have hL : 1 < halfPeriod δ := by unfold halfPeriod; linarith
  have hT : 0 < fullPeriod δ := by unfold fullPeriod; linarith
  constructor
  · refine ⟨0, ⟨le_rfl, hT.le⟩, ?_⟩
    rw [flatCoreRawForcing_eq_even hδ ⟨le_rfl, hT.le⟩,
      flatCoreEven_constant_outside hδ (by
        rw [zero_sub, abs_neg, abs_of_pos (by linarith : 0 < halfPeriod δ)])]
    exact neg_neg_of_pos (div_pos (by norm_num) hδ)
  · refine ⟨halfPeriod δ + 1, ⟨by linarith, by unfold fullPeriod; linarith⟩, ?_⟩
    rw [flatCoreRawForcing_bowl hδ (by norm_num : |(1 : ℝ)| ≤ 1),
      flatCoreProfile_one_of_half_le_abs (by norm_num : (1:ℝ)/2 ≤ |(1:ℝ)|), mul_one]
    exact hε

/-- Exactly two units of negative pulse mass in a fundamental interval. -/
theorem flatCoreNegative_integral {δ : ℝ} (hδ : 0 < δ) :
    (∫ s in -halfPeriod δ..halfPeriod δ, flatCoreNegative δ s) = 2 := by
  have hI (a b : ℝ) : IntervalIntegrable (negativePulse δ) volume a b :=
    (negativePulse_contDiff δ).continuous.intervalIntegrable a b
  have hzero : (∫ s in -halfPeriod δ..(0 : ℝ), negativePulse δ s) = 0 := by
    calc
      _ = ∫ s in -halfPeriod δ..(0 : ℝ), (0 : ℝ) := by
        apply intervalIntegral.integral_congr
        intro s hs
        rw [uIcc_of_le (by unfold halfPeriod; linarith : -halfPeriod δ ≤ (0 : ℝ))] at hs
        exact negativePulse_zero_before δ s hδ (by linarith [hs.2])
      _ = 0 := by simp
  have hmass : (∫ s in -halfPeriod δ..halfPeriod δ, negativePulse δ s) = 1 := by
    rw [← intervalIntegral.integral_add_adjacent_intervals (hI (-halfPeriod δ) 0)
      (hI 0 (halfPeriod δ)), hzero, zero_add, negativePulse_integral_halfPeriod δ hδ]
  have hIn : IntervalIntegrable (fun s => negativePulse δ (-s)) volume
      (-halfPeriod δ) (halfPeriod δ) :=
    ((negativePulse_contDiff δ).continuous.comp continuous_neg).intervalIntegrable _ _
  unfold flatCoreNegative
  rw [intervalIntegral.integral_add (hI _ _) hIn,
    intervalIntegral.integral_comp_neg, neg_neg, hmass]
  norm_num

def flatCoreMass (ε δ : ℝ) : ℝ :=
  2 - ∫ s in -halfPeriod δ..halfPeriod δ, flatCorePositive ε δ s

theorem flatCorePositive_integral_nonneg {ε δ : ℝ} (hε : 0 ≤ ε) (hδ : 0 < δ) :
    0 ≤ ∫ s in -halfPeriod δ..halfPeriod δ, flatCorePositive ε δ s := by
  apply intervalIntegral.integral_nonneg (by unfold halfPeriod; linarith)
  intro s _
  exact flatCorePositive_nonneg hε hδ s

theorem flatCorePositive_integral_le {ε δ : ℝ} (hε : 0 ≤ ε) (hδ : 0 < δ) :
    (∫ s in -halfPeriod δ..halfPeriod δ, flatCorePositive ε δ s) ≤ ε * fullPeriod δ := by
  calc
    _ ≤ ∫ s in -halfPeriod δ..halfPeriod δ, ε := by
      apply intervalIntegral.integral_mono_on (by unfold halfPeriod; linarith)
        ((flatCorePositive_contDiff ε δ).continuous.intervalIntegrable _ _)
        (continuous_const.intervalIntegrable _ _)
      intro s _
      exact flatCorePositive_le hε hδ s
    _ = ε * fullPeriod δ := by simp [intervalIntegral.integral_const, fullPeriod]; ring

theorem flatCoreMass_bounds {ε δ : ℝ} (hε : 0 ≤ ε) (hδ : 0 < δ) :
    2 - ε * fullPeriod δ ≤ flatCoreMass ε δ ∧ flatCoreMass ε δ ≤ 2 := by
  constructor
  · unfold flatCoreMass
    linarith [flatCorePositive_integral_le hε hδ]
  · unfold flatCoreMass
    linarith [flatCorePositive_integral_nonneg hε hδ]

theorem flatCoreRawForcing_integral {ε δ : ℝ} (hδ : 0 < δ) :
    (∫ s in (0 : ℝ)..fullPeriod δ, flatCoreRawForcing ε δ s) = -flatCoreMass ε δ := by
  have heq : (∫ s in (0 : ℝ)..fullPeriod δ, flatCoreRawForcing ε δ s) =
      ∫ s in (0 : ℝ)..fullPeriod δ, flatCoreEven ε δ (s - halfPeriod δ) := by
    apply intervalIntegral.integral_congr
    intro s hs
    rw [uIcc_of_le (by unfold fullPeriod halfPeriod; linarith : (0:ℝ) ≤ fullPeriod δ)] at hs
    exact flatCoreRawForcing_eq_even hδ hs
  rw [heq, intervalIntegral.integral_comp_sub_right, zero_sub,
    show fullPeriod δ - halfPeriod δ = halfPeriod δ by unfold fullPeriod; ring]
  unfold flatCoreEven
  rw [intervalIntegral.integral_sub
    ((flatCorePositive_contDiff ε δ).continuous.intervalIntegrable _ _)
    ((flatCoreNegative_contDiff δ).continuous.intervalIntegrable _ _), flatCoreNegative_integral hδ]
  unfold flatCoreMass
  ring

end ReciprocalCounterexample
