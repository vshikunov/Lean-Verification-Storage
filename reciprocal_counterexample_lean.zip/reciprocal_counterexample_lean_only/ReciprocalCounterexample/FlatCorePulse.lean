import ReciprocalCounterexample.FlatCoreHeight

/-!
# Quantitative smooth-pulse estimates for the actual flat-core family

The parameters are ε = η² and δ = η⁴/4096. The estimates below are derived
from every putative positive classical periodic solution. No limiting
solution, collision flow, or compactness hypothesis is used.
-/

noncomputable section
open Set MeasureTheory
open scoped Interval

namespace ReciprocalCounterexample
namespace IsClassicalSolution

set_option maxHeartbeats 800000

/-- The explicit two-scale family has small bowl displacement, small
scaled acceleration mass, and small kinetic energy on the smooth pulse. -/
theorem flatCore_eta_pulse_bounds {η : ℝ} {x v a : ℝ → ℝ}
    (hη : 0 < η) (hη1 : η ≤ 1)
    (hs : IsClassicalSolution (fullPeriod (η ^ 4 / 4096))
      (flatCoreRawForcing (η ^ 2) (η ^ 4 / 4096)) x v a) :
    (|∫ t in (-1 : ℝ)..1, v (halfPeriod (η ^ 4 / 4096) + t)| ≤ η ^ 2 / 16) ∧
    (η ^ 2 * (∫ t in (-1 : ℝ)..1, a (halfPeriod (η ^ 4 / 4096) + t)) ≤ 36 * η) ∧
    (pulseIntegral (fullPeriod (η ^ 4 / 4096))
      (halfPeriod (η ^ 4 / 4096) - 1) (halfPeriod (η ^ 4 / 4096) + 1)
      (fun t => (v t) ^ 2) ≤ 6 * η ^ 2) := by
  let δ := η ^ 4 / 4096
  let T := fullPeriod δ
  let L := halfPeriod δ
  let l := L - 1
  let r := L + 1
  let A := max (x l) (x r)
  let d := η ^ 2 / 32
  have hδ : 0 < δ := by dsimp [δ]; positivity
  have hl : 0 ≤ l := by dsimp [l, L, halfPeriod]; linarith
  have hlr : l < r := by dsimp [l, r]; linarith
  have hr : r ≤ T := by dsimp [r, L, T, fullPeriod, halfPeriod]; linarith
  have hlen : r - l = 2 := by dsimp [r, l]; ring
  have hA : 0 < A := (hs.positive l ⟨hl, hlr.le.trans hr⟩).trans_le (le_max_left _ _)
  have hA2 : η ^ 2 ≤ 32 * A ^ 2 := hs.flatCore_endpoint_height_sq (sq_nonneg η) hδ
  have hηA : η ≤ 6 * A := by
    apply (sq_le_sq₀ hη.le (by positivity : 0 ≤ 6 * A)).mp
    nlinarith [sq_nonneg A]
  have hη2 : η ^ 2 ≤ 1 := pow_le_one₀ hη.le hη1
  have hη3 : η ^ 3 ≤ 1 := pow_le_one₀ hη.le hη1
  have hη4 : η ^ 4 ≤ 1 := pow_le_one₀ hη.le hη1
  have hη6 : η ^ 6 ≤ 1 := pow_le_one₀ hη.le hη1
  have hd : 0 ≤ d := by dsimp [d]; positivity
  have hδ2 : 0 ≤ 2 * δ := by positivity
  have hE : (∫ t in (0 : ℝ)..T, (v t) ^ 2) ≤ 2 :=
    hs.flatCore_energy_le_two (sq_nonneg η) hδ
  have hmod : ∀ u ∈ pulseSet T l r, |x u - x 0| ≤ d := by
    have hh := hs.pulse_position_modulus hl hlr.le hr
      (D := 2 * δ) (E := 2)
      (by dsimp [l, L, halfPeriod, δ]; linarith)
      (by dsimp [T, r, L, fullPeriod, halfPeriod, δ]; linarith)
      (by norm_num) hE
    have hid : (2 * δ) * 2 = d ^ 2 := by dsimp [δ, d]; ring
    rw [hid, Real.sqrt_sq hd] at hh
    exact hh
  have hsmall : 4 * d ≤ A := by
    have hh : η ^ 2 ≤ η := by nlinarith [mul_nonneg hη.le (sub_nonneg.mpr hη1)]
    dsimp [d]
    nlinarith
  have hb := hs.flatCore_bowl hδ
  have hmono : MonotoneOn v (Icc l r) := by
    intro s hs' t ht hst
    have hms : s - L ∈ Icc (-1 : ℝ) 1 := by
      constructor <;> dsimp [l, r] at hs' <;> linarith [hs'.1, hs'.2]
    have hmt : t - L ∈ Icc (-1 : ℝ) 1 := by
      constructor <;> dsimp [l, r] at ht <;> linarith [ht.1, ht.2]
    have hh := hb.velocity_monotone (sq_nonneg η)
      (fun t _ => flatCoreProfile_nonneg t) hms hmt (sub_le_sub_right hst L)
    simpa only [show halfPeriod δ + (s - L) = s by dsimp [L]; ring,
      show halfPeriod δ + (t - L) = t by dsimp [L]; ring] using hh
  have hpmass : pulseIntegral T l r (flatCoreRawPositive (η ^ 2) δ) ≤ 1 := by
    have hh := flatCoreRawPositive_pulseIntegral_le (sq_nonneg η) hδ
    have hid : 4 * η ^ 2 * δ = η ^ 6 / 1024 := by dsimp [δ]; ring
    rw [hid] at hh
    exact hh.trans (by linarith)
  have hsub := pulseSet_subset hl hlr.le hr
  have hest := hs.short_pulse_bounds hl hlr hr hlen hA rfl hmono hmod hsmall
    (flatCoreRawPositive_continuous (η ^ 2) δ).continuousOn
    (flatCoreRawNegative_continuous δ).continuousOn
    (fun u _ => flatCoreRawPositive_nonneg (sq_nonneg η) hδ u)
    (fun u _ => flatCoreRawNegative_nonneg hδ u)
    (fun u hu => flatCoreRawForcing_decomposition hδ (hsub hu))
    hpmass (le_of_eq (flatCoreRawNegative_pulseIntegral hδ))
  have hdis : |∫ t in (-1 : ℝ)..1, v (L + t)| ≤ η ^ 2 / 16 := by
    rw [hb.integral_velocity]
    have hh := hest.2.2.2
    simpa only [L, r, l, d, sub_eq_add_neg, show 2 * (η ^ 2 / 32) = η ^ 2 / 16 by ring] using hh
  have hscaled : η ^ 2 * (v r - v l) ≤ 36 * η := by
    calc
      η ^ 2 * (v r - v l) ≤ η ^ 2 * (6 / A) :=
        mul_le_mul_of_nonneg_left hest.1 (sq_nonneg η)
      _ = (6 * η ^ 2) / A := by ring
      _ ≤ 36 * η := (div_le_iff₀ hA).2 (by nlinarith [mul_le_mul_of_nonneg_left hηA (by positivity : 0 ≤ 6 * η)])
  have hacc : η ^ 2 * (∫ t in (-1 : ℝ)..1, a (L + t)) ≤ 36 * η := by
    rw [hb.integral_acceleration]
    simpa only [r, l, L, sub_eq_add_neg] using hscaled
  have h12 : 12 / A ≤ 72 / η := by
    apply (div_le_div_iff₀ hA hη).2
    nlinarith
  have hd1 : d ≤ 1 / η := by
    apply (le_div_iff₀ hη).2
    dsimp [d]
    nlinarith
  have hV : d + 12 / A ≤ 73 / η := by
    have hh := add_le_add hd1 h12
    convert hh using 1 <;> ring
  have hV0 : 0 ≤ d + 12 / A := by positivity
  have hV' : 0 ≤ 73 / η := by positivity
  have hVsq := (sq_le_sq₀ hV0 hV').2 hV
  have hlength : l + (T - r) = 4 * δ := by dsimp [l, r, L, T, fullPeriod, halfPeriod]; ring
  have hkin : pulseIntegral T l r (fun t => (v t) ^ 2) ≤ 6 * η ^ 2 := by
    calc
      pulseIntegral T l r (fun t => (v t) ^ 2) ≤ 4 * δ * (d + 12 / A) ^ 2 := by
        have hh := hest.2.2.1
        change pulseIntegral T l r (fun u => (v u) ^ 2) ≤
          (l + (T - r)) * (d + 12 / A) ^ 2 at hh
        rwa [hlength] at hh
      _ ≤ 4 * δ * (73 / η) ^ 2 := mul_le_mul_of_nonneg_left hVsq (by positivity)
      _ = (5329 / 1024 : ℝ) * η ^ 2 := by dsimp [δ]; field_simp [ne_of_gt hη]; ring
      _ ≤ 6 * η ^ 2 := by nlinarith [sq_nonneg η]
  exact ⟨hdis, hacc, hkin⟩

end IsClassicalSolution

#print axioms IsClassicalSolution.flatCore_eta_pulse_bounds

end ReciprocalCounterexample
