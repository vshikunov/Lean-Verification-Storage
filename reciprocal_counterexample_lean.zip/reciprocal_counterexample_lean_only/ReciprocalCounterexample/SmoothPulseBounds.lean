import ReciprocalCounterexample.Energy
import Mathlib.Analysis.SpecialFunctions.Sqrt

/-!
# Direct estimates across short smooth forcing pulses

These estimates are derived from the classical boundary-value problem itself.
They use the exact global energy identity, the fundamental theorem of calculus,
and integral inequalities; no collision continuation or solution map is assumed.
-/

noncomputable section
open Set MeasureTheory
open scoped Interval

namespace ReciprocalCounterexample

/-- The fundamental theorem on a closed interval, formulated with continuous
within-derivatives at the endpoints. -/
theorem integral_eq_sub_of_within_derivative {s t : ℝ} {f g : ℝ → ℝ}
    (hst : s ≤ t) (hf : ContinuousOn f (Icc s t))
    (hg : ContinuousOn g (Icc s t))
    (hd : ∀ u ∈ Icc s t, HasDerivWithinAt f (g u) (Icc s t) u) :
    (∫ u in s..t, g u) = f t - f s := by
  apply intervalIntegral.integral_eq_sub_of_hasDerivAt_of_le hst hf
  · intro u hu
    exact (hd u (mem_Icc_of_Ioo hu)).hasDerivAt (Icc_mem_nhds hu.1 hu.2)
  · exact hg.intervalIntegrable_of_Icc hst

/-- The scalar integral Cauchy--Schwarz inequality, proved directly by
integrating a nonnegative square. -/
theorem sq_integral_le_length_mul_integral_sq {s t : ℝ} {v : ℝ → ℝ}
    (hst : s ≤ t) (hv : ContinuousOn v (Icc s t)) :
    (∫ u in s..t, v u) ^ 2 ≤ (t - s) * ∫ u in s..t, (v u) ^ 2 := by
  rcases hst.eq_or_lt with hst | hst
  · subst t
    simp
  let L := t - s
  let I := ∫ u in s..t, v u
  let J := ∫ u in s..t, (v u) ^ 2
  have hL : 0 < L := sub_pos.mpr hst
  have hi : IntervalIntegrable v volume s t := hv.intervalIntegrable_of_Icc hst.le
  have hj : IntervalIntegrable (fun u => (v u) ^ 2) volume s t :=
    (hv.pow 2).intervalIntegrable_of_Icc hst.le
  have hzero := intervalIntegral.integral_nonneg (μ := volume) hst.le
    (fun u (_ : u ∈ Icc s t) => sq_nonneg (L * v u - I))
  have hid : (∫ u in s..t, (L * v u - I) ^ 2) = L ^ 2 * J - L * I ^ 2 := by
    calc
      (∫ u in s..t, (L * v u - I) ^ 2) =
          ∫ u in s..t, L ^ 2 * (v u) ^ 2 - (2 * L * I) * v u + I ^ 2 := by
        apply intervalIntegral.integral_congr
        intro u _
        ring
      _ = L ^ 2 * J - (2 * L * I) * I + (t - s) * I ^ 2 := by
        rw [intervalIntegral.integral_add
          ((hj.const_mul _).sub (hi.const_mul _)) intervalIntegrable_const,
          intervalIntegral.integral_sub (hj.const_mul _) (hi.const_mul _),
          intervalIntegral.integral_const_mul, intervalIntegral.integral_const_mul,
          intervalIntegral.integral_const]
        simp only [smul_eq_mul, I, J]
      _ = L ^ 2 * J - L * I ^ 2 := by dsimp [L]; ring
  rw [hid] at hzero
  change I ^ 2 ≤ L * J
  apply (mul_le_mul_left hL).mp
  nlinarith

/-- The two short intervals meeting the periodic seam. -/
def pulseSet (T l r : ℝ) : Set ℝ := Icc 0 l ∪ Icc r T

/-- Integration over the two endpoint pulse intervals. -/
def pulseIntegral (T l r : ℝ) (F : ℝ → ℝ) : ℝ :=
  (∫ u in (0 : ℝ)..l, F u) + ∫ u in r..T, F u

lemma pulseSet_subset {T l r : ℝ} (hl : 0 ≤ l) (hlr : l ≤ r) (hr : r ≤ T) :
    pulseSet T l r ⊆ Icc 0 T := by
  intro u hu
  rcases hu with hu | hu
  · exact ⟨hu.1, hu.2.trans (hlr.trans hr)⟩
  · exact ⟨(hl.trans hlr).trans hu.1, hu.2⟩

lemma pulseIntegral_nonneg {T l r : ℝ} {F : ℝ → ℝ}
    (hl : 0 ≤ l) (hr : r ≤ T) (hF : ∀ u ∈ pulseSet T l r, 0 ≤ F u) :
    0 ≤ pulseIntegral T l r F := by
  exact add_nonneg
    (intervalIntegral.integral_nonneg hl (fun u hu => hF u (Or.inl hu)))
    (intervalIntegral.integral_nonneg hr (fun u hu => hF u (Or.inr hu)))

lemma pulseIntegral_mono {T l r : ℝ} {F G : ℝ → ℝ}
    (hl : 0 ≤ l) (hr : r ≤ T)
    (hF : ContinuousOn F (pulseSet T l r))
    (hG : ContinuousOn G (pulseSet T l r))
    (hFG : ∀ u ∈ pulseSet T l r, F u ≤ G u) :
    pulseIntegral T l r F ≤ pulseIntegral T l r G := by
  apply add_le_add
  · exact intervalIntegral.integral_mono_on hl
      ((hF.mono subset_union_left).intervalIntegrable_of_Icc hl)
      ((hG.mono subset_union_left).intervalIntegrable_of_Icc hl)
      (fun u hu => hFG u (Or.inl hu))
  · exact intervalIntegral.integral_mono_on hr
      ((hF.mono subset_union_right).intervalIntegrable_of_Icc hr)
      ((hG.mono subset_union_right).intervalIntegrable_of_Icc hr)
      (fun u hu => hFG u (Or.inr hu))

lemma pulseIntegral_sub {T l r : ℝ} {F G : ℝ → ℝ}
    (hl : 0 ≤ l) (hr : r ≤ T)
    (hF : ContinuousOn F (pulseSet T l r))
    (hG : ContinuousOn G (pulseSet T l r)) :
    pulseIntegral T l r (fun u => F u - G u) =
      pulseIntegral T l r F - pulseIntegral T l r G := by
  unfold pulseIntegral
  rw [intervalIntegral.integral_sub
        ((hF.mono subset_union_left).intervalIntegrable_of_Icc hl)
        ((hG.mono subset_union_left).intervalIntegrable_of_Icc hl),
      intervalIntegral.integral_sub
        ((hF.mono subset_union_right).intervalIntegrable_of_Icc hr)
        ((hG.mono subset_union_right).intervalIntegrable_of_Icc hr)]
  ring

lemma pulseIntegral_const_mul (T l r c : ℝ) (F : ℝ → ℝ) :
    pulseIntegral T l r (fun u => c * F u) = c * pulseIntegral T l r F := by
  simp only [pulseIntegral, intervalIntegral.integral_const_mul]
  ring

/-- Positive and negative forcing masses have controlled effects whenever
the positive height is comparable with a reference height. -/
lemma quotient_upper_of_comparable_height {A z p n : ℝ}
    (hA : 0 < A) (hz : 0 < z) (hp : 0 ≤ p) (hn : 0 ≤ n)
    (hl : A / 2 ≤ z) (hu : z ≤ 2 * A) :
    (p - n) / z ≤ (2 / A) * p - (1 / (2 * A)) * n := by
  have hpp : p / z ≤ (2 / A) * p := by
    calc
      p / z ≤ p / (A / 2) := div_le_div_of_nonneg_left hp (half_pos hA) hl
      _ = (2 / A) * p := by field_simp; ring
  have hnn : (1 / (2 * A)) * n ≤ n / z := by
    calc
      (1 / (2 * A)) * n = n / (2 * A) := by ring
      _ ≤ n / z := div_le_div_of_nonneg_left hn hz hu
  rw [sub_div]
  exact sub_le_sub hpp hnn

namespace IsClassicalSolution

variable {T : ℝ} {h x v a : ℝ → ℝ}

/-- Integrating the actual velocity between any two times in the interval. -/
theorem integral_velocity (hs : IsClassicalSolution T h x v a)
    {s t : ℝ} (hs0 : 0 ≤ s) (hst : s ≤ t) (htT : t ≤ T) :
    (∫ u in s..t, v u) = x t - x s := by
  have hsub : Icc s t ⊆ Icc 0 T := Icc_subset_Icc hs0 htT
  exact integral_eq_sub_of_within_derivative hst
    (hs.continuous_x.mono hsub) (hs.continuous_v.mono hsub)
    (fun u hu => (hs.dx u (hsub hu)).mono hsub)

/-- Integrating the actual acceleration on a subinterval. -/
theorem integral_acceleration (hs : IsClassicalSolution T h x v a)
    {s t : ℝ} (hs0 : 0 ≤ s) (hst : s ≤ t) (htT : t ≤ T) :
    (∫ u in s..t, a u) = v t - v s := by
  have hsub : Icc s t ⊆ Icc 0 T := Icc_subset_Icc hs0 htT
  exact integral_eq_sub_of_within_derivative hst
    (hs.continuous_v.mono hsub) (hs.continuous_a.mono hsub)
    (fun u hu => (hs.dv u (hsub hu)).mono hsub)

/-- Global kinetic energy controls position changes even arbitrarily close
to a possible zero-height limit. -/
theorem position_increment_sq_le_energy (hs : IsClassicalSolution T h x v a)
    {s t : ℝ} (hs0 : 0 ≤ s) (hst : s ≤ t) (htT : t ≤ T) :
    (x t - x s) ^ 2 ≤ (t - s) * ∫ u in (0 : ℝ)..T, (v u) ^ 2 := by
  have hT : 0 ≤ T := hs0.trans (hst.trans htT)
  have hsub : Icc s t ⊆ Icc 0 T := Icc_subset_Icc hs0 htT
  have hlocal := sq_integral_le_length_mul_integral_sq hst (hs.continuous_v.mono hsub)
  rw [hs.integral_velocity hs0 hst htT] at hlocal
  refine hlocal.trans (mul_le_mul_of_nonneg_left ?_ (sub_nonneg.mpr hst))
  exact intervalIntegral.integral_mono_interval hs0 hst htT
    (Filter.Eventually.of_forall (fun u => sq_nonneg (v u)))
    ((hs.continuous_v.pow 2).intervalIntegrable_of_Icc hT)

/-- A numerical energy bound yields an explicit square-root modulus. -/
theorem position_increment_abs_le (hs : IsClassicalSolution T h x v a)
    {s t E : ℝ} (hs0 : 0 ≤ s) (hst : s ≤ t) (htT : t ≤ T)
    (hE : (∫ u in (0 : ℝ)..T, (v u) ^ 2) ≤ E) :
    |x t - x s| ≤ Real.sqrt ((t - s) * E) := by
  have hsq := (hs.position_increment_sq_le_energy hs0 hst htT).trans
    (mul_le_mul_of_nonneg_left hE (sub_nonneg.mpr hst))
  exact Real.abs_le_sqrt hsq

/-- The energy controls the full oscillation of the position. -/
theorem position_oscillation_bound (hs : IsClassicalSolution T h x v a)
    {E : ℝ} (hE0 : 0 ≤ E)
    (hE : (∫ u in (0 : ℝ)..T, (v u) ^ 2) ≤ E) :
    ∀ s ∈ Icc 0 T, ∀ t ∈ Icc 0 T,
      |x t - x s| ≤ Real.sqrt (T * E) := by
  intro s hs' t ht
  rcases le_total s t with hst | hts
  · have hb := hs.position_increment_abs_le hs'.1 hst ht.2 hE
    exact hb.trans (Real.sqrt_le_sqrt
      (mul_le_mul_of_nonneg_right (by linarith [ht.2, hs'.1]) hE0))
  · have hb := hs.position_increment_abs_le ht.1 hts hs'.2 hE
    rw [abs_sub_comm] at hb
    exact hb.trans (Real.sqrt_le_sqrt
      (mul_le_mul_of_nonneg_right (by linarith [hs'.2, ht.1]) hE0))

/-- Force balance and a dominant negative forcing mass turn a position
oscillation bound into an absolute height bound. -/
theorem global_height_le_of_oscillation (hs : IsClassicalSolution T h x v a)
    {D : ℝ} {p n : ℝ → ℝ} (hT : 0 ≤ T)
    (hp : ContinuousOn p (Icc 0 T)) (hn : ContinuousOn n (Icc 0 T))
    (hp0 : ∀ u ∈ Icc 0 T, 0 ≤ p u) (hn0 : ∀ u ∈ Icc 0 T, 0 ≤ n u)
    (hdec : ∀ u ∈ Icc 0 T, h u = p u - n u)
    (hpmass : (∫ u in (0 : ℝ)..T, p u) ≤ 1)
    (hnmass : (∫ u in (0 : ℝ)..T, n u) = 2)
    (hosc : ∀ s ∈ Icc 0 T, ∀ t ∈ Icc 0 T, |x t - x s| ≤ D) :
    ∀ t ∈ Icc 0 T, x t ≤ 2 * D := by
  obtain ⟨s, hs', hmin⟩ := isCompact_Icc.exists_isMinOn
    (nonempty_Icc.mpr hT) hs.continuous_x
  let m := x s
  have hm : 0 < m := hs.positive s hs'
  have hD : 0 ≤ D := by simpa using hosc s hs' s hs'
  have hM : 0 < m + D := add_pos_of_pos_of_nonneg hm hD
  have hlo : ∀ u ∈ Icc 0 T, m ≤ x u := fun u hu => hmin hu
  have hhi : ∀ u ∈ Icc 0 T, x u ≤ m + D := by
    intro u hu
    have hh := (abs_le.mp (hosc s hs' u hu)).2
    dsimp [m]
    linarith
  have hi := hp.intervalIntegrable_of_Icc (μ := volume) hT
  have hj := hn.intervalIntegrable_of_Icc (μ := volume) hT
  have hbound : (∫ u in (0 : ℝ)..T, a u) ≤
      (∫ u in (0 : ℝ)..T, p u) / m - (∫ u in (0 : ℝ)..T, n u) / (m + D) := by
    calc
      (∫ u in (0 : ℝ)..T, a u) ≤
          ∫ u in (0 : ℝ)..T, p u / m - n u / (m + D) := by
        apply intervalIntegral.integral_mono_on hT
          (hs.continuous_a.intervalIntegrable_of_Icc hT)
          ((hi.div_const _).sub (hj.div_const _))
        intro u hu
        rw [hs.acceleration_eq_div hu, hdec u hu, sub_div]
        apply sub_le_sub
        · exact div_le_div_of_nonneg_left (hp0 u hu) hm (hlo u hu)
        · exact div_le_div_of_nonneg_left (hn0 u hu) (hs.positive u hu) (hhi u hu)
      _ = (∫ u in (0 : ℝ)..T, p u) / m -
          (∫ u in (0 : ℝ)..T, n u) / (m + D) := by
        rw [intervalIntegral.integral_sub (hi.div_const _) (hj.div_const _),
          intervalIntegral.integral_div, intervalIntegral.integral_div]
  rw [hs.integral_acceleration le_rfl hT le_rfl, ← hs.endpoint_v, sub_self,
    hnmass] at hbound
  have hpbound := div_le_div_of_nonneg_right hpmass hm.le
  have hmass : 2 / (m + D) ≤ 1 / m := by linarith
  have hcross := (div_le_div_iff₀ hM hm).mp hmass
  have hmD : m ≤ D := by linarith
  intro t ht
  exact (hhi t ht).trans (by linarith)

/-- A convenient numerical height bound for the raw-period family. -/
theorem global_height_le_six (hs : IsClassicalSolution T h x v a)
    {p n : ℝ → ℝ} (hT : 0 ≤ T) (hT4 : T ≤ 4)
    (hE : (∫ u in (0 : ℝ)..T, (v u) ^ 2) ≤ 2)
    (hp : ContinuousOn p (Icc 0 T)) (hn : ContinuousOn n (Icc 0 T))
    (hp0 : ∀ u ∈ Icc 0 T, 0 ≤ p u) (hn0 : ∀ u ∈ Icc 0 T, 0 ≤ n u)
    (hdec : ∀ u ∈ Icc 0 T, h u = p u - n u)
    (hpmass : (∫ u in (0 : ℝ)..T, p u) ≤ 1)
    (hnmass : (∫ u in (0 : ℝ)..T, n u) = 2) :
    ∀ t ∈ Icc 0 T, x t ≤ 6 := by
  have hosc := hs.position_oscillation_bound (by norm_num : (0 : ℝ) ≤ 2) hE
  have hsqrt : Real.sqrt (T * 2) ≤ 3 := by
    apply (Real.sqrt_le_iff).2
    constructor <;> nlinarith
  have hb := hs.global_height_le_of_oscillation hT hp hn hp0 hn0 hdec hpmass hnmass
    (D := 3) (fun s hs' t ht => (hosc s hs' t ht).trans hsqrt)
  intro t ht
  convert hb t ht using 1 <;> norm_num

/-- A uniform square-root bound at the periodic seam, valid on both
short pulse intervals simultaneously. -/
theorem pulse_position_modulus (hs : IsClassicalSolution T h x v a)
    {l r D E : ℝ} (hl : 0 ≤ l) (hlr : l ≤ r) (hr : r ≤ T)
    (hlD : l ≤ D) (hrD : T - r ≤ D) (hE0 : 0 ≤ E)
    (hE : (∫ u in (0 : ℝ)..T, (v u) ^ 2) ≤ E) :
    ∀ u ∈ pulseSet T l r, |x u - x 0| ≤ Real.sqrt (D * E) := by
  intro u hu
  rcases hu with hu | hu
  · have hb := hs.position_increment_abs_le le_rfl hu.1
      (hu.2.trans (hlr.trans hr)) hE
    simp only [sub_zero] at hb
    exact hb.trans (Real.sqrt_le_sqrt (mul_le_mul_of_nonneg_right (hu.2.trans hlD) hE0))
  · have hb := hs.position_increment_abs_le ((hl.trans hlr).trans hu.1) hu.2 le_rfl hE
    have hc : T - u ≤ D := by linarith [hu.1]
    have hd := hb.trans (Real.sqrt_le_sqrt (mul_le_mul_of_nonneg_right hc hE0))
    rw [← hs.endpoint_x, abs_sub_comm] at hd
    exact hd

/-- The two bowl endpoints differ by at most twice the pulse modulus. -/
theorem pulse_endpoint_difference (hs : IsClassicalSolution T h x v a)
    {l r d : ℝ} (hl : 0 ≤ l) (hr : r ≤ T)
    (hmod : ∀ u ∈ pulseSet T l r, |x u - x 0| ≤ d) :
    |x r - x l| ≤ 2 * d := by
  have hleft := abs_le.mp (hmod l (Or.inl ⟨hl, le_rfl⟩))
  have hright := abs_le.mp (hmod r (Or.inr ⟨le_rfl, hr⟩))
  apply abs_le.mpr
  constructor <;> linarith

/-- A sufficiently short pulse keeps the entire pulse at a comparable
positive height. The reference height is the larger bowl endpoint. -/
theorem pulse_height_comparable (hs : IsClassicalSolution T h x v a)
    {l r d : ℝ} (hl : 0 ≤ l) (hlr : l ≤ r) (hr : r ≤ T)
    (hmod : ∀ u ∈ pulseSet T l r, |x u - x 0| ≤ d)
    (hsmall : 4 * d ≤ max (x l) (x r)) :
    ∀ u ∈ pulseSet T l r,
      max (x l) (x r) / 2 ≤ x u ∧ x u ≤ 2 * max (x l) (x r) := by
  have hlb := abs_le.mp (hmod l (Or.inl ⟨hl, le_rfl⟩))
  have hrb := abs_le.mp (hmod r (Or.inr ⟨le_rfl, hr⟩))
  have hmaxup : max (x l) (x r) ≤ x 0 + d := max_le (by linarith) (by linarith)
  have hmaxlo : x 0 - d ≤ max (x l) (x r) :=
    (show x 0 - d ≤ x l by linarith).trans (le_max_left _ _)
  have hmaxpos : 0 < max (x l) (x r) :=
    (hs.positive l ⟨hl, hlr.trans hr⟩).trans_le (le_max_left _ _)
  intro u hu
  have hub := abs_le.mp (hmod u hu)
  constructor <;> linarith

/-- Across the two endpoint pulses, periodicity gives the acceleration
balance without extending the solution beyond its original interval. -/
theorem pulse_acceleration_balance (hs : IsClassicalSolution T h x v a)
    {l r : ℝ} (hl : 0 ≤ l) (hlr : l ≤ r) (hr : r ≤ T) :
    v r - v l = -((∫ u in (0 : ℝ)..l, a u) + ∫ u in r..T, a u) := by
  rw [hs.integral_acceleration (s := 0) (t := l) le_rfl hl (hlr.trans hr),
      hs.integral_acceleration (s := r) (t := T) (hl.trans hlr) hr le_rfl,
      ← hs.endpoint_v]
  ring

/-- A bound on the total forcing mass, with the negative part dominant,
forces a definite positive velocity jump on the complementary bowl. -/
theorem bowl_velocity_jump_lower (hs : IsClassicalSolution T h x v a)
    {l r A : ℝ} {p n : ℝ → ℝ}
    (hl : 0 ≤ l) (hlr : l ≤ r) (hr : r ≤ T) (hA : 0 < A)
    (hp : ContinuousOn p (pulseSet T l r))
    (hn : ContinuousOn n (pulseSet T l r))
    (hp0 : ∀ u ∈ pulseSet T l r, 0 ≤ p u)
    (hn0 : ∀ u ∈ pulseSet T l r, 0 ≤ n u)
    (hdec : ∀ u ∈ pulseSet T l r, h u = p u - n u)
    (hheight : ∀ u ∈ pulseSet T l r, A / 2 ≤ x u ∧ x u ≤ 2 * A) :
    (1 / (2 * A)) * pulseIntegral T l r n -
      (2 / A) * pulseIntegral T l r p ≤ v r - v l := by
  have hsub := pulseSet_subset hl hlr hr
  have hac : ContinuousOn a (pulseSet T l r) := hs.continuous_a.mono hsub
  have hu : pulseIntegral T l r a ≤
      (2 / A) * pulseIntegral T l r p - (1 / (2 * A)) * pulseIntegral T l r n := by
    calc
      pulseIntegral T l r a ≤
          pulseIntegral T l r (fun u => (2 / A) * p u - (1 / (2 * A)) * n u) := by
        apply pulseIntegral_mono hl hr hac ((continuousOn_const.mul hp).sub (continuousOn_const.mul hn))
        intro u hu
        rw [hs.acceleration_eq_div (hsub hu), hdec u hu]
        exact quotient_upper_of_comparable_height hA (hs.positive u (hsub hu))
          (hp0 u hu) (hn0 u hu) (hheight u hu).1 (hheight u hu).2
      _ = (2 / A) * pulseIntegral T l r p -
          (1 / (2 * A)) * pulseIntegral T l r n := by
        rw [pulseIntegral_sub hl hr (continuousOn_const.mul hp) (continuousOn_const.mul hn),
          pulseIntegral_const_mul, pulseIntegral_const_mul]
  have hb := hs.pulse_acceleration_balance hl hlr hr
  change v r - v l = -pulseIntegral T l r a at hb
  linarith

/-- The absolute acceleration mass depends only on the forcing masses
and the positive lower height. -/
theorem pulse_acceleration_mass_le (hs : IsClassicalSolution T h x v a)
    {l r A : ℝ} {p n : ℝ → ℝ}
    (hl : 0 ≤ l) (hlr : l ≤ r) (hr : r ≤ T) (hA : 0 < A)
    (hp : ContinuousOn p (pulseSet T l r))
    (hn : ContinuousOn n (pulseSet T l r))
    (hp0 : ∀ u ∈ pulseSet T l r, 0 ≤ p u)
    (hn0 : ∀ u ∈ pulseSet T l r, 0 ≤ n u)
    (hdec : ∀ u ∈ pulseSet T l r, h u = p u - n u)
    (hheight : ∀ u ∈ pulseSet T l r, A / 2 ≤ x u) :
    pulseIntegral T l r (fun u => |a u|) ≤
      (2 / A) * (pulseIntegral T l r p + pulseIntegral T l r n) := by
  have hsub := pulseSet_subset hl hlr hr
  calc
    pulseIntegral T l r (fun u => |a u|) ≤
        pulseIntegral T l r (fun u => (2 / A) * (p u + n u)) := by
      apply pulseIntegral_mono hl hr (hs.continuous_a.mono hsub).abs
        (continuousOn_const.mul (hp.add hn))
      intro u hu
      have hx := hs.positive u (hsub hu)
      rw [hs.acceleration_eq_div (hsub hu), hdec u hu, abs_div, abs_of_pos hx]
      calc
        |p u - n u| / x u ≤ (p u + n u) / x u := by
          apply div_le_div_of_nonneg_right _ hx.le
          calc
            |p u - n u| ≤ |p u| + |n u| := abs_sub _ _
            _ = p u + n u := by rw [abs_of_nonneg (hp0 u hu), abs_of_nonneg (hn0 u hu)]
        _ ≤ (p u + n u) / (A / 2) :=
          div_le_div_of_nonneg_left (add_nonneg (hp0 u hu) (hn0 u hu))
            (half_pos hA) (hheight u hu)
        _ = (2 / A) * (p u + n u) := by field_simp; ring
    _ = (2 / A) * (pulseIntegral T l r p + pulseIntegral T l r n) := by
      rw [pulseIntegral_const_mul]
      unfold pulseIntegral
      rw [intervalIntegral.integral_add
        ((hp.mono subset_union_left).intervalIntegrable_of_Icc hl)
        ((hn.mono subset_union_left).intervalIntegrable_of_Icc hl),
        intervalIntegral.integral_add
        ((hp.mono subset_union_right).intervalIntegrable_of_Icc hr)
        ((hn.mono subset_union_right).intervalIntegrable_of_Icc hr)]
      ring

/-- Any velocity inside a short pulse is bounded by its adjacent bowl
endpoint velocity plus the total absolute acceleration mass. -/
theorem pulse_velocity_bound (hs : IsClassicalSolution T h x v a)
    {l r B K : ℝ} (hl : 0 ≤ l) (hlr : l ≤ r) (hr : r ≤ T)
    (hleft : |v l| ≤ B) (hright : |v r| ≤ B)
    (hmass : pulseIntegral T l r (fun u => |a u|) ≤ K) :
    ∀ u ∈ pulseSet T l r, |v u| ≤ B + K := by
  have hT : 0 ≤ T := hl.trans (hlr.trans hr)
  have hi : IntervalIntegrable (fun u => |a u|) volume 0 l :=
    (hs.continuous_a.abs.mono (Icc_subset_Icc le_rfl (hlr.trans hr))).intervalIntegrable_of_Icc hl
  have hj : IntervalIntegrable (fun u => |a u|) volume r T :=
    (hs.continuous_a.abs.mono (Icc_subset_Icc (hl.trans hlr) le_rfl)).intervalIntegrable_of_Icc hr
  have hip : 0 ≤ ∫ u in (0 : ℝ)..l, |a u| :=
    intervalIntegral.integral_nonneg hl (fun u _ => abs_nonneg _)
  have hjp : 0 ≤ ∫ u in r..T, |a u| :=
    intervalIntegral.integral_nonneg hr (fun u _ => abs_nonneg _)
  intro u hu
  rcases hu with hu | hu
  · have hlocal : |v l - v u| ≤ ∫ w in u..l, |a w| := by
      rw [← hs.integral_acceleration hu.1 hu.2 (hlr.trans hr)]
      exact intervalIntegral.abs_integral_le_integral_abs hu.2
    have hmon : (∫ w in u..l, |a w|) ≤ ∫ w in (0 : ℝ)..l, |a w| :=
      intervalIntegral.integral_mono_interval hu.1 hu.2 le_rfl
        (Filter.Eventually.of_forall (fun w => abs_nonneg (a w))) hi
    have htri : |v u| ≤ |v l - v u| + |v l| := by
      calc
        |v u| = |(v u - v l) + v l| := by rw [sub_add_cancel]
        _ ≤ |v u - v l| + |v l| := abs_add _ _
        _ = |v l - v u| + |v l| := by rw [abs_sub_comm]
    dsimp [pulseIntegral] at hmass
    linarith
  · have hlocal : |v u - v r| ≤ ∫ w in r..u, |a w| := by
      rw [← hs.integral_acceleration (hl.trans hlr) hu.1 hu.2]
      exact intervalIntegral.abs_integral_le_integral_abs hu.1
    have hmon : (∫ w in r..u, |a w|) ≤ ∫ w in r..T, |a w| :=
      intervalIntegral.integral_mono_interval le_rfl hu.1 hu.2
        (Filter.Eventually.of_forall (fun w => abs_nonneg (a w))) hj
    have htri : |v u| ≤ |v u - v r| + |v r| := by
      calc
        |v u| = |(v u - v r) + v r| := by rw [sub_add_cancel]
        _ ≤ |v u - v r| + |v r| := abs_add _ _
    dsimp [pulseIntegral] at hmass
    linarith

/-- For a monotone bowl velocity, the endpoint slopes differ from the
average slope by at most the total slope increase. -/
theorem bowl_endpoint_velocity_bound (hs : IsClassicalSolution T h x v a)
    {l r K : ℝ} (hl : 0 ≤ l) (hlr : l < r) (hr : r ≤ T)
    (hmono : MonotoneOn v (Icc l r)) (hjump : v r - v l ≤ K) :
    |v l| ≤ |(x r - x l) / (r - l)| + K ∧
      |v r| ≤ |(x r - x l) / (r - l)| + K := by
  have hi : IntervalIntegrable v volume l r :=
    (hs.continuous_v.mono (Icc_subset_Icc hl hr)).intervalIntegrable_of_Icc hlr.le
  have hlo : (r - l) * v l ≤ x r - x l := by
    have hh := intervalIntegral.integral_mono_on hlr.le intervalIntegrable_const hi
      (fun u hu => hmono ⟨le_rfl, hlr.le⟩ hu hu.1)
    rw [hs.integral_velocity hl hlr.le hr, intervalIntegral.integral_const] at hh
    simpa only [smul_eq_mul] using hh
  have hhi : x r - x l ≤ (r - l) * v r := by
    have hh := intervalIntegral.integral_mono_on hlr.le hi intervalIntegrable_const
      (fun u hu => hmono hu ⟨hlr.le, le_rfl⟩ hu.2)
    rw [hs.integral_velocity hl hlr.le hr, intervalIntegral.integral_const] at hh
    simpa only [smul_eq_mul] using hh
  have hlen : 0 < r - l := sub_pos.mpr hlr
  have hleft : v l ≤ (x r - x l) / (r - l) :=
    (le_div_iff₀ hlen).2 (by simpa only [mul_comm] using hlo)
  have hright : (x r - x l) / (r - l) ≤ v r :=
    (div_le_iff₀ hlen).2 (by simpa only [mul_comm] using hhi)
  have hm0 := neg_abs_le ((x r - x l) / (r - l))
  have hm1 := le_abs_self ((x r - x l) / (r - l))
  have hK : 0 ≤ K := (sub_nonneg.mpr (hmono ⟨le_rfl, hlr.le⟩ ⟨hlr.le, le_rfl⟩ hlr.le)).trans hjump
  constructor <;> apply abs_le.mpr <;> constructor <;> linarith

/-- The bowl slope increase is no larger than the absolute pulse
acceleration mass. -/
theorem bowl_velocity_jump_upper (hs : IsClassicalSolution T h x v a)
    {l r K : ℝ} (hl : 0 ≤ l) (hlr : l ≤ r) (hr : r ≤ T)
    (hmass : pulseIntegral T l r (fun u => |a u|) ≤ K) :
    v r - v l ≤ K := by
  have hsub := pulseSet_subset hl hlr hr
  have hbound := pulseIntegral_mono hl hr (hs.continuous_a.mono hsub).neg
    (hs.continuous_a.mono hsub).abs (fun u _ => neg_le_abs (a u))
  have hneg : pulseIntegral T l r (fun u => -a u) = -pulseIntegral T l r a := by
    simp only [pulseIntegral, intervalIntegral.integral_neg]
    ring
  rw [hneg] at hbound
  have hb := hs.pulse_acceleration_balance hl hlr hr
  change v r - v l = -pulseIntegral T l r a at hb
  rw [hb]
  exact hbound.trans hmass

/-- Bounded velocity makes the kinetic energy in the pulse vanish with
its length. -/
theorem pulse_kinetic_energy_le (hs : IsClassicalSolution T h x v a)
    {l r V : ℝ} (hl : 0 ≤ l) (hlr : l ≤ r) (hr : r ≤ T)
    (hV : ∀ u ∈ pulseSet T l r, |v u| ≤ V) :
    pulseIntegral T l r (fun u => (v u) ^ 2) ≤ (l + (T - r)) * V ^ 2 := by
  calc
    pulseIntegral T l r (fun u => (v u) ^ 2) ≤
        pulseIntegral T l r (fun _ => V ^ 2) := by
      apply pulseIntegral_mono hl hr
        ((hs.continuous_v.mono (pulseSet_subset hl hlr hr)).pow 2) continuousOn_const
      intro u hu
      simpa only [sq_abs] using
        (sq_le_sq₀ (abs_nonneg _) ((abs_nonneg _).trans (hV u hu))).2 (hV u hu)
    _ = (l + (T - r)) * V ^ 2 := by
      simp only [pulseIntegral, intervalIntegral.integral_const, sub_zero, smul_eq_mul]
      ring

/-- Exact splitting into bowl energy and the two short pulse energies. -/
theorem kinetic_energy_split (hs : IsClassicalSolution T h x v a)
    {l r : ℝ} (hl : 0 ≤ l) (hlr : l ≤ r) (hr : r ≤ T) :
    (∫ u in l..r, (v u) ^ 2) + pulseIntegral T l r (fun u => (v u) ^ 2) =
      ∫ u in (0 : ℝ)..T, (v u) ^ 2 := by
  have hT : 0 ≤ T := hl.trans (hlr.trans hr)
  have hint := (hs.continuous_v.pow 2).intervalIntegrable_of_Icc (μ := volume) hT
  have hi : IntervalIntegrable (fun u => (v u) ^ 2) volume 0 l :=
    hint.mono_set (by simpa [uIcc_of_le hT, uIcc_of_le hl] using
      (Icc_subset_Icc le_rfl (hlr.trans hr)))
  have hj : IntervalIntegrable (fun u => (v u) ^ 2) volume l r :=
    hint.mono_set (by simpa [uIcc_of_le hT, uIcc_of_le hlr] using
      (Icc_subset_Icc hl hr))
  have hk : IntervalIntegrable (fun u => (v u) ^ 2) volume r T :=
    hint.mono_set (by simpa [uIcc_of_le hT, uIcc_of_le hr] using
      (Icc_subset_Icc (hl.trans hlr) le_rfl))
  have hij := intervalIntegral.integral_add_adjacent_intervals hi hj
  have hijk := intervalIntegral.integral_add_adjacent_intervals (hi.trans hj) hk
  unfold pulseIntegral
  linarith

/-- In the construction the negative pulse has mass two and its positive
collar has mass at most one quarter. This quantitative jump is uniform in
the shape and width of the smooth pulse. -/
theorem bowl_velocity_jump_half (hs : IsClassicalSolution T h x v a)
    {l r A : ℝ} {p n : ℝ → ℝ}
    (hl : 0 ≤ l) (hlr : l ≤ r) (hr : r ≤ T) (hA : 0 < A)
    (hp : ContinuousOn p (pulseSet T l r))
    (hn : ContinuousOn n (pulseSet T l r))
    (hp0 : ∀ u ∈ pulseSet T l r, 0 ≤ p u)
    (hn0 : ∀ u ∈ pulseSet T l r, 0 ≤ n u)
    (hdec : ∀ u ∈ pulseSet T l r, h u = p u - n u)
    (hheight : ∀ u ∈ pulseSet T l r, A / 2 ≤ x u ∧ x u ≤ 2 * A)
    (hnmass : pulseIntegral T l r n = 2)
    (hpmass : pulseIntegral T l r p ≤ 1 / 4) :
    1 / (2 * A) ≤ v r - v l := by
  have hj := hs.bowl_velocity_jump_lower hl hlr hr hA hp hn hp0 hn0 hdec hheight
  rw [hnmass] at hj
  have hpbound := mul_le_mul_of_nonneg_left hpmass
    (le_of_lt (div_pos (by norm_num : (0 : ℝ) < 2) hA))
  have hid : (1 / (2 * A)) * 2 - (2 / A) * (1 / 4 : ℝ) = 1 / (2 * A) := by
    field_simp
    ring
  linarith

end IsClassicalSolution

/-- A bounded normalized bowl slope and the pulse jump prevent the bowl
endpoint height from collapsing. -/
theorem endpoint_height_lower_of_jump {A C vl vr : ℝ}
    (hA : 0 < A) (hleft : |vl| ≤ C * A) (hright : |vr| ≤ C * A)
    (hjump : 1 / (2 * A) ≤ vr - vl) :
    1 / 4 ≤ C * A ^ 2 := by
  have huv : vr - vl ≤ 2 * C * A := by
    have hl := (abs_le.mp hleft).1
    have hr := (abs_le.mp hright).2
    linarith
  have hp : 0 < 2 * A := mul_pos (by norm_num) hA
  have hx := (div_le_iff₀ hp).mp (hjump.trans huv)
  nlinarith

end ReciprocalCounterexample

namespace ReciprocalCounterexample
namespace IsClassicalSolution

/-- A direct package of the pulse estimates for a bowl of length two.
Only the global modulus, forcing masses and monotonicity of the actual bowl
velocity enter this result. -/
theorem short_pulse_bounds (hs : IsClassicalSolution T h x v a)
    {l r A d : ℝ} {p n : ℝ → ℝ}
    (hl : 0 ≤ l) (hlr : l < r) (hr : r ≤ T) (hlen : r - l = 2)
    (hA : 0 < A) (hAeq : A = max (x l) (x r))
    (hmono : MonotoneOn v (Icc l r))
    (hmod : ∀ u ∈ pulseSet T l r, |x u - x 0| ≤ d) (hsmall : 4 * d ≤ A)
    (hp : ContinuousOn p (pulseSet T l r))
    (hn : ContinuousOn n (pulseSet T l r))
    (hp0 : ∀ u ∈ pulseSet T l r, 0 ≤ p u)
    (hn0 : ∀ u ∈ pulseSet T l r, 0 ≤ n u)
    (hdec : ∀ u ∈ pulseSet T l r, h u = p u - n u)
    (hpmass : pulseIntegral T l r p ≤ 1)
    (hnmass : pulseIntegral T l r n ≤ 2) :
    (v r - v l ≤ 6 / A) ∧
    (∀ u ∈ pulseSet T l r, |v u| ≤ d + 12 / A) ∧
    (pulseIntegral T l r (fun u => (v u) ^ 2) ≤
      (l + (T - r)) * (d + 12 / A) ^ 2) ∧
    |x r - x l| ≤ 2 * d := by
  have hheight := hs.pulse_height_comparable hl hlr.le hr hmod (hAeq ▸ hsmall)
  rw [← hAeq] at hheight
  have hmass0 := hs.pulse_acceleration_mass_le hl hlr.le hr hA hp hn hp0 hn0 hdec
    (fun u hu => (hheight u hu).1)
  have hmass : pulseIntegral T l r (fun u => |a u|) ≤ 6 / A := by
    have hb := mul_le_mul_of_nonneg_left (add_le_add hpmass hnmass)
      (div_nonneg (by norm_num : (0:ℝ) ≤ 2) hA.le)
    have hid : (2 / A) * ((1:ℝ) + 2) = 6 / A := by ring
    rw [hid] at hb
    exact hmass0.trans hb
  have hjump := hs.bowl_velocity_jump_upper hl hlr.le hr hmass
  have hends := hs.bowl_endpoint_velocity_bound hl hlr hr hmono hjump
  have hdiff := hs.pulse_endpoint_difference hl hr hmod
  have hmean : |(x r - x l) / (r - l)| ≤ d := by
    rw [abs_div, hlen, abs_of_pos (by norm_num : (0:ℝ) < 2)]
    exact (div_le_iff₀ (by norm_num : (0:ℝ) < 2)).2 (by linarith)
  have hv := hs.pulse_velocity_bound hl hlr.le hr
    (hends.1.trans (add_le_add_right hmean _))
    (hends.2.trans (add_le_add_right hmean _)) hmass
  have hv' : ∀ u ∈ pulseSet T l r, |v u| ≤ d + 12 / A := by
    intro u hu
    convert hv u hu using 1 <;> ring
  exact ⟨hjump, hv', hs.pulse_kinetic_energy_le hl hlr.le hr hv', hdiff⟩

end IsClassicalSolution
end ReciprocalCounterexample
