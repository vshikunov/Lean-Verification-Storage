#!/usr/bin/env python3
"""Rebuild and audit the complete formalization and its specified forcing.

The default success gate requires checked unconditional proofs of MainTheorem
and IsCounterexample explicitCounterexampleForcing. Exit 1 indicates a build
or audit failure; exit 2 indicates a missing final proof. --components-only
permits component verification without passing the final theorem gate.
The pinned Lean toolchain and fetched mathlib dependencies are required.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys


NAMESPACE = 'ReciprocalCounterexample.'
MAIN_TARGET = NAMESPACE + 'MainTheorem'
EXPECTED_MAIN_PROOFS = {
    NAMESPACE + 'mainTheorem_flatCore',
    NAMESPACE + 'mainTheorem_explicit',
}
SPECIFIED_FORCING = NAMESPACE + 'explicitCounterexampleForcing'
EXPECTED_WITNESS_PROOF = NAMESPACE + 'explicitCounterexampleForcing_isCounterexample'
ALLOWED_AXIOMS = ['propext', 'Classical.choice', 'Quot.sound']


def proof_names(audit: str, marker: str) -> list[str]:
    """Read declaration names emitted after Lean's exact-type comparison."""
    pattern = rf'\b{re.escape(marker)}\s+([A-Za-z_][A-Za-z0-9_.]*)\s*$'
    return sorted(set(re.findall(pattern, audit, flags=re.MULTILINE)))


def save_status(root: Path, status: dict) -> None:
    (root / 'verification_status.json').write_text(
        json.dumps(status, indent=2) + '\n', encoding='utf-8')


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lake', help='Path to the Lake executable (default: PATH)')
    parser.add_argument('--components-only', action='store_true',
                        help='Do not require the final unconditional main and witness proofs')
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    lake = args.lake or shutil.which('lake')
    if not lake:
        print('Lake is not on PATH. Install Lean/elan or pass --lake PATH.', file=sys.stderr)
        return 1

    logs = root / 'logs'
    logs.mkdir(exist_ok=True)
    status = {
        'verification_complete': False,
        'component_build_passed': False,
        'component_axiom_audit_passed': False,
        'audited_compiled_theorem_declarations': None,
        'allowed_axioms': ALLOWED_AXIOMS,
        'main_theorem': MAIN_TARGET,
        'main_theorem_verified': None,
        'main_theorem_proofs': [],
        'specified_forcing': SPECIFIED_FORCING,
        'specified_forcing_verified': None,
        'specified_forcing_proofs': [],
        'required_entry_points_verified': False,
        'remaining_obligation': 'The build and compiled-proof audit have not completed.',
        'legacy_sixth_order_family': {
            'proposition': NAMESPACE + 'SmoothedNonexistence',
            'verified': None,
            'proofs': [],
            'required_for_completed_main_theorem': False,
            'conditional_bridge': NAMESPACE + 'main_of_smoothedNonexistence',
        },
        'components_only_mode': args.components_only,
        'error': None,
    }
    outputs = {}
    for stage, command in [('build', [lake, 'build']),
                           ('axiom-audit', [lake, 'env', 'lean', 'Audit.lean'])]:
        try:
            result = subprocess.run(
                command, cwd=root, text=True, encoding='utf-8', errors='replace',
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False)
        except OSError as exc:
            status['error'] = f'{stage}: {exc}'
            save_status(root, status)
            print(status['error'], file=sys.stderr)
            return 1
        outputs[stage] = result.stdout
        (logs / ('final-' + stage + '.log')).write_text(result.stdout, encoding='utf-8')
        print(f'{stage}: exit {result.returncode}', flush=True)
        if result.returncode:
            status['error'] = f'{stage} exited with code {result.returncode}'
            save_status(root, status)
            print(result.stdout, file=sys.stderr)
            return 1
        if stage == 'build':
            status['component_build_passed'] = True

    audit = outputs['axiom-audit']
    count = re.search(r'\bCHECKED_DECLARATIONS\s+(\d+)\b', audit)
    if 'ALL_COMPONENT_AXIOM_CHECKS_PASSED' not in audit or not count:
        status['error'] = 'Required axiom-audit completion marker or declaration count absent.'
        save_status(root, status)
        print(status['error'], file=sys.stderr)
        return 1
    status['component_axiom_audit_passed'] = True
    status['audited_compiled_theorem_declarations'] = int(count.group(1))

    main_proofs = proof_names(audit, 'MAIN_THEOREM_PROOF')
    witness_proofs = proof_names(audit, 'SPECIFIED_FORCING_PROOF')
    legacy_proofs = proof_names(audit, 'LEGACY_SIXTH_ORDER_PROOF')
    main_verified = bool(main_proofs)
    witness_verified = bool(witness_proofs)
    legacy_verified = bool(legacy_proofs)
    expected_markers = [
        'MAIN_THEOREM_STATUS: ' + ('PROVED' if main_verified else 'NOT_PROVED'),
        'SPECIFIED_FORCING_STATUS: ' + ('VERIFIED' if witness_verified else 'NOT_PROVED'),
        'LEGACY_SIXTH_ORDER_STATUS: ' + ('PROVED' if legacy_verified else 'NOT_PROVED'),
        'LEGACY_SIXTH_ORDER_REQUIRED_FOR_MAIN: FALSE',
    ]
    if not all(marker in audit for marker in expected_markers):
        status['error'] = 'Compiled proof status is indeterminate or inconsistent with audit markers.'
        save_status(root, status)
        print(status['error'], file=sys.stderr)
        return 1

    entry_points_verified = (
        EXPECTED_MAIN_PROOFS.issubset(main_proofs)
        and EXPECTED_WITNESS_PROOF in witness_proofs
    )
    complete = main_verified and witness_verified and entry_points_verified
    if complete:
        remaining = None
    elif not main_verified:
        remaining = 'A checked unconditional proof of ' + MAIN_TARGET
    elif not witness_verified:
        remaining = 'A checked unconditional proof of IsCounterexample ' + SPECIFIED_FORCING
    else:
        remaining = 'The documented main-theorem and specified-witness entry points'
    status.update({
        'verification_complete': complete,
        'main_theorem_verified': main_verified,
        'main_theorem_proofs': main_proofs,
        'specified_forcing_verified': witness_verified,
        'specified_forcing_proofs': witness_proofs,
        'required_entry_points_verified': entry_points_verified,
        'remaining_obligation': remaining,
    })
    status['legacy_sixth_order_family'].update({
        'verified': legacy_verified,
        'proofs': legacy_proofs,
    })
    save_status(root, status)
    print(json.dumps(status, indent=2))
    if complete:
        print('The unconditional main theorem and specified counterexample forcing are Lean verified.')
        return 0
    print('The components pass, but the final theorem/witness gate is incomplete.')
    return 0 if args.components_only else 2


if __name__ == '__main__':
    sys.exit(main())
